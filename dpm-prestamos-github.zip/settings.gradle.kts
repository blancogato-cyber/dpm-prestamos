pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "DPM"

include(":app")
include(":core")
include(":database")
include(":domain")
include(":data")
include(":features:dashboard")
include(":features:loans")
include(":features:clients")
include(":features:payments")
include(":features:calendar")
include(":features:accounting")
include(":features:reports")
include(":features:settings")
include(":features:security")
include(":features:backup")
