package com.dpm.prestamos.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.time.LocalDate

@Entity(
    tableName = "clients",
    indices = [
        Index(value = ["fullName"]),
        Index(value = ["phone"]),
        Index(value = ["documentId"])
    ]
)
data class ClientEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fullName: String,
    val phone: String,
    val address: String? = null,
    val documentId: String? = null,
    val photoUri: String? = null,
    val notes: String? = null,
    val createdAt: LocalDate,
    val isActive: Boolean = true
)
