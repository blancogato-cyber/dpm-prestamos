package com.dpm.prestamos.database.dao

import androidx.room.*
import com.dpm.prestamos.database.entity.LoanEntity
import com.dpm.prestamos.domain.enums.LoanStatus
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

@Dao
interface LoanDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(loan: LoanEntity): Long

    @Update
    suspend fun update(loan: LoanEntity)

    @Query("SELECT * FROM loans WHERE id = :id")
    suspend fun getById(id: Long): LoanEntity?

    @Query("SELECT * FROM loans WHERE id = :id")
    fun observeById(id: Long): Flow<LoanEntity?>

    @Query("SELECT * FROM loans ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<LoanEntity>>

    @Query("SELECT * FROM loans WHERE status = :status ORDER BY dueDate ASC")
    fun observeByStatus(status: LoanStatus): Flow<List<LoanEntity>>

    @Query("SELECT * FROM loans WHERE clientId = :clientId ORDER BY createdAt DESC")
    fun observeByClient(clientId: Long): Flow<List<LoanEntity>>

    @Query("SELECT * FROM loans WHERE dueDate = :date")
    fun observeDueOn(date: LocalDate): Flow<List<LoanEntity>>

    @Query("SELECT COALESCE(MAX(id), 0) + 1 FROM loans")
    suspend fun nextSequence(): Long

    @Query("SELECT * FROM loans")
    suspend fun getAllOnce(): List<LoanEntity>

    @Query("SELECT COALESCE(SUM(CAST(principalOriginal AS REAL)),0) FROM loans WHERE clientId = :clientId")
    suspend fun sumHistoricLent(clientId: Long): Double
    @Query("SELECT COALESCE(SUM(CAST(totalPaid AS REAL)),0) FROM loans WHERE clientId = :clientId")
    suspend fun sumHistoricRecovered(clientId: Long): Double
    @Query("SELECT COALESCE(SUM(CAST(interestPaid AS REAL)),0) FROM loans WHERE clientId = :clientId")
    suspend fun sumInterestPaid(clientId: Long): Double
    @Query("SELECT COALESCE(SUM(CAST(totalBalance AS REAL)),0) FROM loans WHERE clientId = :clientId AND status NOT IN ('LIQUIDADO','CANCELADO','REESTRUCTURADO')")
    suspend fun sumCurrentDebt(clientId: Long): Double
    @Query("SELECT COUNT(*) FROM loans WHERE clientId = :clientId AND status IN ('ACTIVO','PROXIMO_VENCER')")
    suspend fun countActive(clientId: Long): Int
    @Query("SELECT COUNT(*) FROM loans WHERE clientId = :clientId AND status = 'VENCIDO'")
    suspend fun countOverdue(clientId: Long): Int
    @Query("SELECT COUNT(*) FROM loans WHERE clientId = :clientId AND status = 'LIQUIDADO'")
    suspend fun countSettled(clientId: Long): Int
}
