package com.dpm.prestamos.database.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.dpm.prestamos.core.money.Money

@Entity(
    tableName = "payment_allocations",
    foreignKeys = [
        ForeignKey(entity = PaymentEntity::class, parentColumns = ["id"], childColumns = ["paymentId"], onDelete = ForeignKey.RESTRICT)
    ],
    indices = [Index("paymentId")]
)
data class PaymentAllocationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val paymentId: Long,
    val component: String, // INTERES, CAPITAL, MORA, EXCEDENTE
    val periodRef: Int? = null,
    val amount: Money
)
