package com.dpm.prestamos.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.dpm.prestamos.database.converters.DateTimeConverter
import com.dpm.prestamos.database.converters.MoneyConverter
import com.dpm.prestamos.database.dao.*
import com.dpm.prestamos.database.entity.*

@Database(
    entities = [
        ClientEntity::class,
        LoanEntity::class,
        PaymentEntity::class,
        PaymentAllocationEntity::class,
        MovementEntity::class,
        CashAccountEntity::class,
        CashTransactionEntity::class,
        AuditLogEntity::class
    ],
    version = 2,
    exportSchema = true
)
@TypeConverters(MoneyConverter::class, DateTimeConverter::class)
abstract class DpmDatabase : RoomDatabase() {
    abstract fun clientDao(): ClientDao
    abstract fun loanDao(): LoanDao
    abstract fun paymentDao(): PaymentDao
    abstract fun allocationDao(): AllocationDao
    abstract fun movementDao(): MovementDao
    abstract fun cashDao(): CashDao
    abstract fun auditDao(): AuditDao
    abstract fun dashboardDao(): DashboardDao
}
