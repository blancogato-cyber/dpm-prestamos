package com.dpm.prestamos.database.dao

import androidx.room.*
import com.dpm.prestamos.database.entity.PaymentEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PaymentDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(payment: PaymentEntity): Long

    @Update
    suspend fun update(payment: PaymentEntity)

    @Query("SELECT * FROM payments WHERE id = :id")
    suspend fun getById(id: Long): PaymentEntity?

    @Query("SELECT * FROM payments WHERE loanId = :loanId ORDER BY paidAt DESC")
    fun observeByLoan(loanId: Long): Flow<List<PaymentEntity>>

    @Query("SELECT * FROM payments ORDER BY paidAt DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<PaymentEntity>>

    @Query("SELECT * FROM payments WHERE date(paidAt/1000,'unixepoch','localtime') = date(:epochMillis/1000,'unixepoch','localtime')")
    suspend fun getByDay(epochMillis: Long): List<PaymentEntity>

    @Query("SELECT MAX(paidAt) FROM payments WHERE clientId = :clientId AND status = 'APLICADO'")
    suspend fun lastPaymentAt(clientId: Long): java.time.LocalDateTime?

    @Query("SELECT * FROM payments ORDER BY paidAt DESC")
    suspend fun getAllOnce(): List<PaymentEntity>
}
