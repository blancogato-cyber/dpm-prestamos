package com.dpm.prestamos.database.dao

import androidx.room.*
import com.dpm.prestamos.database.entity.CashAccountEntity
import com.dpm.prestamos.database.entity.CashTransactionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CashDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertAccount(account: CashAccountEntity): Long

    @Update
    suspend fun updateAccount(account: CashAccountEntity)

    @Query("SELECT * FROM cash_accounts LIMIT 1")
    suspend fun getMainAccount(): CashAccountEntity?

    @Query("SELECT * FROM cash_accounts LIMIT 1")
    fun observeMainAccount(): Flow<CashAccountEntity?>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertTransaction(tx: CashTransactionEntity): Long

    @Query("SELECT * FROM cash_transactions ORDER BY occurredAt DESC")
    fun observeTransactions(): Flow<List<CashTransactionEntity>>

    @Query("SELECT * FROM cash_transactions ORDER BY occurredAt DESC")
    suspend fun getTransactionsOnce(): List<CashTransactionEntity>
}
