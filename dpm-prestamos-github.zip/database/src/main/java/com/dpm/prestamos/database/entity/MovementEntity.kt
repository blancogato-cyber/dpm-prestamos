package com.dpm.prestamos.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.domain.enums.MovementType
import java.time.LocalDateTime

@Entity(
    tableName = "movements",
    indices = [
        Index(value = ["loanId"]),
        Index(value = ["timestamp"]),
        Index(value = ["type"])
    ]
)
data class MovementEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val loanId: Long? = null,
    val paymentId: Long? = null,
    val cashTxId: Long? = null,
    val type: MovementType,
    val amount: Money,
    val timestamp: LocalDateTime,
    val balanceBefore: Money,
    val balanceAfter: Money,
    val principalBefore: Money? = null,
    val principalAfter: Money? = null,
    val interestBefore: Money? = null,
    val interestAfter: Money? = null,
    val actor: String? = null,
    val reference: String? = null
)
