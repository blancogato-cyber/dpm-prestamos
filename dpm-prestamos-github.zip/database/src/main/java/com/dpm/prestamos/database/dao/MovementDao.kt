package com.dpm.prestamos.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.dpm.prestamos.database.entity.MovementEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MovementDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(movement: MovementEntity): Long

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertAll(movements: List<MovementEntity>)

    @Query("SELECT * FROM movements WHERE loanId = :loanId ORDER BY timestamp DESC, id DESC")
    fun observeByLoan(loanId: Long): Flow<List<MovementEntity>>

    @Query("SELECT * FROM movements ORDER BY timestamp DESC, id DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<MovementEntity>>
}
