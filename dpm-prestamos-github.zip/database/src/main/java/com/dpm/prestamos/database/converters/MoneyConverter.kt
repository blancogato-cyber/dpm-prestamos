package com.dpm.prestamos.database.converters

import androidx.room.TypeConverter
import com.dpm.prestamos.core.money.Money
import java.math.BigDecimal

class MoneyConverter {
    @TypeConverter
    fun fromMoney(value: Money?): String? = value?.amount?.toPlainString()

    @TypeConverter
    fun toMoney(value: String?): Money? = value?.let { Money.ofExact(BigDecimal(it)) }
}
