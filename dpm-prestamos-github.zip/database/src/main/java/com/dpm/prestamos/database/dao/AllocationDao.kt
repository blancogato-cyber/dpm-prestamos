package com.dpm.prestamos.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.dpm.prestamos.database.entity.PaymentAllocationEntity

@Dao
interface AllocationDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertAll(items: List<PaymentAllocationEntity>)

    @Query("SELECT * FROM payment_allocations WHERE paymentId = :paymentId")
    suspend fun getByPayment(paymentId: Long): List<PaymentAllocationEntity>
}
