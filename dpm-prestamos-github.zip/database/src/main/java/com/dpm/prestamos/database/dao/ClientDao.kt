package com.dpm.prestamos.database.dao

import androidx.room.*
import com.dpm.prestamos.database.entity.ClientEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ClientDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(client: ClientEntity): Long

    @Update
    suspend fun update(client: ClientEntity)

    @Query("SELECT * FROM clients WHERE id = :id")
    suspend fun getById(id: Long): ClientEntity?

    @Query("SELECT * FROM clients WHERE id = :id")
    fun observeById(id: Long): Flow<ClientEntity?>

    @Query("SELECT * FROM clients ORDER BY fullName COLLATE NOCASE ASC")
    fun observeAll(): Flow<List<ClientEntity>>

    @Query("SELECT * FROM clients WHERE fullName LIKE '%' || :query || '%' OR phone LIKE '%' || :query || '%' ORDER BY fullName")
    fun search(query: String): Flow<List<ClientEntity>>

    @Query("SELECT COUNT(*) FROM clients WHERE lower(trim(fullName)) = lower(trim(:name)) AND trim(phone) = trim(:phone) AND (:excludeId IS NULL OR id != :excludeId)")
    suspend fun countPossibleDuplicates(name: String, phone: String, excludeId: Long?): Int

    @Query("SELECT * FROM clients ORDER BY fullName COLLATE NOCASE ASC")
    suspend fun getAllOnce(): List<ClientEntity>
}
