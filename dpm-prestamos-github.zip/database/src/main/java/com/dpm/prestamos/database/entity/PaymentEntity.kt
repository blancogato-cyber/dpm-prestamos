package com.dpm.prestamos.database.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.domain.enums.DistributionMode
import com.dpm.prestamos.domain.enums.PaymentMethod
import com.dpm.prestamos.domain.enums.PaymentStatus
import java.time.LocalDateTime

@Entity(
    tableName = "payments",
    foreignKeys = [
        ForeignKey(entity = LoanEntity::class, parentColumns = ["id"], childColumns = ["loanId"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = ClientEntity::class, parentColumns = ["id"], childColumns = ["clientId"], onDelete = ForeignKey.RESTRICT)
    ],
    indices = [
        Index(value = ["loanId"]),
        Index(value = ["clientId"]),
        Index(value = ["paidAt"]),
        Index(value = ["receiptNumber"], unique = true),
        Index(value = ["status"])
    ]
)
data class PaymentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val loanId: Long,
    val clientId: Long,
    val receiptNumber: String,
    val paidAt: LocalDateTime,
    val amountTotal: Money,
    val amountToInterest: Money,
    val amountToPrincipal: Money,
    val amountToFees: Money = Money.ZERO,
    val surplus: Money = Money.ZERO,
    val method: PaymentMethod,
    val distributionMode: DistributionMode,
    val notes: String? = null,
    val status: PaymentStatus = PaymentStatus.APLICADO,
    val voidReason: String? = null,
    val voidedAt: LocalDateTime? = null
)
