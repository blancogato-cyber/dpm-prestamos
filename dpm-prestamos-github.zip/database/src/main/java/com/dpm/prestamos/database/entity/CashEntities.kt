package com.dpm.prestamos.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.domain.enums.CashTxType
import java.time.LocalDateTime

@Entity(tableName = "cash_accounts")
data class CashAccountEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val currency: String = "DOP",
    val initialBalance: Money,
    val currentBalance: Money,
    val createdAt: LocalDateTime
)

@Entity(
    tableName = "cash_transactions",
    indices = [Index("cashAccountId"), Index("occurredAt"), Index("type"), Index("relatedLoanId")]
)
data class CashTransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val cashAccountId: Long,
    val type: CashTxType,
    val amount: Money,
    val relatedLoanId: Long? = null,
    val relatedPaymentId: Long? = null,
    val occurredAt: LocalDateTime,
    val notes: String? = null,
    val justification: String? = null
)
