package com.dpm.prestamos.database.di

import android.content.Context
import androidx.room.Room
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.dpm.prestamos.database.DpmDatabase
import com.dpm.prestamos.database.dao.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    private val MIGRATION_1_2 = object : Migration(1, 2) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL(
                """
                CREATE TABLE IF NOT EXISTS `payment_allocations` (
                    `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    `paymentId` INTEGER NOT NULL,
                    `component` TEXT NOT NULL,
                    `periodRef` INTEGER,
                    `amount` TEXT NOT NULL,
                    FOREIGN KEY(`paymentId`) REFERENCES `payments`(`id`) ON UPDATE NO ACTION ON DELETE RESTRICT
                )
                """.trimIndent()
            )
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_payment_allocations_paymentId` ON `payment_allocations` (`paymentId`)")
        }
    }

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): DpmDatabase =
        Room.databaseBuilder(context, DpmDatabase::class.java, "dpm.db")
            .addMigrations(MIGRATION_1_2)
            .build()

    @Provides fun provideClientDao(db: DpmDatabase): ClientDao = db.clientDao()
    @Provides fun provideLoanDao(db: DpmDatabase): LoanDao = db.loanDao()
    @Provides fun providePaymentDao(db: DpmDatabase): PaymentDao = db.paymentDao()
    @Provides fun provideAllocationDao(db: DpmDatabase): AllocationDao = db.allocationDao()
    @Provides fun provideMovementDao(db: DpmDatabase): MovementDao = db.movementDao()
    @Provides fun provideCashDao(db: DpmDatabase): CashDao = db.cashDao()
    @Provides fun provideAuditDao(db: DpmDatabase): AuditDao = db.auditDao()
    @Provides fun provideDashboardDao(db: DpmDatabase): DashboardDao = db.dashboardDao()
}
