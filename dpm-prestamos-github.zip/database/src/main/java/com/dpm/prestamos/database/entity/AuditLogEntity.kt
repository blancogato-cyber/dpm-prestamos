package com.dpm.prestamos.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.dpm.prestamos.domain.enums.AuditAction
import java.time.LocalDateTime

@Entity(
    tableName = "audit_log",
    indices = [Index(value = ["entityType", "entityId", "timestamp"]), Index("action")]
)
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val action: AuditAction,
    val entityType: String,
    val entityId: String,
    val timestamp: LocalDateTime,
    val actor: String? = null,
    val details: String? = null,
    val reason: String? = null
)
