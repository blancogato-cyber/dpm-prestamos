package com.dpm.prestamos.database.dao

import androidx.room.Dao
import androidx.room.Query
import com.dpm.prestamos.domain.enums.LoanStatus

@Dao
interface DashboardDao {
    @Query("SELECT COUNT(*) FROM loans WHERE status = :status")
    suspend fun countLoansByStatus(status: LoanStatus): Int

    @Query("SELECT COUNT(*) FROM loans WHERE status IN (:statuses)")
    suspend fun countLoansByStatuses(statuses: List<LoanStatus>): Int

    @Query("SELECT COALESCE(SUM(CAST(principalOutstanding AS REAL)), 0) FROM loans WHERE status NOT IN ('LIQUIDADO','CANCELADO')")
    suspend fun sumPrincipalOutstandingActive(): Double

    @Query("SELECT COALESCE(SUM(CAST(interestOutstanding AS REAL)), 0) FROM loans WHERE status NOT IN ('LIQUIDADO','CANCELADO')")
    suspend fun sumInterestOutstandingActive(): Double

    @Query("SELECT COALESCE(SUM(CAST(totalBalance AS REAL)), 0) FROM loans WHERE status NOT IN ('LIQUIDADO','CANCELADO')")
    suspend fun sumTotalToRecover(): Double

    @Query("SELECT COALESCE(SUM(CAST(interestPaid AS REAL)), 0) FROM loans")
    suspend fun sumInterestCollected(): Double

    @Query("SELECT COALESCE(SUM(CAST(totalPaid AS REAL)), 0) FROM loans")
    suspend fun sumMoneyRecovered(): Double

    @Query("SELECT COUNT(*) FROM payments WHERE status = 'APLICADO' AND date(paidAt/1000,'unixepoch','localtime') = date('now','localtime')")
    suspend fun countPaymentsToday(): Int

    @Query("SELECT COALESCE(SUM(CAST(principalOriginal AS REAL)), 0) FROM loans WHERE status != 'CANCELADO'")
    suspend fun sumCapitalDisbursed(): Double

    @Query("SELECT COALESCE(SUM(CAST(interestGenerated AS REAL)), 0) FROM loans WHERE status != 'CANCELADO'")
    suspend fun sumInterestGenerated(): Double

    @Query("SELECT COUNT(*) FROM loans WHERE status = 'LIQUIDADO'")
    suspend fun countSettledLoans(): Int
}
