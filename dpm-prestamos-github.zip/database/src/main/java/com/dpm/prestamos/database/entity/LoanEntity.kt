package com.dpm.prestamos.database.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.domain.enums.AccrualMode
import com.dpm.prestamos.domain.enums.InterestMethod
import com.dpm.prestamos.domain.enums.LoanStatus
import com.dpm.prestamos.domain.enums.PaymentMode
import com.dpm.prestamos.domain.enums.TermType
import java.time.LocalDate

@Entity(
    tableName = "loans",
    foreignKeys = [
        ForeignKey(
            entity = ClientEntity::class,
            parentColumns = ["id"],
            childColumns = ["clientId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [
        Index(value = ["loanNumber"], unique = true),
        Index(value = ["clientId"]),
        Index(value = ["status"]),
        Index(value = ["dueDate"]),
        Index(value = ["disbursementDate"]),
        Index(value = ["status", "dueDate"])
    ]
)
data class LoanEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val clientId: Long,
    val loanNumber: String,
    val principalOriginal: Money,
    val principalOutstanding: Money,
    val interestRatePercent: String, // BigDecimal as string
    val interestMethod: InterestMethod,
    val accrualMode: AccrualMode,
    val defaultPaymentMode: PaymentMode,
    val termType: TermType,
    val termDays: Int,
    val disbursementDate: LocalDate,
    val dueDate: LocalDate,
    val status: LoanStatus,
    val interestGenerated: Money,
    val interestPaid: Money,
    val interestOutstanding: Money,
    val totalPaid: Money,
    val totalBalance: Money,
    val gracePeriodDays: Int = 0,
    val lateFeeEnabled: Boolean = false,
    val parentLoanId: Long? = null,
    val periodsCharged: Int = 0,
    val notes: String? = null,
    val createdAt: LocalDate,
    val updatedAt: LocalDate
)
