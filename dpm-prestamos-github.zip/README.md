# DPM - Gestión profesional de préstamos

Aplicación Android (Kotlin + Jetpack Compose + Material 3) para administración de préstamos personales con intereses. **100% offline**, moneda RD$, zona horaria `America/Santo_Domingo`.

## Estado del proyecto
Implementación funcional a nivel de código (requiere compilación/pruebas en entorno con Android SDK):
- Arquitectura multi-módulo (app, core, database, domain, data, features) y documentación técnica/usuario.
- Núcleo de dominio: `Money` (BigDecimal), modelos/enums y **motor financiero** (interés simple, devengo completo/proporcional, base capital inicial/pendiente, asignación automática/manual, excedentes, liquidación, estados y períodos).
- Datos: Room v2 (`dpm.db`) con migración explícita `1→2`, repositorios y transacciones atómicas (pagos/liquidaciones/anulaciones, renovación/refinanciamiento, caja) con auditoría.
- UI/funcionalidad: dashboard, clientes + perfil financiero, préstamos/filtros/detalle, pagos y abonos, contabilidad, caja, calendario (día/semana/mes, mora/gracia), búsqueda global, reportes/exportación PDF/CSV, recibos PDF compartibles, recordatorios (WorkManager + permiso), seguridad (PIN/bloqueo), respaldos cifrados con integridad y configuración.

**Pendiente para entrega verificada**: ejecutar suite de pruebas (incl. 15 escenarios) y técnicas en dispositivo/emulador, corregir hallazgos de runtime/UI, biometría/auto-bloqueo avanzado, selector SAF de respaldos y generar APK instalable. Ver `docs/informe-pruebas.md`.

## Compilación
Ver `docs/guia-compilacion.md`. Requiere JDK 17 y Android SDK (compileSdk 35, minSdk 26).

### Compilar con GitHub Actions
El repositorio incluye el workflow `.github/workflows/android-build.yml`:
1. Sube el proyecto a GitHub.
2. En **Actions → Android Build**, ejecuta **Run workflow** (o haz push/PR).
3. Descarga el artefacto **`dpm-debug-apk`** (`app/build/outputs/apk/debug/*.apk`).
4. Instala en Android: `adb install -r app-debug.apk` (con depuración USB y dispositivo autorizado).

Configura `local.properties` (ver `local.properties.example`) para builds locales. Compilación local/CI requiere acceso a dependencias en `google()`/`mavenCentral()`.

## Documentación
- `docs/reglas-financieras.md`
- `docs/guia-compilacion.md`
- `docs/guia-usuario.md`
- `docs/informe-pruebas.md`
