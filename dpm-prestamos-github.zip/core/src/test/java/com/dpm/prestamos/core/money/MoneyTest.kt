package com.dpm.prestamos.core.money

import com.google.common.truth.Truth.assertThat
import org.junit.Test
import java.math.BigDecimal

class MoneyTest {
    @Test fun `operaciones basicas`() {
        val a = Money.of("1000.00")
        val b = Money.of("250.50")
        assertThat((a + b).toPlainString()).isEqualTo("1250.50")
        assertThat((a - b).toPlainString()).isEqualTo("749.50")
    }
    @Test fun `porcentaje`() {
        val interest = Money.of("10000.00").percentage(BigDecimal("20"))
        assertThat(interest).isEqualTo(Money.of("2000.00"))
    }
}
