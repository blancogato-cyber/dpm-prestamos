package com.dpm.prestamos.core.datetime

import java.time.Clock
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId

class AppClock(
    private val clock: Clock = Clock.system(ZoneId.of("America/Santo_Domingo"))
) {
    fun today(): LocalDate = LocalDate.now(clock)
    fun now(): LocalDateTime = LocalDateTime.now(clock)
    fun zone(): ZoneId = clock.zone
    fun instant() = clock.instant()

    companion object {
        val SYSTEM: AppClock = AppClock()
    }
}
