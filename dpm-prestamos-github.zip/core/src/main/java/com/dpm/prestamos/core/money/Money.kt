package com.dpm.prestamos.core.money

import java.math.BigDecimal
import java.math.RoundingMode

/**
 * Immutable monetary value backed by BigDecimal for exact financial calculations.
 * Scale and rounding are centralized to avoid precision errors.
 */
@JvmInline
value class Money(val amount: BigDecimal) : Comparable<Money> {

    init {
        require(amount.scale() <= SCALE) { "Money scale must be <= $SCALE" }
    }

    operator fun plus(other: Money): Money = Money(amount.add(other.amount).setScale(SCALE, ROUNDING))
    operator fun minus(other: Money): Money = Money(amount.subtract(other.amount).setScale(SCALE, ROUNDING))
    operator fun times(multiplier: BigDecimal): Money = Money(amount.multiply(multiplier).setScale(SCALE, ROUNDING))
    operator fun times(multiplier: Int): Money = times(BigDecimal(multiplier))
    operator fun div(divisor: BigDecimal): Money = Money(amount.divide(divisor, SCALE, ROUNDING))
    operator fun unaryMinus(): Money = Money(amount.negate().setScale(SCALE, ROUNDING))

    fun isZero(): Boolean = amount.compareTo(BigDecimal.ZERO) == 0
    fun isPositive(): Boolean = amount > BigDecimal.ZERO
    fun isNegative(): Boolean = amount < BigDecimal.ZERO
    fun isPositiveOrZero(): Boolean = amount >= BigDecimal.ZERO

    fun min(other: Money): Money = if (this <= other) this else other
    fun max(other: Money): Money = if (this >= other) this else other
    fun abs(): Money = Money(amount.abs().setScale(SCALE, ROUNDING))

    fun percentage(percent: BigDecimal): Money = this * percent.divide(BigDecimal(100), 10, ROUNDING)

    override fun compareTo(other: Money): Int = amount.compareTo(other.amount)

    fun toPlainString(): String = amount.setScale(SCALE, ROUNDING).toPlainString()

    companion object {
        const val SCALE: Int = 2
        val ROUNDING: RoundingMode = RoundingMode.HALF_EVEN
        val ZERO: Money = Money(BigDecimal.ZERO.setScale(SCALE, ROUNDING))

        fun of(value: String): Money = Money(BigDecimal(value).setScale(SCALE, ROUNDING))
        fun of(value: Long): Money = Money(BigDecimal(value).setScale(SCALE, ROUNDING))
        fun of(value: Double): Money = Money(BigDecimal.valueOf(value).setScale(SCALE, ROUNDING))
        fun ofExact(value: BigDecimal): Money = Money(value.setScale(SCALE, ROUNDING))
    }
}
