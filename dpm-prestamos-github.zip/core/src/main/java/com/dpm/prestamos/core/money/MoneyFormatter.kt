package com.dpm.prestamos.core.money

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

object MoneyFormatter {
    private val symbols = DecimalFormatSymbols(Locale("es", "DO")).apply {
        currencySymbol = "RD$"
        groupingSeparator = ','
        decimalSeparator = '.'
    }
    private val format = DecimalFormat("RD$ #,##0.00", symbols)

    fun format(money: Money): String = format.format(money.amount)
}
