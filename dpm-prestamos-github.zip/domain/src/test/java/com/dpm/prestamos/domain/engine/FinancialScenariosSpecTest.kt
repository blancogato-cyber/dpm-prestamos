package com.dpm.prestamos.domain.engine

import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.domain.enums.AccrualMode
import com.dpm.prestamos.domain.enums.InterestMethod
import com.google.common.truth.Truth.assertThat
import org.junit.Test
import java.math.BigDecimal

/**
 * Cobertura de escenarios financieros solicitados (PROMPT 8) a nivel de motor.
 * Los escenarios que involucran persistencia/transacciones se validan en integración Room.
 */
class FinancialScenariosSpecTest {

    @Test fun `1 prestamo sin intereses`() {
        val i = InterestCalculator.calculateInterest(Money.of("5000"), Money.of("5000"), BigDecimal.ZERO, InterestMethod.CAPITAL_PENDIENTE, AccrualMode.PERIODO_COMPLETO, 1, 0, 30)
        assertThat(i).isEqualTo(Money.ZERO)
    }

    @Test fun `2 prestamo con 10 porciento`() {
        val i = InterestCalculator.calculateInterest(Money.of("10000"), Money.of("10000"), BigDecimal("10"), InterestMethod.CAPITAL_INICIAL, AccrualMode.PERIODO_COMPLETO, 1, 0, 30)
        assertThat(i).isEqualTo(Money.of("1000.00"))
    }

    @Test fun `3 prestamo con 20 porciento`() {
        val i = InterestCalculator.calculateInterest(Money.of("10000"), Money.of("10000"), BigDecimal("20"), InterestMethod.CAPITAL_INICIAL, AccrualMode.PERIODO_COMPLETO, 1, 0, 30)
        assertThat(i).isEqualTo(Money.of("2000.00"))
    }

    @Test fun `4 y 5 plazos 15 y 30 dias - proporcional coherente`() {
        val i15 = InterestCalculator.calculateInterest(Money.of("10000"), Money.of("10000"), BigDecimal("20"), InterestMethod.CAPITAL_INICIAL, AccrualMode.PROPORCIONAL_DIAS, 0, 15, 15)
        val i30 = InterestCalculator.calculateInterest(Money.of("10000"), Money.of("10000"), BigDecimal("20"), InterestMethod.CAPITAL_INICIAL, AccrualMode.PROPORCIONAL_DIAS, 0, 30, 30)
        assertThat(i15).isEqualTo(Money.of("2000.00"))
        assertThat(i30).isEqualTo(Money.of("2000.00"))
    }

    @Test fun `6 pago exclusivo de intereses`() {
        val r = PaymentAllocator.automatic(PaymentAllocator.AllocationInput(Money.of("2000"), Money.of("2000"), Money.ZERO, Money.of("10000"))) as PaymentAllocator.AllocationResult.Ok
        assertThat(r.distribution.toPrincipal).isEqualTo(Money.ZERO)
        assertThat(r.distribution.toInterest).isEqualTo(Money.of("2000.00"))
    }

    @Test fun `7 abono parcial de capital`() {
        val r = PaymentAllocator.manual(Money.of("3000"), toInterest = Money.of("1000"), toPrincipal = Money.of("2000"), interestOutstanding = Money.of("2000"), principalOutstanding = Money.of("10000")) as PaymentAllocator.AllocationResult.Ok
        assertThat(r.distribution.toPrincipal).isEqualTo(Money.of("2000.00"))
    }

    @Test fun `8 pago combinado`() {
        val r = PaymentAllocator.automatic(PaymentAllocator.AllocationInput(Money.of("5000"), Money.of("2000"), Money.ZERO, Money.of("10000"))) as PaymentAllocator.AllocationResult.Ok
        assertThat(r.distribution.toInterest).isEqualTo(Money.of("2000.00"))
        assertThat(r.distribution.toPrincipal).isEqualTo(Money.of("3000.00"))
    }

    @Test fun `9 liquidacion completa`() {
        val s = SettlementCalculator.settle(Money.of("10000"), Money.of("2000"))
        assertThat(s.total).isEqualTo(Money.of("12000.00"))
    }

    @Test fun `10 liquidacion anticipada con devengado`() {
        val s = SettlementCalculator.settle(Money.of("8000"), Money.of("500"))
        assertThat(s.total).isEqualTo(Money.of("8500.00"))
    }

    @Test fun `14 pagos consecutivos no duplican periodo`() {
        val p1 = PeriodTracker.periodsDue(1, 0)
        val p2 = PeriodTracker.periodsDue(1, p1.newPeriodsCharged)
        assertThat(p1.periodsToCharge).isEqualTo(1)
        assertThat(p2.periodsToCharge).isEqualTo(0)
    }

    @Test fun `15 pagos en diferentes periodos - interes sobre capital pendiente cambia base`() {
        val i1 = InterestCalculator.calculateInterest(Money.of("10000"), Money.of("10000"), BigDecimal("20"), InterestMethod.CAPITAL_PENDIENTE, AccrualMode.PERIODO_COMPLETO, 1, 0, 30)
        // tras abono de 2000 a capital
        val i2 = InterestCalculator.calculateInterest(Money.of("10000"), Money.of("8000"), BigDecimal("20"), InterestMethod.CAPITAL_PENDIENTE, AccrualMode.PERIODO_COMPLETO, 1, 0, 30)
        assertThat(i1).isEqualTo(Money.of("2000.00"))
        assertThat(i2).isEqualTo(Money.of("1600.00"))
    }
}
