package com.dpm.prestamos.domain.engine

import com.dpm.prestamos.core.money.Money
import com.google.common.truth.Truth.assertThat
import org.junit.Test

class PaymentAllocatorTest {

    @Test
    fun `automatico cubre primero intereses y luego capital`() {
        val result = PaymentAllocator.automatic(
            PaymentAllocator.AllocationInput(
                amount = Money.of("3000.00"),
                interestOutstanding = Money.of("2000.00"),
                principalOutstanding = Money.of("10000.00")
            )
        )
        assertThat(result).isInstanceOf(PaymentAllocator.AllocationResult.Ok::class.java)
        val dist = (result as PaymentAllocator.AllocationResult.Ok).distribution
        assertThat(dist.toInterest).isEqualTo(Money.of("2000.00"))
        assertThat(dist.toPrincipal).isEqualTo(Money.of("1000.00"))
        assertThat(dist.surplus).isEqualTo(Money.ZERO)
    }

    @Test
    fun `pago solo intereses deja capital intacto`() {
        val result = PaymentAllocator.automatic(
            PaymentAllocator.AllocationInput(
                amount = Money.of("2000.00"),
                interestOutstanding = Money.of("2000.00"),
                principalOutstanding = Money.of("10000.00")
            )
        )
        val dist = (result as PaymentAllocator.AllocationResult.Ok).distribution
        assertThat(dist.toInterest).isEqualTo(Money.of("2000.00"))
        assertThat(dist.toPrincipal).isEqualTo(Money.ZERO)
    }

    @Test
    fun `excedente sin autorizacion requiere confirmacion`() {
        val result = PaymentAllocator.automatic(
            PaymentAllocator.AllocationInput(
                amount = Money.of("13000.00"),
                interestOutstanding = Money.of("2000.00"),
                principalOutstanding = Money.of("10000.00"),
                allowSurplus = false
            )
        )
        assertThat(result).isInstanceOf(PaymentAllocator.AllocationResult.RequiresSurplusConfirmation::class.java)
    }

    @Test
    fun `excedente autorizado se registra`() {
        val result = PaymentAllocator.automatic(
            PaymentAllocator.AllocationInput(
                amount = Money.of("13000.00"),
                interestOutstanding = Money.of("2000.00"),
                principalOutstanding = Money.of("10000.00"),
                allowSurplus = true
            )
        )
        val dist = (result as PaymentAllocator.AllocationResult.Ok).distribution
        assertThat(dist.surplus).isEqualTo(Money.of("1000.00"))
        assertThat(dist.toPrincipal).isEqualTo(Money.of("10000.00"))
    }
}
