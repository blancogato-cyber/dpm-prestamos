package com.dpm.prestamos.domain.engine

import com.dpm.prestamos.domain.enums.LoanStatus
import com.google.common.truth.Truth.assertThat
import org.junit.Test
import java.time.LocalDate

class LoanStateMachineTest {
    @Test fun `saldo cero es liquidado`() {
        val s = LoanStateMachine.deriveStatus(LoanStatus.ACTIVO, LocalDate.now(), LocalDate.now(), true)
        assertThat(s).isEqualTo(LoanStatus.LIQUIDADO)
    }
    @Test fun `despues de vencimiento con gracia es vencido`() {
        val due = LocalDate.of(2026,1,1)
        val s = LoanStateMachine.deriveStatus(LoanStatus.ACTIVO, due, LocalDate.of(2026,1,10), false, gracePeriodDays = 3)
        assertThat(s).isEqualTo(LoanStatus.VENCIDO)
    }
    @Test fun `proximo a vencer`() {
        val today = LocalDate.of(2026,1,1)
        val s = LoanStateMachine.deriveStatus(LoanStatus.ACTIVO, LocalDate.of(2026,1,3), today, false, 0, 3)
        assertThat(s).isEqualTo(LoanStatus.PROXIMO_VENCER)
    }
}
