package com.dpm.prestamos.domain.engine

import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.domain.enums.AccrualMode
import com.dpm.prestamos.domain.enums.InterestMethod
import com.google.common.truth.Truth.assertThat
import org.junit.Test
import java.math.BigDecimal

class InterestCalculatorTest {

    @Test
    fun `ejemplo spec - 10000 al 20 porciento por 30 dias genera 2000`() {
        val interest = InterestCalculator.calculateInterest(
            principalOriginal = Money.of("10000.00"),
            principalOutstanding = Money.of("10000.00"),
            ratePercent = BigDecimal("20"),
            method = InterestMethod.CAPITAL_INICIAL,
            accrualMode = AccrualMode.PERIODO_COMPLETO,
            periods = 1,
            termDays = 30
        )
        assertThat(interest).isEqualTo(Money.of("2000.00"))
    }

    @Test
    fun `capital pendiente usa saldo vigente - tras abono 2000 base es 8000`() {
        val interest = InterestCalculator.calculateInterest(
            principalOriginal = Money.of("10000.00"),
            principalOutstanding = Money.of("8000.00"),
            ratePercent = BigDecimal("20"),
            method = InterestMethod.CAPITAL_PENDIENTE,
            accrualMode = AccrualMode.PERIODO_COMPLETO,
            periods = 1,
            termDays = 30
        )
        assertThat(interest).isEqualTo(Money.of("1600.00"))
    }

    @Test
    fun `capital inicial mantiene base original aunque haya abonos`() {
        val interest = InterestCalculator.calculateInterest(
            principalOriginal = Money.of("10000.00"),
            principalOutstanding = Money.of("8000.00"),
            ratePercent = BigDecimal("20"),
            method = InterestMethod.CAPITAL_INICIAL,
            accrualMode = AccrualMode.PERIODO_COMPLETO,
            periods = 1,
            termDays = 30
        )
        assertThat(interest).isEqualTo(Money.of("2000.00"))
    }

    @Test
    fun `prestamo sin intereses`() {
        val interest = InterestCalculator.calculateInterest(
            principalOriginal = Money.of("10000.00"),
            principalOutstanding = Money.of("10000.00"),
            ratePercent = BigDecimal("0"),
            method = InterestMethod.CAPITAL_PENDIENTE,
            accrualMode = AccrualMode.PERIODO_COMPLETO,
            periods = 1,
            termDays = 30
        )
        assertThat(interest).isEqualTo(Money.ZERO)
    }

    @Test
    fun `devengo proporcional a dias`() {
        val interest = InterestCalculator.calculateInterest(
            principalOriginal = Money.of("10000.00"),
            principalOutstanding = Money.of("10000.00"),
            ratePercent = BigDecimal("20"),
            method = InterestMethod.CAPITAL_INICIAL,
            accrualMode = AccrualMode.PROPORCIONAL_DIAS,
            periods = 0,
            daysElapsed = 15,
            termDays = 30
        )
        assertThat(interest).isEqualTo(Money.of("1000.00"))
    }
}
