package com.dpm.prestamos.domain.engine

import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.domain.enums.AccrualMode
import com.dpm.prestamos.domain.enums.InterestMethod
import com.google.common.truth.Truth.assertThat
import org.junit.Test
import java.math.BigDecimal

class AmortizationAndSettlementTest {

    @Test
    fun `quote 10000 al 20 porciento total 12000`() {
        val q = AmortizationSimulator.quoteLoan(
            principal = Money.of("10000.00"),
            ratePercent = BigDecimal("20"),
            termDays = 30,
            method = InterestMethod.CAPITAL_INICIAL,
            accrualMode = AccrualMode.PERIODO_COMPLETO
        )
        assertThat(q.interest).isEqualTo(Money.of("2000.00"))
        assertThat(q.total).isEqualTo(Money.of("12000.00"))
    }

    @Test
    fun `abono 20 porciento de 10000 deja 8000`() {
        val d = AmortizationSimulator.calculateDownPayment(Money.of("10000.00"), 20)
        assertThat(d.amount).isEqualTo(Money.of("2000.00"))
        assertThat(d.newPrincipalOutstanding).isEqualTo(Money.of("8000.00"))
    }

    @Test
    fun `liquidacion anticipada suma capital e interes devengado`() {
        val s = SettlementCalculator.settle(
            principalOutstanding = Money.of("8000.00"),
            interestAccruedUnpaid = Money.of("1600.00"),
            fees = Money.ZERO,
            discounts = Money.ZERO
        )
        assertThat(s.total).isEqualTo(Money.of("9600.00"))
    }

    @Test
    fun `period tracker evita duplicar periodos`() {
        val r = PeriodTracker.periodsDue(totalPeriodsElapsed = 2, periodsCharged = 1)
        assertThat(r.periodsToCharge).isEqualTo(1)
        assertThat(r.newPeriodsCharged).isEqualTo(2)
        val r2 = PeriodTracker.periodsDue(totalPeriodsElapsed = 2, periodsCharged = 2)
        assertThat(r2.periodsToCharge).isEqualTo(0)
    }
}
