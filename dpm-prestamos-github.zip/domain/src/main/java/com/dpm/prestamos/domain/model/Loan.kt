package com.dpm.prestamos.domain.model

import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.domain.enums.AccrualMode
import com.dpm.prestamos.domain.enums.InterestMethod
import com.dpm.prestamos.domain.enums.LoanStatus
import com.dpm.prestamos.domain.enums.PaymentMode
import com.dpm.prestamos.domain.enums.TermType
import java.time.LocalDate

data class Loan(
    val id: Long = 0,
    val clientId: Long,
    val loanNumber: String,
    val principalOriginal: Money,
    val principalOutstanding: Money,
    val interestRatePercent: java.math.BigDecimal, // tasa por período
    val interestMethod: InterestMethod,
    val accrualMode: AccrualMode,
    val defaultPaymentMode: PaymentMode,
    val termType: TermType,
    val termDays: Int,
    val disbursementDate: LocalDate,
    val dueDate: LocalDate,
    val status: LoanStatus,
    val interestGenerated: Money,
    val interestPaid: Money,
    val interestOutstanding: Money,
    val totalPaid: Money,
    val totalBalance: Money,
    val gracePeriodDays: Int = 0,
    val lateFeeEnabled: Boolean = false,
    val parentLoanId: Long? = null,
    val notes: String? = null,
    val periodsCharged: Int = 0 // períodos ya cobrados/generados (control PeriodTracker)
) {
    val interestBase: Money
        get() = when (interestMethod) {
            InterestMethod.CAPITAL_INICIAL -> principalOriginal
            InterestMethod.CAPITAL_PENDIENTE -> principalOutstanding
        }
}
