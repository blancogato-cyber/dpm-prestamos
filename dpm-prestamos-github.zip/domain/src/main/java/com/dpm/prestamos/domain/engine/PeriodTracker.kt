package com.dpm.prestamos.domain.engine

/**
 * Controla períodos cobrados/generados para evitar duplicar el cobro de un mismo período.
 * periodsCharged representa cuántos períodos completos ya fueron reconocidos en el préstamo.
 */
object PeriodTracker {

    data class AccrualResult(
        val periodsToCharge: Int,
        val newPeriodsCharged: Int
    )

    /**
     * Calcula cuántos períodos nuevos deben generarse dado el total de períodos transcurridos
     * desde el inicio (o desde el último hito) y los ya cobrados.
     */
    fun periodsDue(totalPeriodsElapsed: Int, periodsCharged: Int): AccrualResult {
        require(totalPeriodsElapsed >= 0 && periodsCharged >= 0)
        val due = (totalPeriodsElapsed - periodsCharged).coerceAtLeast(0)
        return AccrualResult(periodsToCharge = due, newPeriodsCharged = periodsCharged + due)
    }

    fun elapsedPeriods(daysElapsed: Int, termDays: Int): Int {
        require(termDays > 0)
        if (daysElapsed <= 0) return 0
        return daysElapsed / termDays
    }
}
