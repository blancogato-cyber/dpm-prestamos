package com.dpm.prestamos.domain.engine

import com.dpm.prestamos.core.money.Money

object SettlementCalculator {

    data class Settlement(
        val principalOutstanding: Money,
        val interestAccruedUnpaid: Money,
        val fees: Money,
        val discounts: Money,
        val total: Money
    ) {
        init { require(total.isPositiveOrZero()) }
    }

    /**
     * Calcula el total de liquidación anticipada. Cargos y descuentos deben estar
     * fundamentados/configurados; no se aplican retroactivamente sin registro.
     */
    fun settle(
        principalOutstanding: Money,
        interestAccruedUnpaid: Money,
        fees: Money = Money.ZERO,
        discounts: Money = Money.ZERO
    ): Settlement {
        require(discounts <= principalOutstanding + interestAccruedUnpaid + fees) {
            "El descuento no puede exceder el saldo adeudado"
        }
        val gross = principalOutstanding + interestAccruedUnpaid + fees
        val total = (gross - discounts).let { if (it.isNegative()) Money.ZERO else it }
        return Settlement(
            principalOutstanding = principalOutstanding,
            interestAccruedUnpaid = interestAccruedUnpaid,
            fees = fees,
            discounts = discounts,
            total = total
        )
    }
}
