package com.dpm.prestamos.domain.engine

import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.domain.enums.AccrualMode
import com.dpm.prestamos.domain.enums.InterestMethod
import java.math.BigDecimal

object AmortizationSimulator {

    data class LoanQuote(
        val principal: Money,
        val interest: Money,
        val total: Money,
        val baseUsed: Money
    )

    fun quoteLoan(
        principal: Money,
        ratePercent: BigDecimal,
        termDays: Int,
        method: InterestMethod,
        accrualMode: AccrualMode,
        periods: Int = 1
    ): LoanQuote {
        val interest = InterestCalculator.calculateInterest(
            principalOriginal = principal,
            principalOutstanding = principal,
            ratePercent = ratePercent,
            method = method,
            accrualMode = accrualMode,
            periods = periods,
            termDays = termDays
        )
        val base = InterestCalculator.resolveBase(method, principal, principal)
        return LoanQuote(principal = principal, interest = interest, total = principal + interest, baseUsed = base)
    }

    data class DownPayment(
        val percent: Int,
        val amount: Money,
        val newPrincipalOutstanding: Money
    )

    fun calculateDownPayment(principalOutstanding: Money, percent: Int): DownPayment {
        require(percent in 0..100) { "El porcentaje debe estar entre 0 y 100" }
        val amount = principalOutstanding.percentage(BigDecimal(percent))
        return DownPayment(percent, amount, principalOutstanding - amount)
    }

    fun calculateCustomDownPayment(principalOutstanding: Money, amount: Money): DownPayment {
        require(amount.isPositiveOrZero() && amount <= principalOutstanding) { "Monto de abono inválido" }
        val pct = if (principalOutstanding.isZero()) 0 else
            amount.amount.multiply(BigDecimal(100)).divide(principalOutstanding.amount, 2, java.math.RoundingMode.HALF_EVEN).toInt()
        return DownPayment(pct, amount, principalOutstanding - amount)
    }
}
