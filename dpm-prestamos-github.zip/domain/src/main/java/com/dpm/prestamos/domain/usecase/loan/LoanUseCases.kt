package com.dpm.prestamos.domain.usecase.loan

import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.domain.engine.InterestCalculator
import com.dpm.prestamos.domain.enums.AccrualMode
import com.dpm.prestamos.domain.enums.LoanStatus
import com.dpm.prestamos.domain.model.Loan
import com.dpm.prestamos.domain.repository.LoanRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class CreateLoanUseCase @Inject constructor(private val repository: LoanRepository) {
    suspend operator fun invoke(draft: Loan): Long {
        require(draft.principalOriginal.isPositive()) { "El monto del préstamo debe ser mayor a cero" }
        val initialInterest = InterestCalculator.calculateInterest(
            principalOriginal = draft.principalOriginal,
            principalOutstanding = draft.principalOriginal,
            ratePercent = draft.interestRatePercent,
            method = draft.interestMethod,
            accrualMode = draft.accrualMode,
            periods = if (draft.accrualMode == AccrualMode.PERIODO_COMPLETO) 1 else 0,
            daysElapsed = draft.termDays,
            termDays = draft.termDays
        )
        val loan = draft.copy(
            loanNumber = if (draft.loanNumber.isBlank()) repository.nextLoanNumber() else draft.loanNumber,
            principalOutstanding = draft.principalOriginal,
            interestGenerated = initialInterest,
            interestPaid = Money.ZERO,
            interestOutstanding = initialInterest,
            totalPaid = Money.ZERO,
            totalBalance = draft.principalOriginal + initialInterest,
            status = LoanStatus.ACTIVO,
            periodsCharged = if (draft.accrualMode == AccrualMode.PERIODO_COMPLETO) 1 else 0
        )
        return repository.save(loan)
    }
}

class ObserveLoansUseCase @Inject constructor(private val repository: LoanRepository) {
    operator fun invoke(): Flow<List<Loan>> = repository.observeAll()
}

class ObserveLoanUseCase @Inject constructor(private val repository: LoanRepository) {
    operator fun invoke(id: Long): Flow<Loan?> = repository.observeById(id)
}
