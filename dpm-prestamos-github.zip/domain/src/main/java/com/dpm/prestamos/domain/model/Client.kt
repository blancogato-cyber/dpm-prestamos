package com.dpm.prestamos.domain.model

import java.time.LocalDate

data class Client(
    val id: Long = 0,
    val fullName: String,
    val phone: String,
    val address: String? = null,
    val documentId: String? = null,
    val photoUri: String? = null,
    val notes: String? = null,
    val createdAt: LocalDate,
    val isActive: Boolean = true
)
