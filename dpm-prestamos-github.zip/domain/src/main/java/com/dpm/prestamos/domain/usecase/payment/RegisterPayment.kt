package com.dpm.prestamos.domain.usecase.payment

import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.domain.enums.DistributionMode
import com.dpm.prestamos.domain.enums.PaymentMethod
import com.dpm.prestamos.domain.model.Loan
import java.time.LocalDate
import java.time.LocalDateTime

sealed interface RegisterPaymentResult {
    data class Success(val paymentId: Long, val receiptNumber: String = "") : RegisterPaymentResult
    data class NeedsSurplusConfirmation(val surplus: Money) : RegisterPaymentResult
    data class Error(val message: String) : RegisterPaymentResult
}

interface PaymentRegistrar {
    suspend fun register(
        loan: Loan,
        amount: Money,
        method: PaymentMethod,
        distributionMode: DistributionMode,
        allowSurplus: Boolean = false,
        manualToInterest: Money? = null,
        manualToPrincipal: Money? = null,
        notes: String? = null,
        paidAt: LocalDateTime = LocalDateTime.now(),
        today: LocalDate = LocalDate.now()
    ): RegisterPaymentResult

    suspend fun void(paymentId: Long, reason: String): RegisterPaymentResult

    suspend fun settle(
        loan: Loan,
        interestAccruedUnpaid: Money,
        fees: Money = Money.ZERO,
        discount: Money = Money.ZERO,
        method: PaymentMethod = PaymentMethod.EFECTIVO,
        notes: String? = null,
        now: LocalDateTime = LocalDateTime.now(),
        today: LocalDate = LocalDate.now()
    ): RegisterPaymentResult
}
