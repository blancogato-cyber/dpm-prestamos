package com.dpm.prestamos.domain.usecase.client

import com.dpm.prestamos.domain.model.Client
import com.dpm.prestamos.domain.repository.ClientRepository
import javax.inject.Inject

class CreateClientUseCase @Inject constructor(private val repository: ClientRepository) {
    sealed interface Result {
        data class Success(val id: Long) : Result
        data class Duplicate(val message: String) : Result
        data class Invalid(val message: String) : Result
    }

    suspend operator fun invoke(client: Client): Result {
        if (client.fullName.isBlank()) return Result.Invalid("El nombre es obligatorio")
        if (client.phone.isBlank()) return Result.Invalid("El teléfono es obligatorio")
        if (repository.isPossibleDuplicate(client.fullName, client.phone, client.id.takeIf { it != 0L })) {
            return Result.Duplicate("Ya existe un cliente con nombre y teléfono similares")
        }
        return Result.Success(repository.save(client))
    }
}
