package com.dpm.prestamos.domain.model

import com.dpm.prestamos.core.money.Money
import java.time.LocalDate

data class ClientProfile(
    val client: Client,
    val totalHistoricLent: Money,
    val totalHistoricRecovered: Money,
    val interestPaid: Money,
    val currentDebt: Money,
    val activeLoans: Int,
    val overdueLoans: Int,
    val settledLoans: Int,
    val lastPaymentDate: LocalDate? = null
)
