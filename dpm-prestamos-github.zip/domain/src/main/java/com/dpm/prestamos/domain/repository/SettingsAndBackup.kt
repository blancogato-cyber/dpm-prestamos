package com.dpm.prestamos.domain.repository

import kotlinx.coroutines.flow.Flow

data class AppSettings(
    val defaultRatePercent: String = "20",
    val defaultTermDays: Int = 30,
    val gracePeriodDays: Int = 0,
    val upcomingDays: Int = 3,
    val remindersEnabled: Boolean = false,
    val biometricEnabled: Boolean = false,
    val autoLockMinutes: Int = 2,
    val autoBackupEnabled: Boolean = false
)

interface SettingsRepository {
    val settings: Flow<AppSettings>
    suspend fun update(transform: (AppSettings) -> AppSettings)
}

interface BackupRepository {
    suspend fun exportBackup(password: String): Result<String> // file path
    suspend fun restoreBackup(filePath: String, password: String): Result<Unit>
}

interface SecurityRepository {
    suspend fun hasPin(): Boolean
    suspend fun setPin(pin: String)
    suspend fun verifyPin(pin: String): Boolean
    suspend fun clearPin()
    suspend fun setBackupPassphrase(passphrase: String)
    suspend fun getBackupPassphrase(): String?
    suspend fun clearBackupPassphrase()
}
