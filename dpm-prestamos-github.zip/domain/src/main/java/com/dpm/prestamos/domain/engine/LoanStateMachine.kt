package com.dpm.prestamos.domain.engine

import com.dpm.prestamos.domain.enums.LoanStatus
import java.time.LocalDate

object LoanStateMachine {

    /**
     * Deriva estado operativo según fechas y saldos (no aplica transiciones terminales manuales
     * como CANCELADO/REESTRUCTURADO, que son explícitas).
     */
    fun deriveStatus(
        current: LoanStatus,
        dueDate: LocalDate,
        today: LocalDate,
        totalBalanceIsZero: Boolean,
        gracePeriodDays: Int = 0,
        daysBeforeDueToFlag: Int = 3
    ): LoanStatus {
        if (current == LoanStatus.CANCELADO || current == LoanStatus.REESTRUCTURADO) return current
        if (totalBalanceIsZero) return LoanStatus.LIQUIDADO
        val effectiveDue = dueDate.plusDays(gracePeriodDays.toLong())
        return when {
            today.isAfter(effectiveDue) -> LoanStatus.VENCIDO
            !today.isBefore(dueDate.minusDays(daysBeforeDueToFlag.toLong())) -> LoanStatus.PROXIMO_VENCER
            else -> LoanStatus.ACTIVO
        }
    }

    fun canRegisterPayment(status: LoanStatus): Boolean =
        status != LoanStatus.CANCELADO && status != LoanStatus.REESTRUCTURADO

    fun canRenewOrRefinance(status: LoanStatus): Boolean =
        status == LoanStatus.ACTIVO || status == LoanStatus.PROXIMO_VENCER || status == LoanStatus.VENCIDO
}
