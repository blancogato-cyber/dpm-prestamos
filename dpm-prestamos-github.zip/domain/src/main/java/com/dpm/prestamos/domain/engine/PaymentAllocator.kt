package com.dpm.prestamos.domain.engine

import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.domain.model.PaymentDistribution

/**
 * Distribución de pagos entre intereses, capital, mora y excedente.
 * Regla automática predeterminada: primero intereses vencidos/pendientes, luego capital.
 */
object PaymentAllocator {

    data class AllocationInput(
        val amount: Money,
        val interestOutstanding: Money,
        val feesOutstanding: Money = Money.ZERO,
        val principalOutstanding: Money,
        val allowSurplus: Boolean = false
    )

    sealed interface AllocationResult {
        data class Ok(val distribution: PaymentDistribution) : AllocationResult
        data class RequiresSurplusConfirmation(val totalDebt: Money, val surplus: Money) : AllocationResult
        data class Invalid(val reason: String) : AllocationResult
    }

    fun automatic(input: AllocationInput): AllocationResult {
        if (input.amount.isNegative()) return AllocationResult.Invalid("El monto no puede ser negativo")
        val totalDebt = input.interestOutstanding + input.feesOutstanding + input.principalOutstanding
        if (input.amount > totalDebt && !input.allowSurplus) {
            return AllocationResult.RequiresSurplusConfirmation(totalDebt, input.amount - totalDebt)
        }
        var remaining = input.amount

        val toFees = remaining.min(input.feesOutstanding.max(Money.ZERO))
        remaining -= toFees

        val toInterest = remaining.min(input.interestOutstanding.max(Money.ZERO))
        remaining -= toInterest

        val toPrincipal = remaining.min(input.principalOutstanding.max(Money.ZERO))
        remaining -= toPrincipal

        val surplus = if (remaining.isPositive()) remaining else Money.ZERO
        return AllocationResult.Ok(
            PaymentDistribution(
                toInterest = toInterest,
                toPrincipal = toPrincipal,
                toFees = toFees,
                surplus = surplus
            )
        )
    }

    fun manual(
        amount: Money,
        toInterest: Money,
        toPrincipal: Money,
        toFees: Money = Money.ZERO,
        interestOutstanding: Money,
        principalOutstanding: Money,
        feesOutstanding: Money = Money.ZERO,
        allowSurplus: Boolean = false
    ): AllocationResult {
        if (amount.isNegative() || toInterest.isNegative() || toPrincipal.isNegative() || toFees.isNegative()) {
            return AllocationResult.Invalid("Los montos no pueden ser negativos")
        }
        val allocated = toInterest + toPrincipal + toFees
        if (allocated > amount) return AllocationResult.Invalid("La distribución excede el monto recibido")
        if (toInterest > interestOutstanding) return AllocationResult.Invalid("Interés asignado excede el interés pendiente")
        if (toPrincipal > principalOutstanding) return AllocationResult.Invalid("Capital asignado excede el capital pendiente")
        if (toFees > feesOutstanding) return AllocationResult.Invalid("Cargos asignados exceden los cargos pendientes")
        val totalDebt = interestOutstanding + feesOutstanding + principalOutstanding
        val surplus = amount - allocated
        val effectiveDebtReduction = allocated
        val coversBeyondDebt = amount > totalDebt
        if (coversBeyondDebt && !allowSurplus) {
            return AllocationResult.RequiresSurplusConfirmation(totalDebt, amount - totalDebt)
        }
        // Si hay remanente no asignado pero dentro de deuda, forzar asignación explícita no es automática aquí;
        // se permite como excedente solo si cubre deuda y fue autorizado, o se considera inválido para evitar ambigüedad.
        if (surplus.isPositive() && !allowSurplus && amount <= totalDebt) {
            return AllocationResult.Invalid("Distribución incompleta: asigne el total del monto o ajuste la cantidad")
        }
        return AllocationResult.Ok(
            PaymentDistribution(toInterest = toInterest, toPrincipal = toPrincipal, toFees = toFees, surplus = surplus)
        )
    }
}
