package com.dpm.prestamos.domain.model

import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.domain.enums.DistributionMode
import com.dpm.prestamos.domain.enums.PaymentMethod
import com.dpm.prestamos.domain.enums.PaymentStatus
import java.time.LocalDateTime

data class Payment(
    val id: Long = 0,
    val loanId: Long,
    val clientId: Long,
    val receiptNumber: String,
    val paidAt: LocalDateTime,
    val amountTotal: Money,
    val amountToInterest: Money,
    val amountToPrincipal: Money,
    val amountToFees: Money = Money.ZERO,
    val surplus: Money = Money.ZERO,
    val method: PaymentMethod,
    val distributionMode: DistributionMode,
    val notes: String? = null,
    val status: PaymentStatus = PaymentStatus.APLICADO,
    val voidReason: String? = null
)

data class PaymentDistribution(
    val toInterest: Money,
    val toPrincipal: Money,
    val toFees: Money = Money.ZERO,
    val surplus: Money = Money.ZERO
) {
    val total: Money get() = toInterest + toPrincipal + toFees + surplus
}
