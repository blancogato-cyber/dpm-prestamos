package com.dpm.prestamos.domain.usecase.reports

import java.time.LocalDate

enum class ReportType { CLIENTES, PRESTAMOS, PAGOS, CAJA, INTERESES, CARTERA }
enum class ExportFormat { PDF, CSV, EXCEL }

data class ExportResult(val filePath: String, val mimeType: String, val displayName: String)

interface ReportExporter {
    suspend fun export(type: ReportType, format: ExportFormat, from: LocalDate? = null, to: LocalDate? = null): Result<ExportResult>
    suspend fun generateReceipt(paymentId: Long): Result<ExportResult>
}
