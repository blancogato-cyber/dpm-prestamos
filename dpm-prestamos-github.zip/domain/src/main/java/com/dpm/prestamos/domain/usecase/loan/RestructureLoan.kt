package com.dpm.prestamos.domain.usecase.loan

import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.domain.enums.*
import com.dpm.prestamos.domain.model.Loan
import java.math.BigDecimal

data class RestructureParams(
    val oldLoan: Loan,
    val paymentNow: Money,
    val paymentMethod: PaymentMethod = PaymentMethod.EFECTIVO,
    val newPrincipal: Money,
    val newRatePercent: BigDecimal,
    val newTermDays: Int,
    val newInterestMethod: InterestMethod,
    val newAccrualMode: AccrualMode,
    val newPaymentMode: PaymentMode,
    val type: MovementType
)

sealed interface RestructureResult {
    data class Success(val oldLoanId: Long, val newLoanId: Long) : RestructureResult
    data class Error(val message: String) : RestructureResult
}

interface LoanRestructurer {
    suspend fun restructure(params: RestructureParams): RestructureResult
}
