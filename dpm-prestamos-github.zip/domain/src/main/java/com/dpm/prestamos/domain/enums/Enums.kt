package com.dpm.prestamos.domain.enums

enum class LoanStatus {
    ACTIVO,
    PROXIMO_VENCER,
    VENCIDO,
    LIQUIDADO,
    CANCELADO,
    REESTRUCTURADO
}

enum class InterestMethod {
    /** Interés calculado sobre el capital original del préstamo. */
    CAPITAL_INICIAL,
    /** Interés calculado sobre el capital pendiente vigente. */
    CAPITAL_PENDIENTE
}

enum class AccrualMode {
    /** Interés generado por período completo. */
    PERIODO_COMPLETO,
    /** Interés generado proporcionalmente a los días transcurridos. */
    PROPORCIONAL_DIAS
}

enum class PaymentMode {
    SOLO_INTERES,
    CAPITAL_E_INTERES,
    ABONO_PORCENTUAL,
    PERSONALIZADO
}

enum class PaymentMethod {
    EFECTIVO,
    TRANSFERENCIA,
    DEPOSITO,
    OTRO
}

enum class DistributionMode {
    AUTOMATICA,
    MANUAL
}

enum class TermType(val days: Int?) {
    QUINCENAL(15),
    MENSUAL(30),
    PERSONALIZADO(null)
}

enum class MovementType {
    DESEMBOLSO,
    PAGO,
    PAGO_INTERES,
    ABONO_CAPITAL,
    LIQUIDACION,
    RENOVACION,
    REFINANCIAMIENTO,
    AJUSTE,
    ANULACION_PAGO,
    CARGO_MORA,
    DESCUENTO
}

enum class CashTxType {
    SALDO_INICIAL,
    APORTE,
    DESEMBOLSO_PRESTAMO,
    PAGO_RECIBIDO,
    RETIRO,
    GASTO_OPERATIVO,
    AJUSTE
}

enum class PaymentStatus {
    APLICADO,
    ANULADO
}

enum class AuditAction {
    CREAR_PRESTAMO,
    EDITAR_PRESTAMO,
    REGISTRAR_PAGO,
    ANULAR_PAGO,
    RENOVAR,
    REFINANCIAR,
    LIQUIDAR,
    CANCELAR_PRESTAMO,
    CAMBIO_CONFIGURACION,
    MOVIMIENTO_CAJA,
    RESPALDO,
    RESTAURACION
}
