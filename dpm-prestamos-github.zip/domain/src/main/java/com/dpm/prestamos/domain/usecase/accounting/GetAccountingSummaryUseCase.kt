package com.dpm.prestamos.domain.usecase.accounting

import com.dpm.prestamos.domain.model.AccountingSummary
import javax.inject.Inject

interface AccountingSummaryProvider {
    suspend fun getSummary(): AccountingSummary
}

class GetAccountingSummaryUseCase @Inject constructor(private val provider: AccountingSummaryProvider) {
    suspend operator fun invoke(): AccountingSummary = provider.getSummary()
}
