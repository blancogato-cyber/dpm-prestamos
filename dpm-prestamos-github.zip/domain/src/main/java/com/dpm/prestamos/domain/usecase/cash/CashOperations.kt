package com.dpm.prestamos.domain.usecase.cash

import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.domain.enums.CashTxType

sealed interface CashOpResult {
    data object Success : CashOpResult
    data class Error(val message: String) : CashOpResult
}

interface CashOperator {
    suspend fun register(type: CashTxType, amount: Money, notes: String?, justification: String? = null): CashOpResult
}
