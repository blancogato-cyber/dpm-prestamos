package com.dpm.prestamos.domain.engine

import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.domain.enums.AccrualMode
import com.dpm.prestamos.domain.enums.InterestMethod
import java.math.BigDecimal
import java.math.RoundingMode

/**
 * Motor de cálculo de interés simple. Independiente de UI y persistencia.
 * Interés = Capital_base × Tasa / 100. Sin capitalización automática.
 */
object InterestCalculator {

    fun interestForPeriod(base: Money, ratePercent: BigDecimal): Money {
        require(ratePercent >= BigDecimal.ZERO) { "La tasa no puede ser negativa" }
        return base.percentage(ratePercent)
    }

    fun resolveBase(
        method: InterestMethod,
        principalOriginal: Money,
        principalOutstanding: Money
    ): Money = when (method) {
        InterestMethod.CAPITAL_INICIAL -> principalOriginal
        InterestMethod.CAPITAL_PENDIENTE -> principalOutstanding
    }

    /**
     * Interés generado para un número de períodos o días, según modo de devengo.
     * @param periods Número de períodos completos transcurridos a considerar (>=0).
     * @param daysElapsed Días transcurridos dentro del contexto (para prorrateo).
     * @param termDays Días que conforman un período.
     */
    fun calculateInterest(
        principalOriginal: Money,
        principalOutstanding: Money,
        ratePercent: BigDecimal,
        method: InterestMethod,
        accrualMode: AccrualMode,
        periods: Int = 1,
        daysElapsed: Int = 0,
        termDays: Int
    ): Money {
        require(periods >= 0) { "Los períodos no pueden ser negativos" }
        require(termDays > 0) { "La duración del período debe ser mayor a 0" }
        val base = resolveBase(method, principalOriginal, principalOutstanding)
        val perPeriod = interestForPeriod(base, ratePercent)
        return when (accrualMode) {
            AccrualMode.PERIODO_COMPLETO -> perPeriod * periods
            AccrualMode.PROPORCIONAL_DIAS -> {
                val effectiveDays = if (periods > 0) periods * termDays else daysElapsed.coerceAtLeast(0)
                val fraction = BigDecimal(effectiveDays).divide(BigDecimal(termDays), 10, RoundingMode.HALF_EVEN)
                perPeriod * fraction
            }
        }
    }
}
