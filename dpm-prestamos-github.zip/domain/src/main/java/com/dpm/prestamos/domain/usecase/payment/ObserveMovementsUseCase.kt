package com.dpm.prestamos.domain.usecase.payment

import com.dpm.prestamos.domain.model.Movement
import com.dpm.prestamos.domain.repository.MovementRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class ObserveRecentMovementsUseCase @Inject constructor(private val repository: MovementRepository) {
    operator fun invoke(limit: Int = 100): Flow<List<Movement>> = repository.observeRecent(limit)
}

class ObserveLoanMovementsUseCase @Inject constructor(private val repository: MovementRepository) {
    operator fun invoke(loanId: Long): Flow<List<Movement>> = repository.observeByLoan(loanId)
}
