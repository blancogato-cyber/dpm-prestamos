package com.dpm.prestamos.domain.engine

import com.dpm.prestamos.core.money.Money
import java.math.BigDecimal

/**
 * Intereses de mora: independientes del interés ordinario, configurables.
 * No aplicar retroactivamente sin registro/fundamento (la aplicación se hace mediante
 * operaciones explícitas registradas en movimientos/auditoría).
 */
object LateFeeCalculator {
    data class LateFeeConfig(
        val enabled: Boolean = false,
        val ratePercent: BigDecimal = BigDecimal.ZERO, // tasa por período de mora
        val graceDays: Int = 0
    )

    fun calculate(
        base: Money,
        overduePeriods: Int,
        config: LateFeeConfig
    ): Money {
        if (!config.enabled || overduePeriods <= 0) return Money.ZERO
        return base.percentage(config.ratePercent) * overduePeriods
    }
}
