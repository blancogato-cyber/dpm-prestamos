package com.dpm.prestamos.domain.model

import com.dpm.prestamos.core.money.Money

data class AccountingSummary(
    val capitalDisbursed: Money,
    val capitalRecovered: Money,
    val capitalPending: Money,
    val interestGenerated: Money,
    val interestCollected: Money,
    val interestPending: Money,
    val cashAvailable: Money,
    val activeLoans: Int,
    val settledLoans: Int,
    val realProfitFromInterest: Money
)
