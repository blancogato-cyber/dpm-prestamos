package com.dpm.prestamos.domain.repository

import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.domain.enums.LoanStatus
import com.dpm.prestamos.domain.model.*
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

interface ClientRepository {
    fun observeAll(): Flow<List<Client>>
    fun observeById(id: Long): Flow<Client?>
    suspend fun getById(id: Long): Client?
    suspend fun getAllOnce(): List<Client>
    fun search(query: String): Flow<List<Client>>
    suspend fun save(client: Client): Long
    suspend fun isPossibleDuplicate(name: String, phone: String, excludeId: Long? = null): Boolean
    suspend fun getProfile(clientId: Long): com.dpm.prestamos.domain.model.ClientProfile?
}

interface LoanRepository {
    fun observeAll(): Flow<List<Loan>>
    fun observeById(id: Long): Flow<Loan?>
    fun observeByClient(clientId: Long): Flow<List<Loan>>
    fun observeByStatus(status: LoanStatus): Flow<List<Loan>>
    fun observeDueOn(date: LocalDate): Flow<List<Loan>>
    suspend fun getById(id: Long): Loan?
    suspend fun getAllOnce(): List<Loan>
    suspend fun save(loan: Loan): Long
    suspend fun nextLoanNumber(): String
    suspend fun syncStatuses(today: LocalDate = LocalDate.now(), upcomingDays: Long = 3)
}

interface PaymentRepository {
    fun observeByLoan(loanId: Long): Flow<List<Payment>>
    suspend fun getById(id: Long): Payment?
    suspend fun getAllOnce(): List<Payment>
    suspend fun save(payment: Payment): Long
}

interface MovementRepository {
    fun observeByLoan(loanId: Long): Flow<List<Movement>>
    fun observeRecent(limit: Int): Flow<List<Movement>>
    suspend fun append(movement: Movement): Long
    suspend fun appendAll(movements: List<Movement>)
}

interface AuditRepository {
    suspend fun log(entry: AuditEntry)
    fun observeAll(): Flow<List<AuditEntry>>
}

data class CashAccount(val id: Long, val name: String, val currentBalance: com.dpm.prestamos.core.money.Money)
data class CashTx(val id: Long, val type: com.dpm.prestamos.domain.enums.CashTxType, val amount: com.dpm.prestamos.core.money.Money, val occurredAt: java.time.LocalDateTime, val notes: String?)

interface CashRepository {
    fun observeAccount(): Flow<CashAccount?>
    fun observeTransactions(): Flow<List<CashTx>>
    suspend fun getTransactionsOnce(): List<CashTx>
}

data class AuditEntry(
    val id: Long = 0,
    val action: com.dpm.prestamos.domain.enums.AuditAction,
    val entityType: String,
    val entityId: String,
    val timestamp: java.time.LocalDateTime,
    val actor: String? = null,
    val details: String? = null,
    val reason: String? = null
)

data class FinancialSummary(
    val totalToRecover: Money,
    val principalOutstanding: Money,
    val interestOutstanding: Money,
    val interestCollected: Money,
    val moneyRecovered: Money,
    val activeLoans: Int,
    val overdueLoans: Int,
    val settledLoans: Int,
    val paymentsToday: Int
)
