package com.dpm.prestamos.domain.usecase.accounting

import com.dpm.prestamos.domain.repository.FinancialSummary
import javax.inject.Inject

interface DashboardSummaryProvider {
    suspend fun getSummary(): FinancialSummary
}

class GetDashboardSummaryUseCase @Inject constructor(private val provider: DashboardSummaryProvider) {
    suspend operator fun invoke(): FinancialSummary = provider.getSummary()
}
