package com.dpm.prestamos.domain.usecase.payment

import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.domain.engine.PaymentAllocator
import com.dpm.prestamos.domain.model.Loan
import javax.inject.Inject

class PreviewPaymentUseCase @Inject constructor() {
    fun previewAutomatic(loan: Loan, amount: Money, allowSurplus: Boolean = false) =
        PaymentAllocator.automatic(
            PaymentAllocator.AllocationInput(
                amount = amount,
                interestOutstanding = loan.interestOutstanding,
                feesOutstanding = Money.ZERO,
                principalOutstanding = loan.principalOutstanding,
                allowSurplus = allowSurplus
            )
        )

    fun previewManual(
        loan: Loan, amount: Money, toInterest: Money, toPrincipal: Money, toFees: Money = Money.ZERO, allowSurplus: Boolean = false
    ) = PaymentAllocator.manual(
        amount = amount,
        toInterest = toInterest,
        toPrincipal = toPrincipal,
        toFees = toFees,
        interestOutstanding = loan.interestOutstanding,
        principalOutstanding = loan.principalOutstanding,
        feesOutstanding = Money.ZERO,
        allowSurplus = allowSurplus
    )
}
