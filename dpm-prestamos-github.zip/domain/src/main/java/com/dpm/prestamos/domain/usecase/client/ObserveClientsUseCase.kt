package com.dpm.prestamos.domain.usecase.client

import com.dpm.prestamos.domain.model.Client
import com.dpm.prestamos.domain.repository.ClientRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class ObserveClientsUseCase @Inject constructor(private val repository: ClientRepository) {
    operator fun invoke(): Flow<List<Client>> = repository.observeAll()
}

class SearchClientsUseCase @Inject constructor(private val repository: ClientRepository) {
    operator fun invoke(query: String): Flow<List<Client>> = repository.search(query)
}
