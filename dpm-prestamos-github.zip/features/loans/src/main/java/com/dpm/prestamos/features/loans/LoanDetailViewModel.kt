package com.dpm.prestamos.features.loans

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.domain.enums.DistributionMode
import com.dpm.prestamos.domain.enums.PaymentMethod
import com.dpm.prestamos.domain.model.Loan
import com.dpm.prestamos.domain.model.Movement
import com.dpm.prestamos.domain.model.Payment
import com.dpm.prestamos.domain.repository.ClientRepository
import com.dpm.prestamos.domain.repository.PaymentRepository
import com.dpm.prestamos.domain.usecase.loan.LoanRestructurer
import com.dpm.prestamos.domain.usecase.loan.ObserveLoanUseCase
import com.dpm.prestamos.domain.usecase.loan.RestructureParams
import com.dpm.prestamos.domain.usecase.loan.RestructureResult
import com.dpm.prestamos.domain.usecase.payment.ObserveLoanMovementsUseCase
import com.dpm.prestamos.domain.usecase.payment.PaymentRegistrar
import com.dpm.prestamos.domain.usecase.payment.RegisterPaymentResult
import com.dpm.prestamos.domain.usecase.reports.ReportExporter
import com.dpm.prestamos.domain.enums.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.math.BigDecimal
import javax.inject.Inject

data class LoanDetailUiState(
    val loan: Loan? = null,
    val clientName: String? = null,
    val movements: List<Movement> = emptyList(),
    val payments: List<Payment> = emptyList(),
    val message: String? = null,
    val pendingSurplus: Money? = null,
    val receiptToShare: Pair<String, String>? = null // path, mime
)

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class LoanDetailViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    observeLoan: ObserveLoanUseCase,
    observeMovements: ObserveLoanMovementsUseCase,
    paymentRepository: PaymentRepository,
    private val clientRepository: ClientRepository,
    private val registrar: PaymentRegistrar,
    private val restructurer: LoanRestructurer,
    private val reportExporter: ReportExporter
) : ViewModel() {
    private val loanId: Long = savedStateHandle.get<String>("loanId")?.toLongOrNull() ?: -1L
    private val message = MutableStateFlow<String?>(null)
    private val pendingSurplus = MutableStateFlow<Money?>(null)
    private val receiptToShare = MutableStateFlow<Pair<String, String>?>(null)

    private val loanFlow = observeLoan(loanId)
    private val clientNameFlow = loanFlow.flatMapLatest { loan ->
        if (loan == null) flowOf(null) else clientRepository.observeById(loan.clientId).map { it?.fullName }
    }

    val uiState: StateFlow<LoanDetailUiState> = combine(
        loanFlow, clientNameFlow, observeMovements(loanId), paymentRepository.observeByLoan(loanId), message, pendingSurplus, receiptToShare
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        LoanDetailUiState(
            loan = values[0] as Loan?,
            clientName = values[1] as String?,
            movements = values[2] as List<Movement>,
            payments = values[3] as List<Payment>,
            message = values[4] as String?,
            pendingSurplus = values[5] as Money?,
            receiptToShare = values[6] as Pair<String, String>?
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), LoanDetailUiState())

    fun clearMessage() { message.value = null }
    fun clearPendingSurplus() { pendingSurplus.value = null }
    fun clearReceipt() { receiptToShare.value = null }

    fun generateReceipt(paymentId: Long) {
        viewModelScope.launch {
            val r = reportExporter.generateReceipt(paymentId)
            r.onSuccess { receiptToShare.value = it.filePath to it.mimeType }
                .onFailure { message.value = "Error al generar recibo: ${it.message}" }
        }
    }

    fun registerPayment(
        amountText: String,
        method: PaymentMethod,
        auto: Boolean = true,
        toInterestText: String = "",
        toPrincipalText: String = "",
        allowSurplus: Boolean = false
    ) {
        val loan = uiState.value.loan ?: return
        viewModelScope.launch {
            val amount = runCatching { Money.of(amountText.trim()) }.getOrNull()
            if (amount == null || !amount.isPositive()) { message.value = "Monto inválido"; return@launch }
            val mode = if (auto) DistributionMode.AUTOMATICA else DistributionMode.MANUAL
            val toInterest = if (auto) null else runCatching { Money.of(toInterestText.ifBlank { "0" }) }.getOrDefault(Money.ZERO)
            val toPrincipal = if (auto) null else runCatching { Money.of(toPrincipalText.ifBlank { "0" }) }.getOrDefault(Money.ZERO)
            when (val r = registrar.register(loan, amount, method, mode, allowSurplus, toInterest, toPrincipal)) {
                is RegisterPaymentResult.Success -> { pendingSurplus.value = null; message.value = "Pago registrado (${r.receiptNumber})" }
                is RegisterPaymentResult.NeedsSurplusConfirmation -> {
                    pendingSurplus.value = r.surplus
                    message.value = "El pago excede el saldo (excedente RD$ ${r.surplus.toPlainString()}). Confirme el tratamiento del excedente."
                }
                is RegisterPaymentResult.Error -> { pendingSurplus.value = null; message.value = r.message }
            }
        }
    }

    fun voidPayment(paymentId: Long, reason: String) {
        if (reason.isBlank()) { message.value = "Indique el motivo de anulación"; return }
        viewModelScope.launch {
            when (val r = registrar.void(paymentId, reason.trim())) {
                is RegisterPaymentResult.Success -> message.value = "Pago anulado (${r.receiptNumber})"
                is RegisterPaymentResult.Error -> message.value = r.message
                else -> {}
            }
        }
    }

    fun settle(interestAccrued: String, discount: String, method: PaymentMethod) {
        val loan = uiState.value.loan ?: return
        viewModelScope.launch {
            val interest = runCatching { Money.of(interestAccrued.ifBlank { loan.interestOutstanding.toPlainString() }) }.getOrDefault(loan.interestOutstanding)
            val disc = runCatching { Money.of(discount.ifBlank { "0" }) }.getOrDefault(Money.ZERO)
            when (val r = registrar.settle(loan, interest, Money.ZERO, disc, method)) {
                is RegisterPaymentResult.Success -> message.value = "Préstamo liquidado (${r.receiptNumber})"
                is RegisterPaymentResult.Error -> message.value = r.message
                else -> {}
            }
        }
    }

    fun restructure(
        type: MovementType,
        paymentNowText: String,
        newPrincipalText: String,
        newRateText: String,
        newTermDays: Int,
        method: InterestMethod,
        accrual: AccrualMode
    ) {
        val loan = uiState.value.loan ?: return
        viewModelScope.launch {
            val paymentNow = runCatching { Money.of(paymentNowText.ifBlank { "0" }) }.getOrDefault(Money.ZERO)
            val newPrincipal = runCatching { Money.of(newPrincipalText) }.getOrNull()
            val newRate = runCatching { BigDecimal(newRateText) }.getOrNull()
            if (newPrincipal == null || newRate == null) { message.value = "Datos del nuevo préstamo inválidos"; return@launch }
            val res = restructurer.restructure(
                RestructureParams(
                    oldLoan = loan, paymentNow = paymentNow, paymentMethod = PaymentMethod.EFECTIVO,
                    newPrincipal = newPrincipal, newRatePercent = newRate, newTermDays = newTermDays,
                    newInterestMethod = method, newAccrualMode = accrual, newPaymentMode = PaymentMode.CAPITAL_E_INTERES,
                    type = type
                )
            )
            message.value = when (res) {
                is RestructureResult.Success -> "Reestructuración completada. Nuevo préstamo #${res.newLoanId}"
                is RestructureResult.Error -> res.message
            }
        }
    }
}
