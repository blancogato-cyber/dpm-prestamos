package com.dpm.prestamos.features.loans

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.domain.enums.*
import com.dpm.prestamos.domain.model.Client
import com.dpm.prestamos.domain.model.Loan
import com.dpm.prestamos.domain.usecase.client.ObserveClientsUseCase
import com.dpm.prestamos.domain.usecase.loan.CreateLoanUseCase
import com.dpm.prestamos.domain.usecase.loan.ObserveLoansUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.math.BigDecimal
import java.time.LocalDate
import javax.inject.Inject

data class LoanFilters(
    val status: LoanStatus? = null,
    val termDays: Int? = null,
    val clientId: Long? = null,
    val minAmount: String = "",
    val maxAmount: String = ""
)

data class LoansUiState(
    val loans: List<Loan> = emptyList(),
    val clients: List<Client> = emptyList(),
    val clientNames: Map<Long, String> = emptyMap(),
    val filters: LoanFilters = LoanFilters(),
    val message: String? = null
)

@HiltViewModel
class LoansViewModel @Inject constructor(
    observeLoans: ObserveLoansUseCase,
    observeClients: ObserveClientsUseCase,
    private val createLoan: CreateLoanUseCase
) : ViewModel() {
    private val filters = MutableStateFlow(LoanFilters())
    private val message = MutableStateFlow<String?>(null)

    private val loansFlow = combine(observeLoans(), filters) { loans, f ->
        loans.filter { loan ->
            (f.status == null || loan.status == f.status) &&
            (f.termDays == null || loan.termDays == f.termDays) &&
            (f.clientId == null || loan.clientId == f.clientId) &&
            (f.minAmount.toBigDecimalOrNull()?.let { loan.principalOriginal.amount >= it } ?: true) &&
            (f.maxAmount.toBigDecimalOrNull()?.let { loan.principalOriginal.amount <= it } ?: true)
        }
    }

    val uiState: StateFlow<LoansUiState> = combine(loansFlow, observeClients(), filters, message) { loans, clients, f, msg ->
        LoansUiState(
            loans = loans,
            clients = clients,
            clientNames = clients.associate { it.id to it.fullName },
            filters = f,
            message = msg
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), LoansUiState())

    fun setStatus(status: LoanStatus?) { filters.value = filters.value.copy(status = status) }
    fun setTermDays(days: Int?) { filters.value = filters.value.copy(termDays = days) }
    fun setClient(clientId: Long?) { filters.value = filters.value.copy(clientId = clientId) }
    fun setAmountRange(min: String, max: String) { filters.value = filters.value.copy(minAmount = min, maxAmount = max) }
    fun clearFilters() { filters.value = LoanFilters() }
    fun clearMessage() { message.value = null }

    fun createLoan(
        clientId: Long, amount: String, rate: String, termDays: Int, termType: TermType,
        interestMethod: InterestMethod, accrualMode: AccrualMode, paymentMode: PaymentMode, notes: String?
    ) {
        viewModelScope.launch {
            runCatching {
                val principal = Money.of(amount.trim())
                val rateBd = BigDecimal(rate.trim())
                val today = LocalDate.now()
                val draft = Loan(
                    clientId = clientId,
                    loanNumber = "",
                    principalOriginal = principal,
                    principalOutstanding = principal,
                    interestRatePercent = rateBd,
                    interestMethod = interestMethod,
                    accrualMode = accrualMode,
                    defaultPaymentMode = paymentMode,
                    termType = termType,
                    termDays = termDays,
                    disbursementDate = today,
                    dueDate = today.plusDays(termDays.toLong()),
                    status = LoanStatus.ACTIVO,
                    interestGenerated = Money.ZERO,
                    interestPaid = Money.ZERO,
                    interestOutstanding = Money.ZERO,
                    totalPaid = Money.ZERO,
                    totalBalance = principal,
                    notes = notes?.takeIf { it.isNotBlank() }
                )
                createLoan(draft)
            }.onSuccess { message.value = "Préstamo creado" }
             .onFailure { message.value = it.message ?: "Error al crear préstamo" }
        }
    }
}
