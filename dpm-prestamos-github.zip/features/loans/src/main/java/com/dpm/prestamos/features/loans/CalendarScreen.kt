package com.dpm.prestamos.features.loans

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dpm.prestamos.core.money.MoneyFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalendarScreen(onBack: () -> Unit, onLoanClick: (Long) -> Unit = {}, viewModel: CalendarViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    Scaffold(topBar = { TopAppBar(title = { Text("Calendario financiero") }, navigationIcon = { TextButton(onClick = onBack) { Text("Atrás") } }) }) { padding ->
        LazyColumn(Modifier.padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = state.mode == CalendarViewMode.DIA, onClick = { viewModel.setMode(CalendarViewMode.DIA) }, label = { Text("Día") })
                    FilterChip(selected = state.mode == CalendarViewMode.SEMANA, onClick = { viewModel.setMode(CalendarViewMode.SEMANA) }, label = { Text("Semana") })
                    FilterChip(selected = state.mode == CalendarViewMode.MES, onClick = { viewModel.setMode(CalendarViewMode.MES) }, label = { Text("Mes") })
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { viewModel.shift(-1) }) { Text("◀") }
                    OutlinedButton(onClick = { viewModel.today() }) { Text("Hoy") }
                    OutlinedButton(onClick = { viewModel.shift(1) }) { Text("▶") }
                    Text("Ref: ${state.selectedDate}", modifier = Modifier.padding(start = 8.dp, top = 10.dp), style = MaterialTheme.typography.bodySmall)
                }
            }
            item { Text("Vencimientos en el período", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary) }
            if (state.loans.isEmpty()) item { Text("Sin vencimientos en este período.") } else items(state.loans, key = { "r${it.loan.id}" }) { itemLoan(it, onLoanClick) }

            item { Text("Próximos 7 días", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary) }
            if (state.upcoming.isEmpty()) item { Text("Sin vencimientos próximos.") } else items(state.upcoming, key = { "u${it.loan.id}" }) { itemLoan(it, onLoanClick) }

            item { Text("En atraso / mora", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.error) }
            if (state.overdue.isEmpty()) item { Text("Sin préstamos en atraso.") } else items(state.overdue, key = { "o${it.loan.id}" }) { itemLoan(it, onLoanClick, true) }
        }
    }
}

@Composable
private fun itemLoan(item: CalendarLoan, onClick: (Long) -> Unit, showOverdue: Boolean = false) {
    ElevatedCard(onClick = { onClick(item.loan.id) }, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("${item.clientName} • ${item.loan.loanNumber}", style = MaterialTheme.typography.titleSmall)
            Text("Vence: ${item.loan.dueDate} • Estado: ${item.loan.status}")
            Text("Saldo: ${MoneyFormatter.format(item.loan.totalBalance)}", color = if (item.loan.totalBalance.isPositive()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
            if (showOverdue && item.daysOverdue > 0) Text("Días en atraso (tras gracia): ${item.daysOverdue}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
    }
}
