package com.dpm.prestamos.features.loans

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dpm.prestamos.core.money.MoneyFormatter
import com.dpm.prestamos.domain.enums.*
import com.dpm.prestamos.domain.model.Loan

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoansScreen(onLoanClick: (Long) -> Unit = {}, viewModel: LoansViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var showAdd by remember { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(state.message) {
        state.message?.let { snackbar.showSnackbar(it); viewModel.clearMessage(); if (it == "Préstamo creado") showAdd = false }
    }

    Scaffold(
        floatingActionButton = { FloatingActionButton(onClick = { showAdd = true }) { Icon(Icons.Default.Add, "Nuevo préstamo") } },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Préstamos", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
            Text("Estado", style = MaterialTheme.typography.labelMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = state.filters.status == null, onClick = { viewModel.setStatus(null) }, label = { Text("Todos") })
                FilterChip(selected = state.filters.status == LoanStatus.ACTIVO, onClick = { viewModel.setStatus(LoanStatus.ACTIVO) }, label = { Text("Activos") })
                FilterChip(selected = state.filters.status == LoanStatus.VENCIDO, onClick = { viewModel.setStatus(LoanStatus.VENCIDO) }, label = { Text("Vencidos") })
                FilterChip(selected = state.filters.status == LoanStatus.LIQUIDADO, onClick = { viewModel.setStatus(LoanStatus.LIQUIDADO) }, label = { Text("Liquidados") })
            }
            Text("Plazo / Filtros", style = MaterialTheme.typography.labelMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = state.filters.termDays == null, onClick = { viewModel.setTermDays(null) }, label = { Text("Cualquier plazo") })
                FilterChip(selected = state.filters.termDays == 15, onClick = { viewModel.setTermDays(15) }, label = { Text("15 días") })
                FilterChip(selected = state.filters.termDays == 30, onClick = { viewModel.setTermDays(30) }, label = { Text("30 días") })
            }
            var clientExpanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(expanded = clientExpanded, onExpandedChange = { clientExpanded = it }) {
                val selectedName = state.clients.find { it.id == state.filters.clientId }?.fullName ?: "Todos los clientes"
                OutlinedTextField(selectedName, {}, readOnly = true, label = { Text("Cliente") }, modifier = Modifier.menuAnchor().fillMaxWidth())
                ExposedDropdownMenu(expanded = clientExpanded, onDismissRequest = { clientExpanded = false }) {
                    DropdownMenuItem(text = { Text("Todos los clientes") }, onClick = { viewModel.setClient(null); clientExpanded = false })
                    state.clients.forEach { c -> DropdownMenuItem(text = { Text(c.fullName) }, onClick = { viewModel.setClient(c.id); clientExpanded = false }) }
                }
            }
            var minAmt by remember(state.filters.minAmount) { mutableStateOf(state.filters.minAmount) }
            var maxAmt by remember(state.filters.maxAmount) { mutableStateOf(state.filters.maxAmount) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(minAmt, { minAmt = it; viewModel.setAmountRange(it, maxAmt) }, label = { Text("Monto mín.") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                OutlinedTextField(maxAmt, { maxAmt = it; viewModel.setAmountRange(minAmt, it) }, label = { Text("Monto máx.") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            }
            TextButton(onClick = { minAmt = ""; maxAmt = ""; viewModel.clearFilters() }) { Text("Limpiar filtros") }
            if (state.loans.isEmpty()) {
                Text("No hay préstamos para mostrar.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(state.loans, key = { it.id }) { loan ->
                        LoanCard(
                            loan = loan,
                            clientName = state.clientNames[loan.clientId],
                            onClick = { onLoanClick(loan.id) }
                        )
                    }
                }
            }
        }
    }
    if (showAdd) CreateLoanDialog(state = state, onDismiss = { showAdd = false }, onCreate = viewModel::createLoan)
}

@Composable
private fun LoanCard(loan: Loan, clientName: String? = null, onClick: () -> Unit = {}) {
    val statusColor = when (loan.status) {
        LoanStatus.VENCIDO -> MaterialTheme.colorScheme.error
        LoanStatus.LIQUIDADO -> MaterialTheme.colorScheme.primary
        else -> MaterialTheme.colorScheme.secondary
    }
    ElevatedCard(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            clientName?.let { Text(it, style = MaterialTheme.typography.titleSmall) }
            Text("${loan.loanNumber} • ${loan.status}", color = statusColor, style = MaterialTheme.typography.bodyMedium)
            Text("Capital: ${MoneyFormatter.format(loan.principalOriginal)}  Pend.: ${MoneyFormatter.format(loan.principalOutstanding)}")
            Text("Interés pend.: ${MoneyFormatter.format(loan.interestOutstanding)}  Saldo: ${MoneyFormatter.format(loan.totalBalance)}", color = MaterialTheme.colorScheme.primary)
            Text("Vence: ${loan.dueDate}  •  ${loan.termDays} días  •  ${loan.interestRatePercent}% (${loan.interestMethod})", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CreateLoanDialog(state: LoansUiState, onDismiss: () -> Unit, onCreate: (Long, String, String, Int, TermType, InterestMethod, AccrualMode, PaymentMode, String?) -> Unit) {
    var clientId by remember { mutableStateOf<Long?>(state.clients.firstOrNull()?.id) }
    var amount by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf("20") }
    var termDaysText by remember { mutableStateOf("30") }
    var termType by remember { mutableStateOf(TermType.MENSUAL) }
    var method by remember { mutableStateOf(InterestMethod.CAPITAL_PENDIENTE) }
    var accrual by remember { mutableStateOf(AccrualMode.PERIODO_COMPLETO) }
    var payMode by remember { mutableStateOf(PaymentMode.CAPITAL_E_INTERES) }
    var notes by remember { mutableStateOf("") }
    var clientExpanded by remember { mutableStateOf(false) }

    AlertDialog(onDismissRequest = onDismiss, title = { Text("Nuevo préstamo") }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (state.clients.isEmpty()) {
                Text("Registra un cliente primero.", color = MaterialTheme.colorScheme.error)
            } else {
                ExposedDropdownMenuBox(expanded = clientExpanded, onExpandedChange = { clientExpanded = it }) {
                    val selected = state.clients.find { it.id == clientId }?.fullName ?: "Cliente"
                    OutlinedTextField(selected, {}, readOnly = true, label = { Text("Cliente") }, modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = clientExpanded, onDismissRequest = { clientExpanded = false }) {
                        state.clients.forEach { c -> DropdownMenuItem(text = { Text(c.fullName) }, onClick = { clientId = c.id; clientExpanded = false }) }
                    }
                }
            }
            OutlinedTextField(amount, { amount = it }, label = { Text("Monto (RD$)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            OutlinedTextField(rate, { rate = it }, label = { Text("Tasa % por período") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = termType == TermType.QUINCENAL, onClick = { termType = TermType.QUINCENAL; termDaysText = "15" }, label = { Text("15 días") })
                FilterChip(selected = termType == TermType.MENSUAL, onClick = { termType = TermType.MENSUAL; termDaysText = "30" }, label = { Text("30 días") })
                FilterChip(selected = termType == TermType.PERSONALIZADO, onClick = { termType = TermType.PERSONALIZADO }, label = { Text("Otro") })
            }
            OutlinedTextField(termDaysText, { termDaysText = it }, label = { Text("Días de plazo") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            Text("Método de interés", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = method == InterestMethod.CAPITAL_INICIAL, onClick = { method = InterestMethod.CAPITAL_INICIAL }, label = { Text("Capital inicial") })
                FilterChip(selected = method == InterestMethod.CAPITAL_PENDIENTE, onClick = { method = InterestMethod.CAPITAL_PENDIENTE }, label = { Text("Capital pendiente") })
            }
            Text("Devengo", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = accrual == AccrualMode.PERIODO_COMPLETO, onClick = { accrual = AccrualMode.PERIODO_COMPLETO }, label = { Text("Período completo") })
                FilterChip(selected = accrual == AccrualMode.PROPORCIONAL_DIAS, onClick = { accrual = AccrualMode.PROPORCIONAL_DIAS }, label = { Text("Proporcional") })
            }
            OutlinedTextField(notes, { notes = it }, label = { Text("Observaciones") })
        }
    }, confirmButton = {
        TextButton(enabled = clientId != null, onClick = {
            val days = termDaysText.toIntOrNull() ?: if (termType == TermType.QUINCENAL) 15 else 30
            clientId?.let { onCreate(it, amount, rate, days, termType, method, accrual, payMode, notes) }
        }) { Text("Crear") }
    }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } })
}
