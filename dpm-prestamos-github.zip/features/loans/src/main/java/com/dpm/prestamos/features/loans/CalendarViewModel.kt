package com.dpm.prestamos.features.loans

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dpm.prestamos.domain.engine.LateFeeCalculator
import com.dpm.prestamos.domain.enums.LoanStatus
import com.dpm.prestamos.domain.model.Loan
import com.dpm.prestamos.domain.repository.ClientRepository
import com.dpm.prestamos.domain.repository.LoanRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters
import javax.inject.Inject

enum class CalendarViewMode { DIA, SEMANA, MES }
data class CalendarLoan(val loan: Loan, val clientName: String, val daysOverdue: Long)

data class CalendarUiState(
    val mode: CalendarViewMode = CalendarViewMode.SEMANA,
    val selectedDate: LocalDate = LocalDate.now(),
    val loans: List<CalendarLoan> = emptyList(),
    val upcoming: List<CalendarLoan> = emptyList(),
    val overdue: List<CalendarLoan> = emptyList()
)

@HiltViewModel
class CalendarViewModel @Inject constructor(
    private val loanRepository: LoanRepository,
    clientRepository: ClientRepository
) : ViewModel() {
    private val mode = MutableStateFlow(CalendarViewMode.SEMANA)
    private val selectedDate = MutableStateFlow(LocalDate.now())

    val uiState: StateFlow<CalendarUiState> = combine(mode, selectedDate, loanRepository.observeAll(), clientRepository.observeAll()) { m, date, loans, clients ->
        val names = clients.associate { it.id to it.fullName }
        val today = LocalDate.now()
        val activeRelevant = loans.filter { it.status in listOf(LoanStatus.ACTIVO, LoanStatus.PROXIMO_VENCER, LoanStatus.VENCIDO) }
        val (start, end) = rangeFor(m, date)
        val inRange = activeRelevant.filter { !it.dueDate.isBefore(start) && !it.dueDate.isAfter(end) }
            .map { CalendarLoan(it, names[it.clientId] ?: "Cliente", LateFeeCalculator.overdueDays(it.dueDate, today, it.gracePeriodDays)) }
            .sortedBy { it.loan.dueDate }
        val upcoming = activeRelevant.filter { !it.dueDate.isBefore(today) && !it.dueDate.isAfter(today.plusDays(7)) }
            .map { CalendarLoan(it, names[it.clientId] ?: "Cliente", 0) }.sortedBy { it.loan.dueDate }
        val overdue = loans.filter { it.status == LoanStatus.VENCIDO || (it.status in listOf(LoanStatus.ACTIVO, LoanStatus.PROXIMO_VENCER) && it.dueDate.isBefore(today)) }
            .map { CalendarLoan(it, names[it.clientId] ?: "Cliente", LateFeeCalculator.overdueDays(it.dueDate, today, it.gracePeriodDays)) }
            .sortedByDescending { it.daysOverdue }
        CalendarUiState(m, date, inRange, upcoming, overdue)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), CalendarUiState())

    init { viewModelScope.launch { runCatching { loanRepository.syncStatuses() } } }

    fun setMode(m: CalendarViewMode) { mode.value = m }
    fun shift(deltaDays: Long) { selectedDate.value = selectedDate.value.plusDays(deltaDays) }
    fun today() { selectedDate.value = LocalDate.now() }

    private fun rangeFor(mode: CalendarViewMode, date: LocalDate): Pair<LocalDate, LocalDate> = when (mode) {
        CalendarViewMode.DIA -> date to date
        CalendarViewMode.SEMANA -> {
            val start = date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            start to start.plusDays(6)
        }
        CalendarViewMode.MES -> date.withDayOfMonth(1) to date.with(TemporalAdjusters.lastDayOfMonth())
    }
}
