package com.dpm.prestamos.features.loans

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.core.money.MoneyFormatter
import com.dpm.prestamos.domain.enums.*
import com.dpm.prestamos.domain.model.Payment
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoanDetailScreen(onBack: () -> Unit, viewModel: LoanDetailViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val context = LocalContext.current
    var showPay by remember { mutableStateOf(false) }
    var showSettle by remember { mutableStateOf(false) }
    var restructureType by remember { mutableStateOf<MovementType?>(null) }
    var voidTarget by remember { mutableStateOf<Payment?>(null) }

    LaunchedEffect(state.message) { state.message?.let { snackbar.showSnackbar(it); viewModel.clearMessage() } }
    LaunchedEffect(state.receiptToShare) {
        state.receiptToShare?.let { (path, mime) ->
            val file = File(path)
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mime
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Compartir recibo"))
            viewModel.clearReceipt()
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Detalle del préstamo") }, navigationIcon = { TextButton(onClick = onBack) { Text("Atrás") } }) }, snackbarHost = { SnackbarHost(snackbar) }) { padding ->
        val loan = state.loan
        if (loan == null) {
            Box(Modifier.padding(padding).padding(24.dp)) { Text("Cargando...") }
        } else {
            LazyColumn(Modifier.padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            state.clientName?.let { Text(it, style = MaterialTheme.typography.titleMedium) }
                            Text(loan.loanNumber, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                            Text("Estado: ${loan.status}")
                            Text("Capital original: ${MoneyFormatter.format(loan.principalOriginal)}")
                            Text("Capital pendiente: ${MoneyFormatter.format(loan.principalOutstanding)}")
                            Text("Intereses generados: ${MoneyFormatter.format(loan.interestGenerated)}")
                            Text("Intereses pagados: ${MoneyFormatter.format(loan.interestPaid)}")
                            Text("Intereses pendientes: ${MoneyFormatter.format(loan.interestOutstanding)}")
                            Text("Total pagado: ${MoneyFormatter.format(loan.totalPaid)}")
                            Text("Saldo total: ${MoneyFormatter.format(loan.totalBalance)}", color = MaterialTheme.colorScheme.primary)
                            Text("Inicio: ${loan.disbursementDate}  Vence: ${loan.dueDate}")
                            Text("Método: ${loan.interestMethod}  •  Devengo: ${loan.accrualMode}")
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { showPay = true }, modifier = Modifier.weight(1f), enabled = loan.totalBalance.isPositive()) { Text("Registrar pago") }
                        OutlinedButton(onClick = { showSettle = true }, modifier = Modifier.weight(1f), enabled = loan.totalBalance.isPositive()) { Text("Liquidar") }
                    }
                }
                val canRestructure = loan.status in listOf(LoanStatus.ACTIVO, LoanStatus.PROXIMO_VENCER, LoanStatus.VENCIDO)
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { restructureType = MovementType.RENOVACION }, modifier = Modifier.weight(1f), enabled = canRestructure) { Text("Renovar") }
                        OutlinedButton(onClick = { restructureType = MovementType.REFINANCIAMIENTO }, modifier = Modifier.weight(1f), enabled = canRestructure) { Text("Refinanciar") }
                    }
                }
                item { Text("Pagos", style = MaterialTheme.typography.titleMedium) }
                if (state.payments.isEmpty()) item { Text("Sin pagos registrados.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                else items(state.payments, key = { it.id }) { p ->
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text("${p.receiptNumber} • ${p.status}", color = if (p.status == PaymentStatus.ANULADO) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                            Text("Total: ${MoneyFormatter.format(p.amountTotal)} (Int: ${MoneyFormatter.format(p.amountToInterest)} / Cap: ${MoneyFormatter.format(p.amountToPrincipal)})")
                            Text("${p.paidAt} • ${p.method}", style = MaterialTheme.typography.bodySmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                TextButton(onClick = { viewModel.generateReceipt(p.id) }) { Text("Recibo") }
                                if (p.status == PaymentStatus.APLICADO) {
                                    TextButton(onClick = { voidTarget = p }) { Text("Anular", color = MaterialTheme.colorScheme.error) }
                                }
                            }
                            if (p.status == PaymentStatus.ANULADO) p.voidReason?.let { Text("Motivo: $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
                        }
                    }
                }
                item { Text("Historial de movimientos", style = MaterialTheme.typography.titleMedium) }
                if (state.movements.isEmpty()) item { Text("Sin movimientos.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                else items(state.movements, key = { it.id }) { m ->
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text("${m.type} • ${MoneyFormatter.format(m.amount)}")
                            Text("${m.timestamp}", style = MaterialTheme.typography.bodySmall)
                            Text("Saldo ${MoneyFormatter.format(m.balanceBefore)} → ${MoneyFormatter.format(m.balanceAfter)}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
    state.loan?.let { loan ->
        if (showPay) RegisterPaymentDialog(
            loan = loan,
            pendingSurplus = state.pendingSurplus,
            onDismiss = { showPay = false; viewModel.clearPendingSurplus() },
            onSubmit = { amount, method, auto, toI, toP, allow -> viewModel.registerPayment(amount, method, auto, toI, toP, allow) },
            onSuccessHint = state.message
        )
        if (showSettle) SettleDialog(loan = loan, onDismiss = { showSettle = false }) { interest, discount, method -> viewModel.settle(interest, discount, method); showSettle = false }
        restructureType?.let { type ->
            RestructureDialog(loan = loan, type = type, onDismiss = { restructureType = null }) { payNow, newPrincipal, rate, term, method, accrual ->
                viewModel.restructure(type, payNow, newPrincipal, rate, term, method, accrual); restructureType = null
            }
        }
    }
    voidTarget?.let { p -> VoidDialog(payment = p, onDismiss = { voidTarget = null }) { reason -> viewModel.voidPayment(p.id, reason); voidTarget = null } }
}

@Composable
private fun RegisterPaymentDialog(
    loan: com.dpm.prestamos.domain.model.Loan,
    pendingSurplus: Money?,
    onDismiss: () -> Unit,
    onSubmit: (String, PaymentMethod, Boolean, String, String, Boolean) -> Unit,
    onSuccessHint: String?
) {
    var amount by remember { mutableStateOf(loan.interestOutstanding.toPlainString()) }
    var method by remember { mutableStateOf(PaymentMethod.EFECTIVO) }
    var auto by remember { mutableStateOf(true) }
    var toInterest by remember { mutableStateOf(loan.interestOutstanding.toPlainString()) }
    var toPrincipal by remember { mutableStateOf("0") }
    val percents = listOf(5, 10, 15, 20, 25, 30, 50, 100)

    LaunchedEffect(onSuccessHint) { if (onSuccessHint?.startsWith("Pago registrado") == true) onDismiss() }

    AlertDialog(onDismissRequest = onDismiss, title = { Text("Registrar pago") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Saldo total: ${MoneyFormatter.format(loan.totalBalance)}", style = MaterialTheme.typography.bodySmall)
            Text("Interés pend.: ${MoneyFormatter.format(loan.interestOutstanding)}  Cap. pend.: ${MoneyFormatter.format(loan.principalOutstanding)}", style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(amount, { amount = it }, label = { Text("Cantidad recibida (RD$)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            Text("Abono a capital + intereses", style = MaterialTheme.typography.labelMedium)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(percents.size) { i ->
                    val pct = percents[i]
                    AssistChip(onClick = {
                        val cap = loan.principalOutstanding.percentage(java.math.BigDecimal(pct))
                        amount = (loan.interestOutstanding + cap).toPlainString()
                        toInterest = loan.interestOutstanding.toPlainString()
                        toPrincipal = cap.toPlainString()
                    }, label = { Text("$pct%") })
                }
                item { AssistChip(onClick = { amount = loan.interestOutstanding.toPlainString(); toInterest = amount; toPrincipal = "0" }, label = { Text("Solo interés") }) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = auto, onClick = { auto = true }, label = { Text("Automática") })
                FilterChip(selected = !auto, onClick = { auto = false }, label = { Text("Manual") })
            }
            if (!auto) {
                OutlinedTextField(toInterest, { toInterest = it }, label = { Text("A intereses") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                OutlinedTextField(toPrincipal, { toPrincipal = it }, label = { Text("A capital") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                Text("El total asignado debe coincidir con el monto (sin excedente no autorizado).", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                Text("Automática: intereses pendientes primero, luego capital.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("Método", style = MaterialTheme.typography.labelMedium)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(PaymentMethod.entries.size) { i ->
                    val m = PaymentMethod.entries[i]
                    FilterChip(selected = method == m, onClick = { method = m }, label = { Text(m.name) })
                }
            }
            if (pendingSurplus != null) {
                ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Column(Modifier.padding(8.dp)) {
                        Text("Excedente detectado: ${MoneyFormatter.format(pendingSurplus)}", color = MaterialTheme.colorScheme.onErrorContainer)
                        Text("Confirme para registrar el pago y dejar el excedente registrado.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }, confirmButton = {
        if (pendingSurplus != null) {
            TextButton(onClick = { onSubmit(amount, method, auto, toInterest, toPrincipal, true) }) { Text("Confirmar con excedente") }
        } else {
            TextButton(onClick = { onSubmit(amount, method, auto, toInterest, toPrincipal, false) }) { Text("Registrar") }
        }
    }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } })
}

@Composable
private fun SettleDialog(loan: com.dpm.prestamos.domain.model.Loan, onDismiss: () -> Unit, onSubmit: (String, String, PaymentMethod) -> Unit) {
    var interest by remember { mutableStateOf(loan.interestOutstanding.toPlainString()) }
    var discount by remember { mutableStateOf("0") }
    var method by remember { mutableStateOf(PaymentMethod.EFECTIVO) }
    val totalPreview = runCatching {
        val i = Money.of(interest.ifBlank { "0" }); val d = Money.of(discount.ifBlank { "0" })
        MoneyFormatter.format(loan.principalOutstanding + i - d)
    }.getOrElse { "-" }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Liquidación anticipada") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Capital pendiente: ${MoneyFormatter.format(loan.principalOutstanding)}")
            OutlinedTextField(interest, { interest = it }, label = { Text("Intereses devengados no pagados") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
            OutlinedTextField(discount, { discount = it }, label = { Text("Descuento autorizado") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
            Text("Total estimado: $totalPreview", color = MaterialTheme.colorScheme.primary)
            Text("Se solicitará confirmación al registrar.", style = MaterialTheme.typography.bodySmall)
        }
    }, confirmButton = { TextButton(onClick = { onSubmit(interest, discount, method) }) { Text("Confirmar liquidación") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } })
}

@Composable
private fun VoidDialog(payment: Payment, onDismiss: () -> Unit, onSubmit: (String) -> Unit) {
    var reason by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Anular pago") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Recibo: ${payment.receiptNumber}")
            Text("Monto: ${MoneyFormatter.format(payment.amountTotal)}")
            Text("La anulación revierte saldos y caja y queda registrada (no se elimina).", style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(reason, { reason = it }, label = { Text("Motivo de anulación") })
        }
    }, confirmButton = { TextButton(onClick = { onSubmit(reason) }) { Text("Anular", color = MaterialTheme.colorScheme.error) } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } })
}
