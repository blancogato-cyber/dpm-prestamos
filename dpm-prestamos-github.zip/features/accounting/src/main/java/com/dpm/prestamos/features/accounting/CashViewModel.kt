package com.dpm.prestamos.features.accounting

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.domain.enums.CashTxType
import com.dpm.prestamos.domain.repository.CashAccount
import com.dpm.prestamos.domain.repository.CashRepository
import com.dpm.prestamos.domain.repository.CashTx
import com.dpm.prestamos.domain.usecase.cash.CashOpResult
import com.dpm.prestamos.domain.usecase.cash.CashOperator
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class CashUiState(
    val account: CashAccount? = null,
    val transactions: List<CashTx> = emptyList(),
    val message: String? = null
)

@HiltViewModel
class CashViewModel @Inject constructor(
    repository: CashRepository,
    private val operator: CashOperator
) : ViewModel() {
    private val message = MutableStateFlow<String?>(null)
    val uiState: StateFlow<CashUiState> = combine(repository.observeAccount(), repository.observeTransactions(), message) { acc, txs, msg ->
        CashUiState(acc, txs, msg)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), CashUiState())

    fun register(type: CashTxType, amountText: String, notes: String, justification: String) {
        viewModelScope.launch {
            val amount = runCatching { Money.of(amountText) }.getOrNull()
            if (amount == null) { message.value = "Monto inválido"; return@launch }
            when (val r = operator.register(type, amount, notes.ifBlank { null }, justification.ifBlank { null })) {
                is CashOpResult.Success -> message.value = "Movimiento registrado"
                is CashOpResult.Error -> message.value = r.message
            }
        }
    }
    fun clearMessage() { message.value = null }
}
