package com.dpm.prestamos.features.accounting

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dpm.prestamos.domain.model.AccountingSummary
import com.dpm.prestamos.domain.usecase.accounting.GetAccountingSummaryUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AccountingViewModel @Inject constructor(private val getSummary: GetAccountingSummaryUseCase) : ViewModel() {
    private val _summary = MutableStateFlow<AccountingSummary?>(null)
    val summary: StateFlow<AccountingSummary?> = _summary
    init { refresh() }
    fun refresh() { viewModelScope.launch { runCatching { getSummary() }.onSuccess { _summary.value = it } } }
}
