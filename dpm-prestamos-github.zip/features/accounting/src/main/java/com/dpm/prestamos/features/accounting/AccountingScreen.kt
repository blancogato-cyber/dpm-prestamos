package com.dpm.prestamos.features.accounting

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dpm.prestamos.core.money.MoneyFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountingScreen(onBack: () -> Unit, viewModel: AccountingViewModel = hiltViewModel()) {
    val summary by viewModel.summary.collectAsStateWithLifecycle()
    Scaffold(topBar = { TopAppBar(title = { Text("Contabilidad") }, navigationIcon = { TextButton(onClick = onBack) { Text("Atrás") } }) }) { padding ->
        LazyColumn(Modifier.padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (summary == null) {
                item { CircularProgressIndicator() }
            } else {
                val s = summary!!
                item { SectionCard("Capital") {
                    RowItem("Capital total entregado", MoneyFormatter.format(s.capitalDisbursed))
                    RowItem("Capital recuperado", MoneyFormatter.format(s.capitalRecovered))
                    RowItem("Capital pendiente", MoneyFormatter.format(s.capitalPending))
                } }
                item { SectionCard("Intereses") {
                    RowItem("Intereses generados", MoneyFormatter.format(s.interestGenerated))
                    RowItem("Intereses cobrados", MoneyFormatter.format(s.interestCollected), positive = true)
                    RowItem("Intereses pendientes", MoneyFormatter.format(s.interestPending))
                    RowItem("Ganancias reales (intereses)", MoneyFormatter.format(s.realProfitFromInterest), positive = true)
                } }
                item { SectionCard("Disponibilidad y cartera") {
                    RowItem("Dinero disponible (caja)", MoneyFormatter.format(s.cashAvailable), positive = true)
                    Text("Préstamos activos: ${s.activeLoans}  •  Liquidados: ${s.settledLoans}")
                    Text("Nota: el capital recuperado no se contabiliza como ganancia.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } }
            }
        }
    }
}

@Composable private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    ElevatedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) { Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary); content() } }
}
@Composable private fun RowItem(label: String, value: String, positive: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(label); Text(value, color = if (positive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface) }
}
