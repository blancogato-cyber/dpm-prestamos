package com.dpm.prestamos.features.accounting

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dpm.prestamos.core.money.MoneyFormatter
import com.dpm.prestamos.domain.enums.CashTxType

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CashScreen(onBack: () -> Unit, viewModel: CashViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    var showAdd by remember { mutableStateOf(false) }
    LaunchedEffect(state.message) { state.message?.let { snackbar.showSnackbar(it); viewModel.clearMessage() } }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Control de caja") }, navigationIcon = { TextButton(onClick = onBack) { Text("Atrás") } }) },
        snackbarHost = { SnackbarHost(snackbar) },
        floatingActionButton = { FloatingActionButton(onClick = { showAdd = true }) { Icon(Icons.Default.Add, contentDescription = "Registrar") } }
    ) { padding ->
        LazyColumn(Modifier.padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Saldo disponible", style = MaterialTheme.typography.titleMedium)
                        Text(MoneyFormatter.format(state.account?.currentBalance ?: com.dpm.prestamos.core.money.Money.ZERO), style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
                        Text(state.account?.name ?: "Caja principal", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        state.account?.let { Text("Saldo inicial: ${MoneyFormatter.format(it.initialBalance)}", style = MaterialTheme.typography.bodySmall) }
                    }
                }
            }
            item { Text("Movimientos de caja", style = MaterialTheme.typography.titleMedium) }
            if (state.transactions.isEmpty()) {
                item { Text("Sin movimientos de caja. Registra saldo inicial, aportes, retiros, gastos o ajustes.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            } else {
                items(state.transactions, key = { it.id }) { tx ->
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text("${tx.type} • ${MoneyFormatter.format(tx.amount)}", color = if (tx.amount.isNegative()) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                            Text("${tx.occurredAt}", style = MaterialTheme.typography.bodySmall)
                            tx.notes?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                }
            }
        }
    }
    if (showAdd) CashOpDialog(onDismiss = { showAdd = false }) { type, amount, notes, just -> viewModel.register(type, amount, notes, just); showAdd = false }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CashOpDialog(onDismiss: () -> Unit, onSubmit: (CashTxType, String, String, String) -> Unit) {
    var type by remember { mutableStateOf(CashTxType.APORTE) }
    var amount by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var justification by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }
    val options = listOf(CashTxType.SALDO_INICIAL, CashTxType.APORTE, CashTxType.RETIRO, CashTxType.GASTO_OPERATIVO, CashTxType.AJUSTE)
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Registrar movimiento de caja") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                OutlinedTextField(type.name, {}, readOnly = true, label = { Text("Tipo") }, modifier = Modifier.menuAnchor().fillMaxWidth())
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    options.forEach { opt -> DropdownMenuItem(text = { Text(opt.name.replace('_', ' ')) }, onClick = { type = opt; expanded = false }) }
                }
            }
            OutlinedTextField(amount, { amount = it }, label = { Text("Monto (RD$)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            OutlinedTextField(notes, { notes = it }, label = { Text("Nota/Concepto") }, singleLine = true)
            if (type == CashTxType.AJUSTE) {
                OutlinedTextField(justification, { justification = it }, label = { Text("Justificación (obligatoria)") })
            }
            Text(if (type == CashTxType.RETIRO || type == CashTxType.GASTO_OPERATIVO) "Se registrará como egreso." else "Se registrará como ingreso.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }, confirmButton = { TextButton(onClick = { onSubmit(type, amount, notes, justification) }) { Text("Guardar") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } })
}
