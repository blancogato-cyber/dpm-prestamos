package com.dpm.prestamos.features.payments

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dpm.prestamos.core.money.MoneyFormatter

@Composable
fun MovementsScreen(viewModel: MovementsViewModel = hiltViewModel()) {
    val items by viewModel.movements.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Movimientos", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
        if (items.isEmpty()) {
            Text("Sin movimientos registrados.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(items, key = { it.id }) { m ->
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text("${m.type} • ${MoneyFormatter.format(m.amount)}", style = MaterialTheme.typography.titleSmall)
                            Text("Fecha: ${m.timestamp}", style = MaterialTheme.typography.bodySmall)
                            Text("Saldo: ${MoneyFormatter.format(m.balanceBefore)} → ${MoneyFormatter.format(m.balanceAfter)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                            m.reference?.let { Text("Ref: $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        }
                    }
                }
            }
        }
    }
}
