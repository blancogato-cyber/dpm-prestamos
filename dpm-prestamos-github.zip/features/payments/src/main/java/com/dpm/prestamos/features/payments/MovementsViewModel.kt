package com.dpm.prestamos.features.payments

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dpm.prestamos.domain.model.Movement
import com.dpm.prestamos.domain.usecase.payment.ObserveRecentMovementsUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

@HiltViewModel
class MovementsViewModel @Inject constructor(
    observeRecent: ObserveRecentMovementsUseCase
) : ViewModel() {
    val movements: StateFlow<List<Movement>> = observeRecent(200)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
}
