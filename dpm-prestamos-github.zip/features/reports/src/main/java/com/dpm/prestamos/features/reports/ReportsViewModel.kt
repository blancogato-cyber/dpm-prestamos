package com.dpm.prestamos.features.reports

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dpm.prestamos.domain.usecase.reports.ExportFormat
import com.dpm.prestamos.domain.usecase.reports.ExportResult
import com.dpm.prestamos.domain.usecase.reports.ReportExporter
import com.dpm.prestamos.domain.usecase.reports.ReportType
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.time.LocalDate
import javax.inject.Inject

data class ReportsUiState(val loading: Boolean = false, val message: String? = null, val lastExport: ExportResult? = null)

@HiltViewModel
class ReportsViewModel @Inject constructor(private val exporter: ReportExporter) : ViewModel() {
    private val _state = MutableStateFlow(ReportsUiState())
    val state: StateFlow<ReportsUiState> = _state

    fun export(type: ReportType, format: ExportFormat, from: String? = null, to: String? = null) {
        viewModelScope.launch {
            val fromDate = from?.trim()?.takeIf { it.isNotBlank() }?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
            val toDate = to?.trim()?.takeIf { it.isNotBlank() }?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
            _state.value = ReportsUiState(loading = true)
            val res = exporter.export(type, format, fromDate, toDate)
            _state.value = res.fold(
                onSuccess = { ReportsUiState(message = "Exportado: ${it.displayName}", lastExport = it) },
                onFailure = { ReportsUiState(message = "Error: ${it.message}") }
            )
        }
    }
    fun clear() { _state.value = _state.value.copy(message = null) }
}
