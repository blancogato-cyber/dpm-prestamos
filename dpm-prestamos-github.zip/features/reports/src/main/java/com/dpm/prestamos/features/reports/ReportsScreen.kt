package com.dpm.prestamos.features.reports

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dpm.prestamos.domain.usecase.reports.ExportFormat
import com.dpm.prestamos.domain.usecase.reports.ReportType
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(onBack: () -> Unit, viewModel: ReportsViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(state.message) { state.message?.let { snackbar.showSnackbar(it); viewModel.clear() } }

    var fromDate by remember { mutableStateOf("") }
    var toDate by remember { mutableStateOf("") }

    Scaffold(topBar = { TopAppBar(title = { Text("Reportes y exportación") }, navigationIcon = { TextButton(onClick = onBack) { Text("Atrás") } }) }, snackbarHost = { SnackbarHost(snackbar) }) { padding ->
        LazyColumn(Modifier.padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { Text("Genera informes en PDF o CSV (compatible con Excel). Puedes filtrar por rango de fechas y compartir el archivo generado.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            item {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Filtro por rango (opcional)", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                        OutlinedTextField(fromDate, { fromDate = it }, label = { Text("Desde (AAAA-MM-DD)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(toDate, { toDate = it }, label = { Text("Hasta (AAAA-MM-DD)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Text("Aplica según reporte: clientes (creación), préstamos/intereses (inicio), pagos/caja (fecha), cartera (inicio o vencimiento).", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            val reports = listOf(
                ReportType.CLIENTES to "Clientes",
                ReportType.PRESTAMOS to "Préstamos",
                ReportType.PAGOS to "Pagos",
                ReportType.CAJA to "Caja",
                ReportType.INTERESES to "Intereses",
                ReportType.CARTERA to "Cartera vigente"
            )
            reports.forEach { (type, label) ->
                item {
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(label, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { viewModel.export(type, ExportFormat.PDF, fromDate, toDate) }, enabled = !state.loading) { Text("PDF") }
                                OutlinedButton(onClick = { viewModel.export(type, ExportFormat.CSV, fromDate, toDate) }, enabled = !state.loading) { Text("CSV/Excel") }
                            }
                        }
                    }
                }
            }
            state.lastExport?.let { exp ->
                item {
                    Button(onClick = { shareFile(ctx, exp.filePath, exp.mimeType) }, modifier = Modifier.fillMaxWidth()) { Text("Compartir último archivo: ${exp.displayName}") }
                }
            }
            if (state.loading) item { CircularProgressIndicator() }
        }
    }
}

private fun shareFile(context: android.content.Context, path: String, mime: String) {
    val file = File(path)
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = mime
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Compartir reporte"))
}
