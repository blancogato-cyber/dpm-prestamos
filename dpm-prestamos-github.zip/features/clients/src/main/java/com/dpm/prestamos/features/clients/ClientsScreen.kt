package com.dpm.prestamos.features.clients

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClientsScreen(onClientClick: (Long) -> Unit = {}, viewModel: ClientsViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var showAdd by remember { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(state.message) {
        state.message?.let { snackbar.showSnackbar(it); viewModel.clearMessage(); if (it == "Cliente registrado") showAdd = false }
    }

    Scaffold(
        floatingActionButton = { FloatingActionButton(onClick = { showAdd = true }) { Icon(Icons.Default.Add, "Nuevo cliente") } },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Clientes", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
            OutlinedTextField(
                value = state.query, onValueChange = viewModel::onQueryChange,
                modifier = Modifier.fillMaxWidth(), label = { Text("Buscar por nombre o teléfono") },
                leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true
            )
            if (state.clients.isEmpty()) {
                Text("Sin clientes registrados.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(state.clients, key = { it.id }) { c ->
                        ElevatedCard(onClick = { onClientClick(c.id) }, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {
                                Text(c.fullName, style = MaterialTheme.typography.titleMedium)
                                Text(c.phone, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                c.documentId?.let { Text("ID: $it", style = MaterialTheme.typography.bodySmall) }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAdd) AddClientDialog(onDismiss = { showAdd = false }, onSave = viewModel::create)
}

@Composable
fun AddClientDialog(onDismiss: () -> Unit, onSave: (String, String, String?, String?, String?) -> Unit) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var doc by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("Nuevo cliente") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nombre completo *") }, singleLine = true)
                OutlinedTextField(phone, { phone = it }, label = { Text("Teléfono *") }, singleLine = true)
                OutlinedTextField(address, { address = it }, label = { Text("Dirección") })
                OutlinedTextField(doc, { doc = it }, label = { Text("Identificación") })
                OutlinedTextField(notes, { notes = it }, label = { Text("Observaciones") })
            }
        },
        confirmButton = { TextButton(onClick = { onSave(name, phone, address, doc, notes) }) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
