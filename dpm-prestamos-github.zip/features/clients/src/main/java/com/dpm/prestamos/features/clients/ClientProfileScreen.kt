package com.dpm.prestamos.features.clients

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dpm.prestamos.core.money.MoneyFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClientProfileScreen(onBack: () -> Unit, viewModel: ClientProfileViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    Scaffold(topBar = { TopAppBar(title = { Text("Perfil del cliente") }, navigationIcon = { TextButton(onClick = onBack) { Text("Atrás") } }) }) { padding ->
        val p = state.profile
        if (p == null) {
            Box(Modifier.padding(padding).padding(24.dp)) { if (state.loading) CircularProgressIndicator() else Text("Cliente no encontrado") }
        } else {
            LazyColumn(Modifier.padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(p.client.fullName, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                            Text(p.client.phone)
                            p.client.address?.let { Text(it) }
                            p.client.documentId?.let { Text("ID: $it") }
                            Text("Registrado: ${p.client.createdAt}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                item {
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Resumen financiero", style = MaterialTheme.typography.titleMedium)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Total histórico prestado"); Text(MoneyFormatter.format(p.totalHistoricLent), color = MaterialTheme.colorScheme.primary) }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Total histórico recuperado"); Text(MoneyFormatter.format(p.totalHistoricRecovered), color = MaterialTheme.colorScheme.primary) }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Intereses pagados"); Text(MoneyFormatter.format(p.interestPaid), color = MaterialTheme.colorScheme.primary) }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Deuda actual"); Text(MoneyFormatter.format(p.currentDebt), color = if (p.currentDebt.isPositive()) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary) }
                            Text("Activos: ${p.activeLoans}  •  Vencidos: ${p.overdueLoans}  •  Liquidados: ${p.settledLoans}")
                            Text("Último pago: ${p.lastPaymentDate ?: "N/A"}")
                        }
                    }
                }
                item { Text("Préstamos del cliente", style = MaterialTheme.typography.titleMedium) }
                if (state.loans.isEmpty()) item { Text("Sin préstamos.") } else items(state.loans, key = { it.id }) { loan ->
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text("${loan.loanNumber} • ${loan.status}")
                            Text("Saldo: ${MoneyFormatter.format(loan.totalBalance)}  Vence: ${loan.dueDate}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}
