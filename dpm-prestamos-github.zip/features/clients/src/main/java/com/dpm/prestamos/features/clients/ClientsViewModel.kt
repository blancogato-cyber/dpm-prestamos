package com.dpm.prestamos.features.clients

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dpm.prestamos.domain.model.Client
import com.dpm.prestamos.domain.usecase.client.CreateClientUseCase
import com.dpm.prestamos.domain.usecase.client.ObserveClientsUseCase
import com.dpm.prestamos.domain.usecase.client.SearchClientsUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import javax.inject.Inject

data class ClientsUiState(
    val query: String = "",
    val clients: List<Client> = emptyList(),
    val message: String? = null
)

@HiltViewModel
class ClientsViewModel @Inject constructor(
    observeClients: ObserveClientsUseCase,
    private val searchClients: SearchClientsUseCase,
    private val createClient: CreateClientUseCase
) : ViewModel() {
    private val query = MutableStateFlow("")
    private val message = MutableStateFlow<String?>(null)
    private val clientsFlow = query.flatMapLatest { q ->
        if (q.isBlank()) observeClients() else searchClients(q)
    }
    val uiState: StateFlow<ClientsUiState> = combine(query, clientsFlow, message) { q, clients, msg ->
        ClientsUiState(query = q, clients = clients, message = msg)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ClientsUiState())

    fun onQueryChange(value: String) { query.value = value }
    fun clearMessage() { message.value = null }

    fun create(name: String, phone: String, address: String?, document: String?, notes: String?) {
        viewModelScope.launch {
            val result = createClient(
                Client(
                    fullName = name.trim(), phone = phone.trim(),
                    address = address?.takeIf { it.isNotBlank() },
                    documentId = document?.takeIf { it.isNotBlank() },
                    notes = notes?.takeIf { it.isNotBlank() },
                    createdAt = LocalDate.now()
                )
            )
            message.value = when (result) {
                is CreateClientUseCase.Result.Success -> "Cliente registrado"
                is CreateClientUseCase.Result.Duplicate -> result.message
                is CreateClientUseCase.Result.Invalid -> result.message
            }
        }
    }
}
