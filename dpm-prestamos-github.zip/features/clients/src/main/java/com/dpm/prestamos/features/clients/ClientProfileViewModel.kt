package com.dpm.prestamos.features.clients

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dpm.prestamos.domain.model.ClientProfile
import com.dpm.prestamos.domain.model.Loan
import com.dpm.prestamos.domain.repository.ClientRepository
import com.dpm.prestamos.domain.repository.LoanRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ClientProfileUiState(val profile: ClientProfile? = null, val loans: List<Loan> = emptyList(), val loading: Boolean = true)

@HiltViewModel
class ClientProfileViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val clientRepository: ClientRepository,
    loanRepository: LoanRepository
) : ViewModel() {
    private val clientId: Long = savedStateHandle.get<String>("clientId")?.toLongOrNull() ?: -1L
    private val profile = MutableStateFlow<ClientProfile?>(null)
    private val loading = MutableStateFlow(true)

    val uiState: StateFlow<ClientProfileUiState> = combine(profile, loanRepository.observeByClient(clientId), loading) { p, loans, l ->
        ClientProfileUiState(p, loans, l)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ClientProfileUiState())

    init { refresh() }
    fun refresh() { viewModelScope.launch { loading.value = true; profile.value = clientRepository.getProfile(clientId); loading.value = false } }
}
