package com.dpm.prestamos.features.dashboard

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dpm.prestamos.core.money.MoneyFormatter
import com.dpm.prestamos.domain.model.Loan

@Composable
fun DashboardScreen(
    onNewLoan: () -> Unit = {},
    viewModel: DashboardViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("DPM", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
            Text("Resumen financiero", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            Button(onClick = onNewLoan, modifier = Modifier.fillMaxWidth()) { Text("Nuevo préstamo") }
        }
        state.summary?.let { s ->
            item {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Kpi("Dinero total por recuperar", MoneyFormatter.format(s.totalToRecover), true)
                        Kpi("Capital pendiente", MoneyFormatter.format(s.principalOutstanding), true)
                        Kpi("Intereses pendientes", MoneyFormatter.format(s.interestOutstanding), true)
                        Kpi("Intereses cobrados", MoneyFormatter.format(s.interestCollected), true)
                        Kpi("Dinero recuperado", MoneyFormatter.format(s.moneyRecovered), true)
                        Divider()
                        Text("Préstamos activos: ${s.activeLoans}  •  Vencidos: ${s.overdueLoans}  •  Liquidados: ${s.settledLoans}")
                        Text("Pagos recibidos hoy: ${s.paymentsToday}")
                    }
                }
            }
        } ?: if (state.loading) item { CircularProgressIndicator() }
        item { Text("Préstamos recientes", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.secondary) }
        if (state.recentLoans.isEmpty()) {
            item { Text("No hay préstamos registrados.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        } else {
            items(state.recentLoans, key = { it.id }) { loan -> LoanRecentCard(loan, state.clientNames[loan.clientId]) }
        }
    }
}

@Composable
private fun Kpi(label: String, value: String, positive: Boolean) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(value, fontWeight = FontWeight.SemiBold, color = if (positive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
    }
}

@Composable
private fun LoanRecentCard(loan: Loan, clientName: String?) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(clientName ?: "Cliente", style = MaterialTheme.typography.titleSmall)
            Text("Préstamo ${loan.loanNumber}", style = MaterialTheme.typography.bodyMedium)
            Text("Capital: ${MoneyFormatter.format(loan.principalOriginal)}  •  Pendiente: ${MoneyFormatter.format(loan.principalOutstanding)}", style = MaterialTheme.typography.bodySmall)
            Text("Intereses pend.: ${MoneyFormatter.format(loan.interestOutstanding)}  •  Saldo: ${MoneyFormatter.format(loan.totalBalance)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
            Text("Vence: ${loan.dueDate}  •  Estado: ${loan.status}", style = MaterialTheme.typography.bodySmall, color = if (loan.status.name == "VENCIDO") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
