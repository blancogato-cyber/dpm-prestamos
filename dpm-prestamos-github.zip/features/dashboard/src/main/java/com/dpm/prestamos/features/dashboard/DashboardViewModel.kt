package com.dpm.prestamos.features.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dpm.prestamos.domain.model.Loan
import com.dpm.prestamos.domain.repository.FinancialSummary
import com.dpm.prestamos.domain.repository.LoanRepository
import com.dpm.prestamos.domain.usecase.accounting.GetDashboardSummaryUseCase
import com.dpm.prestamos.domain.usecase.client.ObserveClientsUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class DashboardUiState(
    val summary: FinancialSummary? = null,
    val recentLoans: List<Loan> = emptyList(),
    val clientNames: Map<Long, String> = emptyMap(),
    val loading: Boolean = true
)

@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val getSummary: GetDashboardSummaryUseCase,
    loanRepository: LoanRepository,
    observeClients: ObserveClientsUseCase
) : ViewModel() {
    private val summaryState = MutableStateFlow<FinancialSummary?>(null)
    private val loading = MutableStateFlow(true)

    val uiState: StateFlow<DashboardUiState> = combine(
        summaryState,
        loanRepository.observeAll().map { it.take(10) },
        observeClients().map { clients -> clients.associate { it.id to it.fullName } },
        loading
    ) { summary, loans, names, isLoading ->
        DashboardUiState(summary = summary, recentLoans = loans, clientNames = names, loading = isLoading)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardUiState())

    init { refresh() }

    fun refresh() {
        viewModelScope.launch {
            loading.value = true
            runCatching { getSummary() }.onSuccess { summaryState.value = it }
            loading.value = false
        }
    }
}
