package com.dpm.prestamos.features.security

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.dpm.prestamos.domain.repository.SecurityRepository
import com.dpm.prestamos.domain.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class LockUiState(val locked: Boolean = false, val checking: Boolean = true, val error: String? = null, val hasPin: Boolean = false, val autoLockMinutes: Int = 2, val biometricEnabled: Boolean = false)

@HiltViewModel
class LockViewModel @Inject constructor(
    private val security: SecurityRepository,
    settingsRepository: SettingsRepository
) : ViewModel() {
    private val _state = MutableStateFlow(LockUiState())
    val state: StateFlow<LockUiState> = _state
    init {
        viewModelScope.launch {
            val has = security.hasPin()
            _state.value = _state.value.copy(locked = has, checking = false, hasPin = has)
            settingsRepository.settings.collect { s ->
                _state.value = _state.value.copy(autoLockMinutes = s.autoLockMinutes, biometricEnabled = s.biometricEnabled)
            }
        }
    }
    fun unlock(pin: String) {
        viewModelScope.launch {
            val ok = security.verifyPin(pin)
            _state.value = if (ok) _state.value.copy(locked = false, error = null) else _state.value.copy(error = "PIN incorrecto")
        }
    }
    fun unlockWithBiometric() { _state.value = _state.value.copy(locked = false, error = null) }
    fun lockIfNeeded() { if (_state.value.hasPin && !_state.value.locked) _state.value = _state.value.copy(locked = true) }
    fun clearError() { _state.value = _state.value.copy(error = null) }
}

@Composable
fun AppLockGate(content: @Composable () -> Unit, viewModel: LockViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var lastInteraction by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(state.locked, state.hasPin, state.autoLockMinutes) {
        if (!state.locked && state.hasPin) {
            val timeoutMs = state.autoLockMinutes.coerceAtLeast(1) * 60_000L
            while (true) {
                delay(15_000L)
                if (state.locked || !state.hasPin) break
                if (System.currentTimeMillis() - lastInteraction >= timeoutMs) {
                    viewModel.lockIfNeeded()
                    break
                }
            }
        }
    }
    when {
        state.checking -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        state.locked -> LockScreen(
            error = state.error,
            biometricEnabled = state.biometricEnabled,
            onUnlock = { viewModel.unlock(it); lastInteraction = System.currentTimeMillis() },
            onBiometricUnlock = { viewModel.unlockWithBiometric(); lastInteraction = System.currentTimeMillis() },
            onClearError = viewModel::clearError
        )
        else -> Box(Modifier.fillMaxSize().pointerInput(Unit) {
            awaitEachGesture {
                awaitFirstDown(requireUnconsumed = false)
                lastInteraction = System.currentTimeMillis()
                do { val event = awaitPointerEvent(); } while (event.changes.any { it.pressed })
            }
        }) { content() }
    }
}

@Composable
fun LockScreen(error: String?, biometricEnabled: Boolean = false, onUnlock: (String) -> Unit, onBiometricUnlock: () -> Unit = {}, onClearError: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    val context = androidx.compose.ui.platform.LocalContext.current
    val activity = context as? androidx.fragment.app.FragmentActivity
    val canBio = biometricEnabled && activity != null && BiometricHelper.canAuthenticate(context)
    LaunchedEffect(error) { if (error != null) pin = "" }
    LaunchedEffect(canBio) {
        if (canBio) {
            BiometricHelper.authenticate(activity!!, "Desbloquear DPM", "Use su huella o rostro", onBiometricUnlock) { /* fallback to PIN */ }
        }
    }
    Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("DPM", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(8.dp))
        Text("Ingrese su PIN para continuar", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(pin, { pin = it.filter(Char::isDigit); if (error != null) onClearError() }, label = { Text("PIN") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true)
        if (error != null) { Spacer(Modifier.height(8.dp)); Text(error, color = MaterialTheme.colorScheme.error) }
        Spacer(Modifier.height(16.dp))
        Button(onClick = { onUnlock(pin) }, modifier = Modifier.fillMaxWidth()) { Text("Desbloquear") }
        if (canBio) {
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { BiometricHelper.authenticate(activity!!, "Desbloquear DPM", "Use su huella o rostro", onBiometricUnlock) {} }, modifier = Modifier.fillMaxWidth()) { Text("Usar biometría") }
        }
    }
}
