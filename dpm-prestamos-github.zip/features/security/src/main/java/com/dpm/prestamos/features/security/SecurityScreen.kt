package com.dpm.prestamos.features.security

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.dpm.prestamos.domain.repository.SecurityRepository
import com.dpm.prestamos.domain.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SecurityUiState(val hasPin: Boolean = false, val biometricEnabled: Boolean = false, val message: String? = null)

@HiltViewModel
class SecurityViewModel @Inject constructor(
    private val security: SecurityRepository,
    private val settings: SettingsRepository
) : ViewModel() {
    private val _state = MutableStateFlow(SecurityUiState())
    val state: StateFlow<SecurityUiState> = _state
    init {
        viewModelScope.launch {
            val has = security.hasPin()
            _state.value = _state.value.copy(hasPin = has)
            settings.settings.collect { s -> _state.value = _state.value.copy(biometricEnabled = s.biometricEnabled) }
        }
    }

    fun setPin(pin: String, confirm: String) {
        viewModelScope.launch {
            if (pin.length < 4) { _state.value = _state.value.copy(message = "El PIN debe tener al menos 4 dígitos"); return@launch }
            if (pin != confirm) { _state.value = _state.value.copy(message = "Los PIN no coinciden"); return@launch }
            security.setPin(pin)
            _state.value = _state.value.copy(hasPin = true, message = "PIN configurado")
        }
    }
    fun removePin(current: String) {
        viewModelScope.launch {
            if (!security.verifyPin(current)) { _state.value = _state.value.copy(message = "PIN actual incorrecto"); return@launch }
            security.clearPin()
            settings.update { it.copy(biometricEnabled = false) }
            _state.value = _state.value.copy(hasPin = false, biometricEnabled = false, message = "PIN eliminado")
        }
    }
    fun setBiometric(enabled: Boolean) { viewModelScope.launch { settings.update { it.copy(biometricEnabled = enabled) }; _state.value = _state.value.copy(biometricEnabled = enabled) } }
    fun clear() { _state.value = _state.value.copy(message = null) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SecurityScreen(onBack: () -> Unit, viewModel: SecurityViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var current by remember { mutableStateOf("") }
    LaunchedEffect(state.message) { state.message?.let { snackbar.showSnackbar(it); viewModel.clear() } }
    Scaffold(topBar = { TopAppBar(title = { Text("Seguridad") }, navigationIcon = { TextButton(onClick = onBack) { Text("Atrás") } }) }, snackbarHost = { SnackbarHost(snackbar) }) { padding ->
        LazyColumn(Modifier.padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { Text(if (state.hasPin) "PIN activo. La app solicitará desbloqueo al iniciar." else "Sin PIN configurado.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            if (!state.hasPin) {
                item { Text("Configurar PIN", style = MaterialTheme.typography.titleMedium) }
                item { OutlinedTextField(pin, { pin = it.filter(Char::isDigit) }, label = { Text("Nuevo PIN (4+ dígitos)") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true) }
                item { OutlinedTextField(confirm, { confirm = it.filter(Char::isDigit) }, label = { Text("Confirmar PIN") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true) }
                item { Button(onClick = { viewModel.setPin(pin, confirm); pin = ""; confirm = "" }, modifier = Modifier.fillMaxWidth()) { Text("Guardar PIN") } }
            } else {
                item { Text("Eliminar PIN", style = MaterialTheme.typography.titleMedium) }
                item { OutlinedTextField(current, { current = it.filter(Char::isDigit) }, label = { Text("PIN actual") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true) }
                item { Button(onClick = { viewModel.removePin(current); current = "" }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Text("Eliminar PIN") } }
                item { Divider() }
                val ctx = androidx.compose.ui.platform.LocalContext.current
                val canBio = BiometricHelper.canAuthenticate(ctx)
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Desbloqueo biométrico", style = MaterialTheme.typography.titleMedium)
                            Text(if (canBio) "Usar huella/rostro además del PIN" else "No disponible en este dispositivo", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = state.biometricEnabled, onCheckedChange = { viewModel.setBiometric(it) }, enabled = canBio)
                    }
                }
            }
            item { Divider() }
            item { Text("Operaciones sensibles (anulación, reestructuración, ajustes de caja) requieren confirmación y motivo. Los movimientos financieros no se eliminan; se anulan con trazabilidad.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            item { Text("El bloqueo automático por inactividad aplica cuando hay PIN activo (configurable en Ajustes).", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
}
