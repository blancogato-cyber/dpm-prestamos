package com.dpm.prestamos.features.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.dpm.prestamos.domain.repository.AppSettings
import com.dpm.prestamos.domain.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(private val repo: SettingsRepository) : ViewModel() {
    val settings: StateFlow<AppSettings> = repo.settings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())
    fun save(rate: String, term: String, grace: String, upcoming: String, autoLock: String) {
        viewModelScope.launch {
            repo.update {
                it.copy(
                    defaultRatePercent = rate.ifBlank { "20" },
                    defaultTermDays = term.toIntOrNull() ?: 30,
                    gracePeriodDays = grace.toIntOrNull() ?: 0,
                    upcomingDays = upcoming.toIntOrNull() ?: 3,
                    autoLockMinutes = autoLock.toIntOrNull()?.coerceAtLeast(0) ?: 2
                )
            }
        }
    }
    fun setReminders(enabled: Boolean) { viewModelScope.launch { repo.update { it.copy(remindersEnabled = enabled) } } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit, onEnableReminders: () -> Unit = {}, onDisableReminders: () -> Unit = {}, viewModel: SettingsViewModel = hiltViewModel()) {
    val s by viewModel.settings.collectAsStateWithLifecycle()
    var rate by remember(s.defaultRatePercent) { mutableStateOf(s.defaultRatePercent) }
    var term by remember(s.defaultTermDays) { mutableStateOf(s.defaultTermDays.toString()) }
    var grace by remember(s.gracePeriodDays) { mutableStateOf(s.gracePeriodDays.toString()) }
    var upcoming by remember(s.upcomingDays) { mutableStateOf(s.upcomingDays.toString()) }
    var autoLock by remember(s.autoLockMinutes) { mutableStateOf(s.autoLockMinutes.toString()) }
    var msg by remember { mutableStateOf<String?>(null) }
    Scaffold(topBar = { TopAppBar(title = { Text("Configuración") }, navigationIcon = { TextButton(onClick = onBack) { Text("Atrás") } }) }) { padding ->
        LazyColumn(Modifier.padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { Text("Valores predeterminados y preferencias", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            item { OutlinedTextField(rate, { rate = it }, label = { Text("Tasa de interés predeterminada (%)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true) }
            item { OutlinedTextField(term, { term = it }, label = { Text("Plazo predeterminado (días)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true) }
            item { OutlinedTextField(grace, { grace = it }, label = { Text("Período de gracia (días)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true) }
            item { OutlinedTextField(upcoming, { upcoming = it }, label = { Text("Avisar próximos a vencer (días)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true) }
            item { OutlinedTextField(autoLock, { autoLock = it }, label = { Text("Bloqueo automático por inactividad (min, 0=desact.)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true) }
            item { Button(onClick = { viewModel.save(rate, term, grace, upcoming, autoLock); msg = "Configuración guardada" }, modifier = Modifier.fillMaxWidth()) { Text("Guardar") } }
            msg?.let { item { Text(it, color = MaterialTheme.colorScheme.primary) } }
            item { Divider() }
            item { Text("Recordatorios y notificaciones", style = MaterialTheme.typography.titleMedium) }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Recordatorios de pagos")
                        Text("Avisos periódicos de préstamos próximos a vencer y en atraso/mora (según días configurados). Requiere permiso de notificaciones en Android 13+.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = s.remindersEnabled, onCheckedChange = {
                        viewModel.setReminders(it)
                        if (it) onEnableReminders() else onDisableReminders()
                    })
                }
            }
            item { Divider() }
            item { Text("Moneda: RD$ (DOP) • Zona horaria: America/Santo_Domingo", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            item { Text("Los cambios de tasas/plazos predeterminados aplican a nuevos préstamos; la gracia se configura por préstamo o como valor base.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
}
