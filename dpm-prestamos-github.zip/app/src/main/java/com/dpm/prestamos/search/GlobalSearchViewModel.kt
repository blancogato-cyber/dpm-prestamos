package com.dpm.prestamos.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dpm.prestamos.domain.model.Client
import com.dpm.prestamos.domain.model.Loan
import com.dpm.prestamos.domain.repository.ClientRepository
import com.dpm.prestamos.domain.repository.LoanRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import javax.inject.Inject

data class GlobalSearchUiState(
    val query: String = "",
    val clients: List<Client> = emptyList(),
    val loans: List<Loan> = emptyList(),
    val clientNames: Map<Long, String> = emptyMap()
)

@HiltViewModel
class GlobalSearchViewModel @Inject constructor(
    clientRepository: ClientRepository,
    loanRepository: LoanRepository
) : ViewModel() {
    private val query = MutableStateFlow("")
    val uiState: StateFlow<GlobalSearchUiState> = combine(query, clientRepository.observeAll(), loanRepository.observeAll()) { q, clients, loans ->
        val t = q.trim().lowercase()
        val names = clients.associate { it.id to it.fullName }
        if (t.isBlank()) {
            GlobalSearchUiState(q, emptyList(), emptyList(), names)
        } else {
            val c = clients.filter { it.fullName.lowercase().contains(t) || it.phone.contains(t) }
            val l = loans.filter { loan ->
                loan.loanNumber.lowercase().contains(t) ||
                loan.status.name.lowercase().contains(t) ||
                loan.principalOriginal.toPlainString().contains(t) ||
                loan.totalBalance.toPlainString().contains(t) ||
                loan.dueDate.toString().contains(t) ||
                (names[loan.clientId]?.lowercase()?.contains(t) == true)
            }
            GlobalSearchUiState(q, c, l, names)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), GlobalSearchUiState())

    fun onQueryChange(v: String) { query.value = v }
}
