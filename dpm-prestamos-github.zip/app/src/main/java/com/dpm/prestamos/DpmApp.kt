package com.dpm.prestamos

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class DpmApp : Application()
