package com.dpm.prestamos.search

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dpm.prestamos.core.money.MoneyFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GlobalSearchScreen(onBack: () -> Unit, onLoanClick: (Long) -> Unit, onClientClick: (Long) -> Unit, viewModel: GlobalSearchViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    Scaffold(topBar = { TopAppBar(title = { Text("Búsqueda global") }, navigationIcon = { TextButton(onClick = onBack) { Text("Atrás") } }) }) { padding ->
        LazyColumn(Modifier.padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                OutlinedTextField(state.query, viewModel::onQueryChange, modifier = Modifier.fillMaxWidth(), label = { Text("Nombre, teléfono, préstamo, fecha, importe, estado") }, singleLine = true)
            }
            if (state.query.isBlank()) {
                item { Text("Escribe para buscar en clientes y préstamos.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            } else {
                if (state.clients.isNotEmpty()) {
                    item { Text("Clientes", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary) }
                    items(state.clients, key = { "c${it.id}" }) { c ->
                        ElevatedCard(onClick = { onClientClick(c.id) }, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) { Text(c.fullName); Text(c.phone, style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                }
                if (state.loans.isNotEmpty()) {
                    item { Text("Préstamos", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary) }
                    items(state.loans, key = { "l${it.id}" }) { loan ->
                        ElevatedCard(onClick = { onLoanClick(loan.id) }, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {
                                Text(state.clientNames[loan.clientId] ?: "Cliente", style = MaterialTheme.typography.titleSmall)
                                Text("${loan.loanNumber} • ${loan.status}")
                                Text("Saldo: ${MoneyFormatter.format(loan.totalBalance)} • Vence: ${loan.dueDate}", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                if (state.clients.isEmpty() && state.loans.isEmpty()) {
                    item { Text("Sin resultados.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
            }
        }
    }
}
