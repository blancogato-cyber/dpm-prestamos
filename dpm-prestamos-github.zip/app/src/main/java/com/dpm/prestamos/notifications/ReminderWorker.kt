package com.dpm.prestamos.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.dpm.prestamos.domain.enums.LoanStatus
import com.dpm.prestamos.domain.repository.LoanRepository
import com.dpm.prestamos.domain.repository.SettingsRepository
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.flow.first
import java.time.LocalDate

class ReminderWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {

    @EntryPoint
    @InstallIn(SingletonComponent::class)
    interface WorkerEntryPoint {
        fun loanRepository(): LoanRepository
        fun settingsRepository(): SettingsRepository
    }

    override suspend fun doWork(): Result = runCatching {
        val ep = EntryPointAccessors.fromApplication(applicationContext, WorkerEntryPoint::class.java)
        val settings = ep.settingsRepository().settings.first()
        if (!settings.remindersEnabled) return Result.success()

        val loanRepository = ep.loanRepository()
        loanRepository.syncStatuses()
        val loans = loanRepository.getAllOnce()
        val today = LocalDate.now()
        val upcomingLimit = today.plusDays(settings.upcomingDays.coerceAtLeast(0).toLong())
        val active = loans.filter { it.status !in listOf(LoanStatus.LIQUIDADO, LoanStatus.CANCELADO, LoanStatus.REESTRUCTURADO) }
        val dueSoon = active.count { !it.dueDate.isBefore(today) && !it.dueDate.isAfter(upcomingLimit) }
        val overdue = loans.count { it.status == LoanStatus.VENCIDO || it.status == LoanStatus.EN_MORA }

        if (dueSoon > 0 || overdue > 0) {
            ensureChannel(applicationContext)
            val text = buildString {
                if (dueSoon > 0) append("$dueSoon préstamo(s) próximo(s) a vencer (≤ ${settings.upcomingDays} días). ")
                if (overdue > 0) append("$overdue préstamo(s) en atraso/mora.")
            }.trim()
            val notif = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("DPM - Recordatorios")
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .build()
            val canNotify = Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            if (canNotify) NotificationManagerCompat.from(applicationContext).notify(1001, notif)
        }
        Result.success()
    }.getOrElse { Result.retry() }

    companion object {
        const val CHANNEL_ID = "dpm_reminders"
        const val WORK_NAME = "dpm_daily_reminders"
        fun ensureChannel(ctx: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Recordatorios DPM", NotificationManager.IMPORTANCE_DEFAULT))
            }
        }
    }
}
