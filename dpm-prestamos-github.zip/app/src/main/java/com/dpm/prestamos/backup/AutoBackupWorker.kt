package com.dpm.prestamos.backup

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.dpm.prestamos.domain.repository.BackupRepository
import com.dpm.prestamos.domain.repository.SecurityRepository
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.components.SingletonComponent
import java.io.File

class AutoBackupWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {

    @EntryPoint
    @InstallIn(SingletonComponent::class)
    interface WorkerEntryPoint {
        fun backupRepository(): BackupRepository
        fun securityRepository(): SecurityRepository
    }

    override suspend fun doWork(): Result = runCatching {
        val ep = EntryPointAccessors.fromApplication(applicationContext, WorkerEntryPoint::class.java)
        val pass = ep.securityRepository().getBackupPassphrase()
        if (pass.isNullOrBlank()) return Result.success()
        val res = ep.backupRepository().exportBackup(pass)
        res.onSuccess { path ->
            val dir = File(applicationContext.filesDir, "backups").apply { mkdirs() }
            val src = File(path)
            src.copyTo(File(dir, src.name), overwrite = true)
            dir.listFiles()?.sortedByDescending { it.lastModified() }?.drop(7)?.forEach { it.delete() }
        }
        if (res.isSuccess) Result.success() else Result.retry()
    }.getOrElse { Result.retry() }

    companion object { const val WORK_NAME = "dpm_auto_backup" }
}
