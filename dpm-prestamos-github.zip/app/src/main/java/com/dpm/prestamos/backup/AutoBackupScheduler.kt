package com.dpm.prestamos.backup

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

object AutoBackupScheduler {
    fun enable(context: Context) {
        val req = PeriodicWorkRequestBuilder<AutoBackupWorker>(24, TimeUnit.HOURS).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(AutoBackupWorker.WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, req)
    }
    fun disable(context: Context) { WorkManager.getInstance(context).cancelUniqueWork(AutoBackupWorker.WORK_NAME) }
}
