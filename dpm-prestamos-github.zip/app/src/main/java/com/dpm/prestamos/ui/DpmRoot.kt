package com.dpm.prestamos.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.core.money.MoneyFormatter
import com.dpm.prestamos.domain.engine.AmortizationSimulator
import com.dpm.prestamos.domain.enums.AccrualMode
import com.dpm.prestamos.domain.enums.InterestMethod
import com.dpm.prestamos.features.accounting.AccountingScreen
import com.dpm.prestamos.features.accounting.CashScreen
import com.dpm.prestamos.features.backup.BackupScreen
import com.dpm.prestamos.features.clients.ClientProfileScreen
import com.dpm.prestamos.features.clients.ClientsScreen
import com.dpm.prestamos.features.dashboard.DashboardScreen
import com.dpm.prestamos.features.loans.CalendarScreen
import com.dpm.prestamos.features.loans.LoanDetailScreen
import com.dpm.prestamos.features.loans.LoansScreen
import com.dpm.prestamos.features.payments.MovementsScreen
import com.dpm.prestamos.features.reports.ReportsScreen
import com.dpm.prestamos.features.security.AppLockGate
import com.dpm.prestamos.features.security.SecurityScreen
import com.dpm.prestamos.features.settings.SettingsScreen
import com.dpm.prestamos.backup.AutoBackupScheduler
import com.dpm.prestamos.notifications.ReminderScheduler
import com.dpm.prestamos.search.GlobalSearchScreen
import java.math.BigDecimal

sealed class Dest(val route: String, val label: String, val icon: ImageVector) {
    data object Home : Dest("home", "Inicio", Icons.Filled.Home)
    data object Loans : Dest("loans", "Préstamos", Icons.Filled.AccountBalance)
    data object Clients : Dest("clients", "Clientes", Icons.Filled.People)
    data object Movements : Dest("movements", "Movimientos", Icons.Filled.ReceiptLong)
    data object More : Dest("more", "Más", Icons.Filled.MoreHoriz)
}

@Composable
fun DpmRoot() {
    AppLockGate {
        val navController = rememberNavController()
        val items = listOf(Dest.Home, Dest.Loans, Dest.Clients, Dest.Movements, Dest.More)
        Scaffold(
            bottomBar = {
                NavigationBar {
                    val navBackStackEntry by navController.currentBackStackEntryAsState()
                    val current = navBackStackEntry?.destination?.route
                    items.forEach { dest ->
                        NavigationBarItem(
                            selected = current == dest.route || (dest == Dest.Loans && current?.startsWith("loan/") == true),
                            onClick = {
                                navController.navigate(dest.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(dest.icon, contentDescription = dest.label) },
                            label = { Text(dest.label) }
                        )
                    }
                }
            }
        ) { inner ->
            NavHost(navController, startDestination = Dest.Home.route, modifier = Modifier.padding(inner)) {
                composable(Dest.Home.route) {
                    DashboardScreen(onNewLoan = {
                        navController.navigate(Dest.Loans.route) {
                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    })
                }
                composable(Dest.Loans.route) { LoansScreen(onLoanClick = { id -> navController.navigate("loan/$id") }) }
                composable("loan/{loanId}") { LoanDetailScreen(onBack = { navController.popBackStack() }) }
                composable(Dest.Clients.route) { ClientsScreen(onClientClick = { id -> navController.navigate("client/$id") }) }
                composable("client/{clientId}") { ClientProfileScreen(onBack = { navController.popBackStack() }) }
                composable(Dest.Movements.route) { MovementsScreen() }
                composable(Dest.More.route) {
                    MoreScreen(
                        onOpenCash = { navController.navigate("cash") },
                        onOpenSearch = { navController.navigate("search") },
                        onOpenAccounting = { navController.navigate("accounting") },
                        onOpenCalendar = { navController.navigate("calendar") },
                        onOpenReports = { navController.navigate("reports") },
                        onOpenSettings = { navController.navigate("settings") },
                        onOpenSecurity = { navController.navigate("security") },
                        onOpenBackup = { navController.navigate("backup") }
                    )
                }
                composable("cash") { CashScreen(onBack = { navController.popBackStack() }) }
                composable("accounting") { AccountingScreen(onBack = { navController.popBackStack() }) }
                composable("calendar") { CalendarScreen(onBack = { navController.popBackStack() }, onLoanClick = { id -> navController.navigate("loan/$id") }) }
                composable("reports") { ReportsScreen(onBack = { navController.popBackStack() }) }
                composable("settings") {
                    val ctx = LocalContext.current
                    SettingsScreen(
                        onBack = { navController.popBackStack() },
                        onEnableReminders = { ReminderScheduler.enable(ctx.applicationContext) },
                        onDisableReminders = { ReminderScheduler.disable(ctx.applicationContext) }
                    )
                }
                composable("security") { SecurityScreen(onBack = { navController.popBackStack() }) }
                composable("backup") {
                    val ctx = LocalContext.current
                    BackupScreen(
                        onBack = { navController.popBackStack() },
                        onEnableAutoBackup = { AutoBackupScheduler.enable(ctx.applicationContext) },
                        onDisableAutoBackup = { AutoBackupScheduler.disable(ctx.applicationContext) }
                    )
                }
                composable("search") {
                    GlobalSearchScreen(
                        onBack = { navController.popBackStack() },
                        onLoanClick = { id -> navController.navigate("loan/$id") },
                        onClientClick = { id -> navController.navigate("client/$id") }
                    )
                }
            }
        }
    }
}

@Composable
fun MoreScreen(
    onOpenCash: () -> Unit = {},
    onOpenSearch: () -> Unit = {},
    onOpenAccounting: () -> Unit = {},
    onOpenCalendar: () -> Unit = {},
    onOpenReports: () -> Unit = {},
    onOpenSettings: () -> Unit = {},
    onOpenSecurity: () -> Unit = {},
    onOpenBackup: () -> Unit = {}
) {
    var showCalc by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Más", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary) }
        item { Text("Herramientas, seguridad, respaldos y configuración.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        item { ToolCard("Búsqueda global", "Buscar por nombre, teléfono, número de préstamo, fecha, importe o estado.", onOpenSearch) }
        item { ToolCard("Contabilidad", "Capital/intereses generados, cobrados y pendientes; ganancias reales y cartera.", onOpenAccounting) }
        item { ToolCard("Calendario financiero", "Vencimientos, pagos próximos y préstamos en atraso (diario/semanal/mensual).", onOpenCalendar) }
        item { ToolCard("Reportes y exportación", "Informes PDF/CSV de clientes, préstamos, pagos, caja, intereses y cartera.", onOpenReports) }
        item { ToolCard("Control de caja", "Saldo disponible y movimientos de caja (aportes, retiros, gastos, ajustes).", onOpenCash) }
        item { ToolCard("Calculadora de préstamos", "Simula capital, interés y total por método y plazo.", { showCalc = true }) }
        item { ToolCard("Seguridad", "PIN de acceso y políticas de operaciones sensibles.", onOpenSecurity) }
        item { ToolCard("Respaldos", "Copia cifrada, exportar y restaurar con verificación de integridad.", onOpenBackup) }
        item { ToolCard("Configuración", "Tasas/plazos predeterminados, gracia, umbrales y preferencias.", onOpenSettings) }
        item {
            val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
                ReminderScheduler.enable(ctx)
            }
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Notificaciones y recordatorios", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    Text("Recordatorios periódicos de vencimientos y préstamos en atraso (requiere permiso de notificaciones en Android 13+).", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            } else {
                                ReminderScheduler.enable(ctx)
                            }
                        }) { Text("Activar") }
                        OutlinedButton(onClick = { ReminderScheduler.disable(ctx) }) { Text("Desactivar") }
                    }
                }
            }
        }
        item {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("Recibos digitales", style = MaterialTheme.typography.titleMedium)
                    Text("Genera y comparte recibos PDF desde cada pago en el detalle del préstamo.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
    if (showCalc) LoanCalculatorDialog(onDismiss = { showCalc = false })
}

@Composable
private fun ToolCard(title: String, desc: String, onClick: () -> Unit) {
    ElevatedCard(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoanCalculatorDialog(onDismiss: () -> Unit) {
    var amount by remember { mutableStateOf("10000") }
    var rate by remember { mutableStateOf("20") }
    var days by remember { mutableStateOf("30") }
    var method by remember { mutableStateOf(InterestMethod.CAPITAL_INICIAL) }
    var result by remember { mutableStateOf<String?>(null) }

    AlertDialog(onDismissRequest = onDismiss, title = { Text("Calculadora de préstamos") }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(amount, { amount = it }, label = { Text("Capital (RD$)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            OutlinedTextField(rate, { rate = it }, label = { Text("Interés % por período") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            OutlinedTextField(days, { days = it }, label = { Text("Duración (días)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = method == InterestMethod.CAPITAL_INICIAL, onClick = { method = InterestMethod.CAPITAL_INICIAL }, label = { Text("Capital inicial") })
                FilterChip(selected = method == InterestMethod.CAPITAL_PENDIENTE, onClick = { method = InterestMethod.CAPITAL_PENDIENTE }, label = { Text("Capital pendiente") })
            }
            Button(onClick = {
                result = runCatching {
                    val q = AmortizationSimulator.quoteLoan(
                        principal = Money.of(amount),
                        ratePercent = BigDecimal(rate),
                        termDays = days.toIntOrNull() ?: 30,
                        method = method,
                        accrualMode = AccrualMode.PERIODO_COMPLETO
                    )
                    "Capital: ${MoneyFormatter.format(q.principal)}\nInterés: ${MoneyFormatter.format(q.interest)}\nTotal: ${MoneyFormatter.format(q.total)}"
                }.getOrElse { "Datos inválidos" }
            }) { Text("Calcular") }
            result?.let { Text(it, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyLarge) }
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } })
}
