package com.dpm.prestamos.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val BlackPure = Color(0xFF000000)
val BlackSecondary = Color(0xFF080C0A)
val GreenPrimary = Color(0xFF00D985)
val GreenDark = Color(0xFF063A26)
val Yellow = Color(0xFFFFD83D)
val Red = Color(0xFFFF5252)
val White = Color(0xFFFFFFFF)
val GraySecondary = Color(0xFF888888)

private val AmoledScheme = darkColorScheme(
    primary = GreenPrimary,
    onPrimary = Color.Black,
    secondary = Yellow,
    onSecondary = Color.Black,
    tertiary = GreenDark,
    background = BlackPure,
    onBackground = White,
    surface = BlackSecondary,
    onSurface = White,
    surfaceVariant = Color(0xFF111614),
    onSurfaceVariant = GraySecondary,
    error = Red,
    onError = Color.White,
    outline = GreenDark
)

@Composable
fun DpmTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AmoledScheme,
        content = content
    )
}
