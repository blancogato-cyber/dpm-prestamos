package com.dpm.prestamos.data.di

import com.dpm.prestamos.data.repository.*
import com.dpm.prestamos.data.transaction.LoanRestructurerImpl
import com.dpm.prestamos.data.transaction.PaymentRegistrarImpl
import com.dpm.prestamos.domain.repository.*
import com.dpm.prestamos.domain.usecase.accounting.AccountingSummaryProvider
import com.dpm.prestamos.domain.usecase.accounting.DashboardSummaryProvider
import com.dpm.prestamos.domain.usecase.loan.LoanRestructurer
import com.dpm.prestamos.domain.usecase.payment.PaymentRegistrar
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class DataModule {
    @Binds @Singleton abstract fun bindClientRepository(impl: ClientRepositoryImpl): ClientRepository
    @Binds @Singleton abstract fun bindLoanRepository(impl: LoanRepositoryImpl): LoanRepository
    @Binds @Singleton abstract fun bindPaymentRepository(impl: PaymentRepositoryImpl): PaymentRepository
    @Binds @Singleton abstract fun bindMovementRepository(impl: MovementRepositoryImpl): MovementRepository
    @Binds @Singleton abstract fun bindAuditRepository(impl: AuditRepositoryImpl): AuditRepository
    @Binds @Singleton abstract fun bindCashRepository(impl: CashRepositoryImpl): CashRepository
    @Binds @Singleton abstract fun bindDashboardSummaryProvider(impl: DashboardSummaryProviderImpl): DashboardSummaryProvider
    @Binds @Singleton abstract fun bindAccountingSummaryProvider(impl: AccountingSummaryProviderImpl): AccountingSummaryProvider
    @Binds @Singleton abstract fun bindPaymentRegistrar(impl: PaymentRegistrarImpl): PaymentRegistrar
    @Binds @Singleton abstract fun bindLoanRestructurer(impl: LoanRestructurerImpl): LoanRestructurer
    @Binds @Singleton abstract fun bindCashOperator(impl: com.dpm.prestamos.data.transaction.CashOperationService): com.dpm.prestamos.domain.usecase.cash.CashOperator
    @Binds @Singleton abstract fun bindReportExporter(impl: com.dpm.prestamos.data.reports.ReportExporterImpl): com.dpm.prestamos.domain.usecase.reports.ReportExporter
    @Binds @Singleton abstract fun bindSettingsRepository(impl: com.dpm.prestamos.data.settings.SettingsRepositoryImpl): com.dpm.prestamos.domain.repository.SettingsRepository
    @Binds @Singleton abstract fun bindSecurityRepository(impl: com.dpm.prestamos.data.security.SecurityRepositoryImpl): com.dpm.prestamos.domain.repository.SecurityRepository
    @Binds @Singleton abstract fun bindBackupRepository(impl: com.dpm.prestamos.data.backup.BackupRepositoryImpl): com.dpm.prestamos.domain.repository.BackupRepository
}
