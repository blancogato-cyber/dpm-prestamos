package com.dpm.prestamos.data.transaction

import androidx.room.withTransaction
import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.data.mapper.toEntity
import com.dpm.prestamos.database.DpmDatabase
import com.dpm.prestamos.database.entity.*
import com.dpm.prestamos.domain.enums.*
import com.dpm.prestamos.domain.engine.LoanStateMachine
import com.dpm.prestamos.domain.engine.PaymentAllocator
import com.dpm.prestamos.domain.engine.SettlementCalculator
import com.dpm.prestamos.domain.model.Loan
import java.time.LocalDate
import java.time.LocalDateTime
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PaymentTransactionService @Inject constructor(
    private val db: DpmDatabase
) {
    sealed interface Result {
        data class Success(val paymentId: Long, val receiptNumber: String) : Result
        data class NeedsSurplusConfirmation(val surplus: Money) : Result
        data class Error(val message: String) : Result
    }

    /**
     * Registra un pago de forma atómica: distribución, actualización de saldos del préstamo,
     * pago, asignaciones, movimiento, caja y auditoría.
     */
    suspend fun registerPayment(
        loan: Loan,
        amount: Money,
        method: PaymentMethod,
        distributionMode: DistributionMode,
        allowSurplus: Boolean = false,
        manualToInterest: Money? = null,
        manualToPrincipal: Money? = null,
        notes: String? = null,
        paidAt: LocalDateTime = LocalDateTime.now(),
        today: LocalDate = LocalDate.now()
    ): Result {
        if (!LoanStateMachine.canRegisterPayment(loan.status)) return Result.Error("El préstamo no admite pagos en su estado actual")
        if (!amount.isPositive()) return Result.Error("El monto debe ser mayor a cero")

        val allocResult = if (distributionMode == DistributionMode.AUTOMATICA) {
            PaymentAllocator.automatic(
                PaymentAllocator.AllocationInput(amount, loan.interestOutstanding, Money.ZERO, loan.principalOutstanding, allowSurplus)
            )
        } else {
            PaymentAllocator.manual(
                amount = amount,
                toInterest = manualToInterest ?: Money.ZERO,
                toPrincipal = manualToPrincipal ?: Money.ZERO,
                toFees = Money.ZERO,
                interestOutstanding = loan.interestOutstanding,
                principalOutstanding = loan.principalOutstanding,
                feesOutstanding = Money.ZERO,
                allowSurplus = allowSurplus
            )
        }

        val dist = when (allocResult) {
            is PaymentAllocator.AllocationResult.Invalid -> return Result.Error(allocResult.reason)
            is PaymentAllocator.AllocationResult.RequiresSurplusConfirmation -> return Result.NeedsSurplusConfirmation(allocResult.surplus)
            is PaymentAllocator.AllocationResult.Ok -> allocResult.distribution
        }

        val newPrincipal = loan.principalOutstanding - dist.toPrincipal
        val newInterestPaid = loan.interestPaid + dist.toInterest
        val newInterestOutstanding = (loan.interestOutstanding - dist.toInterest).let { if (it.isNegative()) Money.ZERO else it }
        val newTotalPaid = loan.totalPaid + (dist.toInterest + dist.toPrincipal + dist.toFees)
        val newBalance = newPrincipal + newInterestOutstanding
        val newStatus = LoanStateMachine.deriveStatus(loan.status, loan.dueDate, today, newBalance.isZero(), loan.gracePeriodDays)

        val updatedLoan = loan.copy(
            principalOutstanding = newPrincipal,
            interestPaid = newInterestPaid,
            interestOutstanding = newInterestOutstanding,
            totalPaid = newTotalPaid,
            totalBalance = newBalance,
            status = newStatus
        )

        val receipt = "REC-${loan.id}-${System.currentTimeMillis()}"
        val payment = PaymentEntity(
            loanId = loan.id, clientId = loan.clientId, receiptNumber = receipt, paidAt = paidAt,
            amountTotal = amount, amountToInterest = dist.toInterest, amountToPrincipal = dist.toPrincipal,
            amountToFees = dist.toFees, surplus = dist.surplus, method = method, distributionMode = distributionMode,
            notes = notes, status = PaymentStatus.APLICADO
        )

        val paymentId = db.withTransaction {
            val existingLoan = db.loanDao().getById(loan.id)
            val createdAt = existingLoan?.createdAt ?: loan.disbursementDate

            val account = ensureCashAccount(paidAt)
            val cashTx = CashTransactionEntity(
                cashAccountId = account.id, type = CashTxType.PAGO_RECIBIDO, amount = amount,
                relatedLoanId = loan.id, relatedPaymentId = null, occurredAt = paidAt, notes = "Pago $receipt"
            )
            val cashTxId = db.cashDao().insertTransaction(cashTx)
            db.cashDao().updateAccount(account.copy(currentBalance = account.currentBalance + amount))

            val pid = db.paymentDao().insert(payment.copy())
            db.paymentDao().update(payment.copy(id = pid)) // ensure id consistency if needed
            // record allocations
            val allocations = buildList {
                if (dist.toInterest.isPositive()) add(PaymentAllocationEntity(paymentId = pid, component = "INTERES", amount = dist.toInterest))
                if (dist.toPrincipal.isPositive()) add(PaymentAllocationEntity(paymentId = pid, component = "CAPITAL", amount = dist.toPrincipal))
                if (dist.toFees.isPositive()) add(PaymentAllocationEntity(paymentId = pid, component = "MORA", amount = dist.toFees))
                if (dist.surplus.isPositive()) add(PaymentAllocationEntity(paymentId = pid, component = "EXCEDENTE", amount = dist.surplus))
            }
            if (allocations.isNotEmpty()) db.allocationDao().insertAll(allocations)

            val movement = MovementEntity(
                loanId = loan.id, paymentId = pid, cashTxId = cashTxId, type = MovementType.PAGO,
                amount = amount, timestamp = paidAt,
                balanceBefore = loan.totalBalance, balanceAfter = newBalance,
                principalBefore = loan.principalOutstanding, principalAfter = newPrincipal,
                interestBefore = loan.interestOutstanding, interestAfter = newInterestOutstanding,
                reference = receipt
            )
            db.movementDao().insert(movement)
            db.loanDao().update(updatedLoan.toEntity(createdAt = createdAt, updatedAt = today))

            db.auditDao().insert(
                AuditLogEntity(
                    action = AuditAction.REGISTRAR_PAGO,
                    entityType = "payment",
                    entityId = pid.toString(),
                    timestamp = paidAt,
                    details = "loan=${loan.id};amount=${amount.toPlainString()};interest=${dist.toInterest.toPlainString()};principal=${dist.toPrincipal.toPlainString()};receipt=$receipt"
                )
            )
            pid
        }
        return Result.Success(paymentId, receipt)
    }

    private suspend fun ensureCashAccount(now: LocalDateTime): CashAccountEntity {
        val existing = db.cashDao().getMainAccount()
        if (existing != null) return existing
        val account = CashAccountEntity(name = "Caja principal", initialBalance = Money.ZERO, currentBalance = Money.ZERO, createdAt = now)
        val id = db.cashDao().insertAccount(account)
        return account.copy(id = id)
    }

    /**
     * Anula un pago aplicado: revierte saldos del préstamo y caja, registra movimiento/auditoría.
     * No elimina registros (trazabilidad completa).
     */
    suspend fun voidPayment(paymentId: Long, reason: String, now: LocalDateTime = LocalDateTime.now(), today: LocalDate = LocalDate.now()): Result {
        return db.withTransaction {
            val payment = db.paymentDao().getById(paymentId) ?: return@withTransaction Result.Error("Pago no encontrado")
            if (payment.status == PaymentStatus.ANULADO) return@withTransaction Result.Error("El pago ya está anulado")
            val loanEntity = db.loanDao().getById(payment.loanId) ?: return@withTransaction Result.Error("Préstamo no encontrado")

            // Reverso de efectos financieros del pago aplicado
            val restoredPrincipal = loanEntity.principalOutstanding + payment.amountToPrincipal
            val restoredInterestOutstanding = loanEntity.interestOutstanding + payment.amountToInterest
            val restoredInterestPaid = (loanEntity.interestPaid - payment.amountToInterest).let { if (it.isNegative()) Money.ZERO else it }
            val restoredTotalPaid = (loanEntity.totalPaid - (payment.amountToInterest + payment.amountToPrincipal + payment.amountToFees)).let { if (it.isNegative()) Money.ZERO else it }
            val restoredBalance = restoredPrincipal + restoredInterestOutstanding
            val restoredStatus = LoanStateMachine.deriveStatus(loanEntity.status, loanEntity.dueDate, today, restoredBalance.isZero(), loanEntity.gracePeriodDays)

            val updatedLoan = loanEntity.copy(
                principalOutstanding = restoredPrincipal,
                interestOutstanding = restoredInterestOutstanding,
                interestPaid = restoredInterestPaid,
                totalPaid = restoredTotalPaid,
                totalBalance = restoredBalance,
                status = restoredStatus,
                updatedAt = today
            )

            // Caja: salida por reverso del ingreso
            val account = ensureCashAccount(now)
            val cashTx = CashTransactionEntity(
                cashAccountId = account.id, type = CashTxType.AJUSTE, amount = -payment.amountTotal,
                relatedLoanId = payment.loanId, relatedPaymentId = paymentId, occurredAt = now,
                notes = "Anulación ${payment.receiptNumber}", justification = reason
            )
            val cashTxId = db.cashDao().insertTransaction(cashTx)
            db.cashDao().updateAccount(account.copy(currentBalance = account.currentBalance - payment.amountTotal))

            db.paymentDao().update(payment.copy(status = PaymentStatus.ANULADO, voidReason = reason, voidedAt = now))
            db.loanDao().update(updatedLoan)

            val movement = MovementEntity(
                loanId = payment.loanId, paymentId = paymentId, cashTxId = cashTxId, type = MovementType.ANULACION_PAGO,
                amount = payment.amountTotal, timestamp = now,
                balanceBefore = loanEntity.totalBalance, balanceAfter = restoredBalance,
                principalBefore = loanEntity.principalOutstanding, principalAfter = restoredPrincipal,
                interestBefore = loanEntity.interestOutstanding, interestAfter = restoredInterestOutstanding,
                reference = payment.receiptNumber
            )
            db.movementDao().insert(movement)
            db.auditDao().insert(
                AuditLogEntity(
                    action = AuditAction.ANULAR_PAGO,
                    entityType = "payment",
                    entityId = paymentId.toString(),
                    timestamp = now,
                    reason = reason,
                    details = "receipt=${payment.receiptNumber};amount=${payment.amountTotal.toPlainString()}"
                )
            )
            Result.Success(paymentId, payment.receiptNumber)
        }
    }

    suspend fun settleLoan(
        loan: Loan,
        interestAccruedUnpaid: Money,
        fees: Money = Money.ZERO,
        discount: Money = Money.ZERO,
        method: PaymentMethod = PaymentMethod.EFECTIVO,
        notes: String? = null,
        now: LocalDateTime = LocalDateTime.now(),
        today: LocalDate = LocalDate.now()
    ): Result {
        if (loan.status == LoanStatus.LIQUIDADO || loan.status == LoanStatus.CANCELADO) {
            return Result.Error("El préstamo no puede liquidarse en su estado actual")
        }
        val settlement = runCatching { SettlementCalculator.settle(loan.principalOutstanding, interestAccruedUnpaid, fees, discount) }
            .getOrElse { return Result.Error(it.message ?: "Datos de liquidación inválidos") }

        val receipt = "LIQ-${loan.id}-${System.currentTimeMillis()}"
        val amount = settlement.total
        val toInterest = interestAccruedUnpaid.min(amount)
        val remainingAfterInterest = amount - toInterest
        val toFees = fees.min(if (remainingAfterInterest.isNegative()) Money.ZERO else remainingAfterInterest)
        val toPrincipal = loan.principalOutstanding.min((amount - toInterest - toFees).let { if (it.isNegative()) Money.ZERO else it })

        val payment = PaymentEntity(
            loanId = loan.id, clientId = loan.clientId, receiptNumber = receipt, paidAt = now,
            amountTotal = amount, amountToInterest = toInterest, amountToPrincipal = toPrincipal,
            amountToFees = toFees, surplus = Money.ZERO, method = method, distributionMode = DistributionMode.AUTOMATICA,
            notes = notes ?: "Liquidación anticipada", status = PaymentStatus.APLICADO
        )

        val updatedLoan = loan.copy(
            principalOutstanding = Money.ZERO,
            interestPaid = loan.interestPaid + toInterest,
            interestOutstanding = Money.ZERO,
            totalPaid = loan.totalPaid + amount,
            totalBalance = Money.ZERO,
            status = LoanStatus.LIQUIDADO
        )

        val paymentId = db.withTransaction {
            val existingLoan = db.loanDao().getById(loan.id)
            val createdAt = existingLoan?.createdAt ?: loan.disbursementDate

            val account = ensureCashAccount(now)
            val cashTx = CashTransactionEntity(
                cashAccountId = account.id, type = CashTxType.PAGO_RECIBIDO, amount = amount,
                relatedLoanId = loan.id, relatedPaymentId = null, occurredAt = now, notes = "Liquidación $receipt"
            )
            val cashTxId = db.cashDao().insertTransaction(cashTx)
            db.cashDao().updateAccount(account.copy(currentBalance = account.currentBalance + amount))

            val pid = db.paymentDao().insert(payment)
            val allocations = buildList {
                if (toInterest.isPositive()) add(PaymentAllocationEntity(paymentId = pid, component = "INTERES", amount = toInterest))
                if (toPrincipal.isPositive()) add(PaymentAllocationEntity(paymentId = pid, component = "CAPITAL", amount = toPrincipal))
                if (toFees.isPositive()) add(PaymentAllocationEntity(paymentId = pid, component = "MORA", amount = toFees))
            }
            if (allocations.isNotEmpty()) db.allocationDao().insertAll(allocations)

            db.movementDao().insert(
                MovementEntity(
                    loanId = loan.id, paymentId = pid, cashTxId = cashTxId, type = MovementType.LIQUIDACION,
                    amount = amount, timestamp = now,
                    balanceBefore = loan.totalBalance, balanceAfter = Money.ZERO,
                    principalBefore = loan.principalOutstanding, principalAfter = Money.ZERO,
                    interestBefore = loan.interestOutstanding, interestAfter = Money.ZERO,
                    reference = receipt
                )
            )
            db.loanDao().update(updatedLoan.toEntity(createdAt = createdAt, updatedAt = today))
            db.auditDao().insert(
                AuditLogEntity(
                    action = AuditAction.LIQUIDAR,
                    entityType = "loan",
                    entityId = loan.id.toString(),
                    timestamp = now,
                    details = "amount=${amount.toPlainString()};interest=${toInterest.toPlainString()};principal=${toPrincipal.toPlainString()};discount=${discount.toPlainString()};receipt=$receipt"
                )
            )
            pid
        }
        return Result.Success(paymentId, receipt)
    }
}
