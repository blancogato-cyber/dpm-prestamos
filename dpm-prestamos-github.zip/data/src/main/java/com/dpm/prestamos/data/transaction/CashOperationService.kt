package com.dpm.prestamos.data.transaction

import androidx.room.withTransaction
import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.database.DpmDatabase
import com.dpm.prestamos.database.entity.AuditLogEntity
import com.dpm.prestamos.database.entity.CashAccountEntity
import com.dpm.prestamos.database.entity.CashTransactionEntity
import com.dpm.prestamos.domain.enums.AuditAction
import com.dpm.prestamos.domain.enums.CashTxType
import com.dpm.prestamos.domain.usecase.cash.CashOpResult
import com.dpm.prestamos.domain.usecase.cash.CashOperator
import java.time.LocalDateTime
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CashOperationService @Inject constructor(private val db: DpmDatabase) : CashOperator {

    override suspend fun register(type: CashTxType, amount: Money, notes: String?, justification: String?): CashOpResult {
        if (!amount.isPositive()) return CashOpResult.Error("El monto debe ser mayor a cero")
        if (type == CashTxType.AJUSTE && justification.isNullOrBlank()) return CashOpResult.Error("El ajuste requiere justificación")
        if (type == CashTxType.PAGO_RECIBIDO || type == CashTxType.DESEMBOLSO_PRESTAMO) {
            return CashOpResult.Error("Este tipo de movimiento se registra automáticamente desde préstamos/pagos")
        }
        val now = LocalDateTime.now()
        return db.withTransaction {
            val account = ensureAccount(now)
            val signed = when (type) {
                CashTxType.SALDO_INICIAL, CashTxType.APORTE -> amount
                CashTxType.RETIRO, CashTxType.GASTO_OPERATIVO -> -amount
                CashTxType.AJUSTE -> amount // ajuste manual positivo; usar retiro/gasto para egresos
                else -> amount
            }
            db.cashDao().insertTransaction(CashTransactionEntity(
                cashAccountId = account.id, type = type, amount = signed,
                occurredAt = now, notes = notes, justification = justification
            ))
            val isFirstInitial = type == CashTxType.SALDO_INICIAL && account.initialBalance.isZero() && account.currentBalance.isZero()
            val newBalance = if (isFirstInitial) amount else account.currentBalance + signed
            val updated = account.copy(
                currentBalance = newBalance,
                initialBalance = if (type == CashTxType.SALDO_INICIAL) amount else account.initialBalance
            )
            db.cashDao().updateAccount(updated)
            db.auditDao().insert(AuditLogEntity(
                action = AuditAction.MOVIMIENTO_CAJA, entityType = "cash", entityId = account.id.toString(),
                timestamp = now, details = "type=$type;amount=${signed.toPlainString()};notes=${notes.orEmpty()}",
                reason = justification
            ))
            CashOpResult.Success
        }
    }

    private suspend fun ensureAccount(now: LocalDateTime): CashAccountEntity {
        val existing = db.cashDao().getMainAccount()
        if (existing != null) return existing
        val acc = CashAccountEntity(name = "Caja principal", initialBalance = Money.ZERO, currentBalance = Money.ZERO, createdAt = now)
        return acc.copy(id = db.cashDao().insertAccount(acc))
    }
}
