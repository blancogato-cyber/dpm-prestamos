package com.dpm.prestamos.data.mapper

import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.database.entity.*
import com.dpm.prestamos.domain.model.*
import com.dpm.prestamos.domain.repository.AuditEntry
import java.math.BigDecimal

fun ClientEntity.toDomain() = Client(id, fullName, phone, address, documentId, photoUri, notes, createdAt, isActive)
fun Client.toEntity() = ClientEntity(id, fullName, phone, address, documentId, photoUri, notes, createdAt, isActive)

fun LoanEntity.toDomain() = Loan(
    id = id, clientId = clientId, loanNumber = loanNumber,
    principalOriginal = principalOriginal, principalOutstanding = principalOutstanding,
    interestRatePercent = BigDecimal(interestRatePercent), interestMethod = interestMethod,
    accrualMode = accrualMode, defaultPaymentMode = defaultPaymentMode,
    termType = termType, termDays = termDays,
    disbursementDate = disbursementDate, dueDate = dueDate, status = status,
    interestGenerated = interestGenerated, interestPaid = interestPaid,
    interestOutstanding = interestOutstanding, totalPaid = totalPaid, totalBalance = totalBalance,
    gracePeriodDays = gracePeriodDays, lateFeeEnabled = lateFeeEnabled,
    parentLoanId = parentLoanId, notes = notes, periodsCharged = periodsCharged
)
fun Loan.toEntity(createdAt: java.time.LocalDate, updatedAt: java.time.LocalDate) = LoanEntity(
    id = id, clientId = clientId, loanNumber = loanNumber,
    principalOriginal = principalOriginal, principalOutstanding = principalOutstanding,
    interestRatePercent = interestRatePercent.toPlainString(), interestMethod = interestMethod,
    accrualMode = accrualMode, defaultPaymentMode = defaultPaymentMode,
    termType = termType, termDays = termDays,
    disbursementDate = disbursementDate, dueDate = dueDate, status = status,
    interestGenerated = interestGenerated, interestPaid = interestPaid,
    interestOutstanding = interestOutstanding, totalPaid = totalPaid, totalBalance = totalBalance,
    gracePeriodDays = gracePeriodDays, lateFeeEnabled = lateFeeEnabled,
    parentLoanId = parentLoanId, periodsCharged = periodsCharged, notes = notes,
    createdAt = createdAt, updatedAt = updatedAt
)

fun PaymentEntity.toDomain() = Payment(
    id, loanId, clientId, receiptNumber, paidAt, amountTotal, amountToInterest, amountToPrincipal,
    amountToFees, surplus, method, distributionMode, notes, status, voidReason
)
fun Payment.toEntity() = PaymentEntity(
    id, loanId, clientId, receiptNumber, paidAt, amountTotal, amountToInterest, amountToPrincipal,
    amountToFees, surplus, method, distributionMode, notes, status, voidReason, voidedAt = null
)

fun MovementEntity.toDomain() = Movement(
    id, loanId, paymentId, cashTxId, type, amount, timestamp, balanceBefore, balanceAfter,
    principalBefore, principalAfter, interestBefore, interestAfter, actor, reference
)
fun Movement.toEntity() = MovementEntity(
    id, loanId, paymentId, cashTxId, type, amount, timestamp, balanceBefore, balanceAfter,
    principalBefore, principalAfter, interestBefore, interestAfter, actor, reference
)

fun AuditLogEntity.toDomain() = AuditEntry(id, action, entityType, entityId, timestamp, actor, details, reason)
fun AuditEntry.toEntity() = AuditLogEntity(id, action, entityType, entityId, timestamp, actor, details, reason)
