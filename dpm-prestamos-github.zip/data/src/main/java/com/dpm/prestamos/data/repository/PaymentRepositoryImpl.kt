package com.dpm.prestamos.data.repository

import com.dpm.prestamos.data.mapper.toDomain
import com.dpm.prestamos.data.mapper.toEntity
import com.dpm.prestamos.database.dao.PaymentDao
import com.dpm.prestamos.domain.model.Payment
import com.dpm.prestamos.domain.repository.PaymentRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

class PaymentRepositoryImpl @Inject constructor(
    private val dao: PaymentDao
) : PaymentRepository {
    override fun observeByLoan(loanId: Long): Flow<List<Payment>> = dao.observeByLoan(loanId).map { it.map { e -> e.toDomain() } }
    override suspend fun getById(id: Long): Payment? = dao.getById(id)?.toDomain()
    override suspend fun getAllOnce(): List<Payment> = dao.getAllOnce().map { it.toDomain() }
    override suspend fun save(payment: Payment): Long =
        if (payment.id == 0L) dao.insert(payment.toEntity()) else { dao.update(payment.toEntity()); payment.id }
}
