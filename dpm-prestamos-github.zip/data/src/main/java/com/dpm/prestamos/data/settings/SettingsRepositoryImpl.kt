package com.dpm.prestamos.data.settings

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.dpm.prestamos.domain.repository.AppSettings
import com.dpm.prestamos.domain.repository.SettingsRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.settingsDataStore by preferencesDataStore(name = "dpm_settings")

@Singleton
class SettingsRepositoryImpl @Inject constructor(@ApplicationContext private val context: Context) : SettingsRepository {
    private object Keys {
        val RATE = stringPreferencesKey("default_rate")
        val TERM = intPreferencesKey("default_term")
        val GRACE = intPreferencesKey("grace_days")
        val UPCOMING = intPreferencesKey("upcoming_days")
        val REMINDERS = booleanPreferencesKey("reminders_enabled")
        val BIOMETRIC = booleanPreferencesKey("biometric_enabled")
        val AUTO_LOCK = intPreferencesKey("auto_lock_min")
        val AUTO_BACKUP = booleanPreferencesKey("auto_backup_enabled")
    }

    override val settings: Flow<AppSettings> = context.settingsDataStore.data.map { p ->
        AppSettings(
            defaultRatePercent = p[Keys.RATE] ?: "20",
            defaultTermDays = p[Keys.TERM] ?: 30,
            gracePeriodDays = p[Keys.GRACE] ?: 0,
            upcomingDays = p[Keys.UPCOMING] ?: 3,
            remindersEnabled = p[Keys.REMINDERS] ?: false,
            biometricEnabled = p[Keys.BIOMETRIC] ?: false,
            autoLockMinutes = p[Keys.AUTO_LOCK] ?: 2,
            autoBackupEnabled = p[Keys.AUTO_BACKUP] ?: false
        )
    }

    override suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.settingsDataStore.edit { p ->
            val cur = AppSettings(
                defaultRatePercent = p[Keys.RATE] ?: "20",
                defaultTermDays = p[Keys.TERM] ?: 30,
                gracePeriodDays = p[Keys.GRACE] ?: 0,
                upcomingDays = p[Keys.UPCOMING] ?: 3,
                remindersEnabled = p[Keys.REMINDERS] ?: false,
                biometricEnabled = p[Keys.BIOMETRIC] ?: false,
                autoLockMinutes = p[Keys.AUTO_LOCK] ?: 2,
                autoBackupEnabled = p[Keys.AUTO_BACKUP] ?: false
            )
            val s = transform(cur)
            p[Keys.RATE] = s.defaultRatePercent
            p[Keys.TERM] = s.defaultTermDays
            p[Keys.GRACE] = s.gracePeriodDays
            p[Keys.UPCOMING] = s.upcomingDays
            p[Keys.REMINDERS] = s.remindersEnabled
            p[Keys.BIOMETRIC] = s.biometricEnabled
            p[Keys.AUTO_LOCK] = s.autoLockMinutes
            p[Keys.AUTO_BACKUP] = s.autoBackupEnabled
        }
    }
}
