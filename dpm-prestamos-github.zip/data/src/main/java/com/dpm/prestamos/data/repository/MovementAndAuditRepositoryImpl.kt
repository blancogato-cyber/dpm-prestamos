package com.dpm.prestamos.data.repository

import com.dpm.prestamos.data.mapper.toDomain
import com.dpm.prestamos.data.mapper.toEntity
import com.dpm.prestamos.database.dao.AuditDao
import com.dpm.prestamos.database.dao.MovementDao
import com.dpm.prestamos.domain.model.Movement
import com.dpm.prestamos.domain.repository.AuditEntry
import com.dpm.prestamos.domain.repository.AuditRepository
import com.dpm.prestamos.domain.repository.MovementRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

class MovementRepositoryImpl @Inject constructor(
    private val dao: MovementDao
) : MovementRepository {
    override fun observeByLoan(loanId: Long): Flow<List<Movement>> = dao.observeByLoan(loanId).map { it.map { e -> e.toDomain() } }
    override fun observeRecent(limit: Int): Flow<List<Movement>> = dao.observeRecent(limit).map { it.map { e -> e.toDomain() } }
    override suspend fun append(movement: Movement): Long = dao.insert(movement.toEntity())
    override suspend fun appendAll(movements: List<Movement>) = dao.insertAll(movements.map { it.toEntity() })
}

class AuditRepositoryImpl @Inject constructor(
    private val dao: AuditDao
) : AuditRepository {
    override suspend fun log(entry: AuditEntry) { dao.insert(entry.toEntity()) }
    override fun observeAll(): Flow<List<AuditEntry>> = dao.observeAll().map { it.map { e -> e.toDomain() } }
}
