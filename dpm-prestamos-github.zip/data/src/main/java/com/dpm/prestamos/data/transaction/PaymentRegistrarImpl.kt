package com.dpm.prestamos.data.transaction

import com.dpm.prestamos.domain.usecase.payment.PaymentRegistrar
import com.dpm.prestamos.domain.usecase.payment.RegisterPaymentResult
import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.domain.enums.DistributionMode
import com.dpm.prestamos.domain.enums.PaymentMethod
import com.dpm.prestamos.domain.model.Loan
import java.time.LocalDate
import java.time.LocalDateTime
import javax.inject.Inject

class PaymentRegistrarImpl @Inject constructor(
    private val service: PaymentTransactionService
) : PaymentRegistrar {
    override suspend fun register(
        loan: Loan, amount: Money, method: PaymentMethod, distributionMode: DistributionMode,
        allowSurplus: Boolean, manualToInterest: Money?, manualToPrincipal: Money?, notes: String?,
        paidAt: LocalDateTime, today: LocalDate
    ): RegisterPaymentResult = when (val r = service.registerPayment(
        loan, amount, method, distributionMode, allowSurplus, manualToInterest, manualToPrincipal, notes, paidAt, today
    )) {
        is PaymentTransactionService.Result.Success -> RegisterPaymentResult.Success(r.paymentId, r.receiptNumber)
        is PaymentTransactionService.Result.NeedsSurplusConfirmation -> RegisterPaymentResult.NeedsSurplusConfirmation(r.surplus)
        is PaymentTransactionService.Result.Error -> RegisterPaymentResult.Error(r.message)
    }

    override suspend fun void(paymentId: Long, reason: String): RegisterPaymentResult = when (val r = service.voidPayment(paymentId, reason)) {
        is PaymentTransactionService.Result.Success -> RegisterPaymentResult.Success(r.paymentId, r.receiptNumber)
        is PaymentTransactionService.Result.NeedsSurplusConfirmation -> RegisterPaymentResult.Error("No aplica")
        is PaymentTransactionService.Result.Error -> RegisterPaymentResult.Error(r.message)
    }

    override suspend fun settle(
        loan: Loan, interestAccruedUnpaid: Money, fees: Money, discount: Money, method: PaymentMethod, notes: String?, now: LocalDateTime, today: LocalDate
    ): RegisterPaymentResult = when (val r = service.settleLoan(loan, interestAccruedUnpaid, fees, discount, method, notes, now, today)) {
        is PaymentTransactionService.Result.Success -> RegisterPaymentResult.Success(r.paymentId, r.receiptNumber)
        is PaymentTransactionService.Result.NeedsSurplusConfirmation -> RegisterPaymentResult.Error("No aplica")
        is PaymentTransactionService.Result.Error -> RegisterPaymentResult.Error(r.message)
    }
}
