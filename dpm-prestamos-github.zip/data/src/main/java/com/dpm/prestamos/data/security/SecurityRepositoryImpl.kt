package com.dpm.prestamos.data.security

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.dpm.prestamos.domain.repository.SecurityRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import java.security.MessageDigest
import java.security.SecureRandom
import javax.inject.Inject
import javax.inject.Singleton
import android.util.Base64

@Singleton
class SecurityRepositoryImpl @Inject constructor(@ApplicationContext private val context: Context) : SecurityRepository {
    private val prefs by lazy {
        val masterKey = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            context, "dpm_secure",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    override suspend fun hasPin(): Boolean = prefs.contains("pin_hash")
    override suspend fun setPin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val hash = hash(pin, salt)
        prefs.edit().putString("pin_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("pin_hash", Base64.encodeToString(hash, Base64.NO_WRAP)).apply()
    }
    override suspend fun verifyPin(pin: String): Boolean {
        val saltB64 = prefs.getString("pin_salt", null) ?: return false
        val hashB64 = prefs.getString("pin_hash", null) ?: return false
        val salt = Base64.decode(saltB64, Base64.NO_WRAP)
        val expected = Base64.decode(hashB64, Base64.NO_WRAP)
        return MessageDigest.isEqual(hash(pin, salt), expected)
    }
    override suspend fun clearPin() { prefs.edit().remove("pin_salt").remove("pin_hash").apply() }

    override suspend fun setBackupPassphrase(passphrase: String) { prefs.edit().putString("backup_pass", passphrase).apply() }
    override suspend fun getBackupPassphrase(): String? = prefs.getString("backup_pass", null)
    override suspend fun clearBackupPassphrase() { prefs.edit().remove("backup_pass").apply() }

    private fun hash(pin: String, salt: ByteArray): ByteArray {
        val md = MessageDigest.getInstance("SHA-256")
        md.update(salt)
        return md.digest(pin.toByteArray(Charsets.UTF_8))
    }
}
