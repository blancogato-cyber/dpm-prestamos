package com.dpm.prestamos.data.backup

import android.content.Context
import com.dpm.prestamos.domain.repository.BackupRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class BackupRepositoryImpl @Inject constructor(@ApplicationContext private val context: Context) : BackupRepository {
    private val dbName = "dpm.db"

    override suspend fun exportBackup(password: String): Result<String> = runCatching {
        require(password.length >= 4) { "La contraseña debe tener al menos 4 caracteres" }
        val dbFile = context.getDatabasePath(dbName)
        require(dbFile.exists()) { "No hay base de datos para respaldar" }
        val plain = dbFile.readBytes()
        val hash = sha256(plain)
        val payload = hash + plain // integrity prefix (32 bytes)
        val encrypted = encrypt(payload, password)
        val out = File(File(context.cacheDir, "exports").apply { mkdirs() }, "dpm_backup_${System.currentTimeMillis()}.dpm")
        out.writeBytes(encrypted)
        out.absolutePath
    }

    override suspend fun restoreBackup(filePath: String, password: String): Result<Unit> = runCatching {
        require(password.isNotBlank()) { "Ingrese la contraseña del respaldo" }
        val src = File(filePath)
        require(src.exists() && src.isFile) { "Archivo de respaldo no encontrado o inaccesible" }
        require(src.canRead()) { "No se puede leer el archivo de respaldo" }
        val enc = src.readBytes()
        require(enc.size > 32) { "Archivo de respaldo inválido o vacío" }
        val payload = try { decrypt(enc, password) } catch (e: Exception) {
            throw IllegalArgumentException("No se pudo descifrar el respaldo. Verifique la contraseña y el archivo.", e)
        }
        require(payload.size > 32) { "Contenido de respaldo inválido" }
        val hash = payload.copyOfRange(0, 32)
        val plain = payload.copyOfRange(32, payload.size)
        require(MessageDigest.isEqual(hash, sha256(plain))) { "Integridad inválida: el respaldo está dañado o no corresponde a esta app" }
        val dbFile = context.getDatabasePath(dbName)
        dbFile.parentFile?.mkdirs()
        // Escribir DB restaurada (mejor esfuerzo). Reiniciar la app para recargar Room y cerrar conexiones activas.
        FileOutputStream(dbFile).use { it.write(plain) }
        File(dbFile.path + "-wal").delete()
        File(dbFile.path + "-shm").delete()
    }

    private fun sha256(data: ByteArray): ByteArray = MessageDigest.getInstance("SHA-256").digest(data)

    private fun encrypt(data: ByteArray, password: String): ByteArray {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val iv = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val key = derive(password, salt)
        val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
        cipher.init(Cipher.ENCRYPT_MODE, key, IvParameterSpec(iv))
        val ct = cipher.doFinal(data)
        return salt + iv + ct
    }

    private fun decrypt(data: ByteArray, password: String): ByteArray {
        require(data.size > 32) { "Archivo de respaldo inválido" }
        val salt = data.copyOfRange(0, 16)
        val iv = data.copyOfRange(16, 32)
        val ct = data.copyOfRange(32, data.size)
        val key = derive(password, salt)
        val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
        cipher.init(Cipher.DECRYPT_MODE, key, IvParameterSpec(iv))
        return cipher.doFinal(ct)
    }

    private fun derive(password: String, salt: ByteArray): SecretKeySpec {
        val spec = PBEKeySpec(password.toCharArray(), salt, 12000, 256)
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return SecretKeySpec(bytes, "AES")
    }
}
