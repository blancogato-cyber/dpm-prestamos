package com.dpm.prestamos.data.repository

import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.database.dao.CashDao
import com.dpm.prestamos.database.dao.DashboardDao
import com.dpm.prestamos.domain.enums.LoanStatus
import com.dpm.prestamos.domain.model.AccountingSummary
import com.dpm.prestamos.domain.usecase.accounting.AccountingSummaryProvider
import java.math.BigDecimal
import javax.inject.Inject

class AccountingSummaryProviderImpl @Inject constructor(
    private val dao: DashboardDao,
    private val cashDao: CashDao
) : AccountingSummaryProvider {
    override suspend fun getSummary(): AccountingSummary {
        val interestCollected = Money.ofExact(BigDecimal.valueOf(dao.sumInterestCollected()))
        val moneyRecovered = Money.ofExact(BigDecimal.valueOf(dao.sumMoneyRecovered()))
        val capitalRecovered = moneyRecovered - interestCollected
        val cash = cashDao.getMainAccount()?.currentBalance ?: Money.ZERO
        val active = dao.countLoansByStatuses(listOf(LoanStatus.ACTIVO, LoanStatus.PROXIMO_VENCER, LoanStatus.VENCIDO))
        return AccountingSummary(
            capitalDisbursed = Money.ofExact(BigDecimal.valueOf(dao.sumCapitalDisbursed())),
            capitalRecovered = capitalRecovered,
            capitalPending = Money.ofExact(BigDecimal.valueOf(dao.sumPrincipalOutstandingActive())),
            interestGenerated = Money.ofExact(BigDecimal.valueOf(dao.sumInterestGenerated())),
            interestCollected = interestCollected,
            interestPending = Money.ofExact(BigDecimal.valueOf(dao.sumInterestOutstandingActive())),
            cashAvailable = cash,
            activeLoans = active,
            settledLoans = dao.countSettledLoans(),
            realProfitFromInterest = interestCollected
        )
    }
}
