package com.dpm.prestamos.data.transaction

import androidx.room.withTransaction
import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.data.mapper.toEntity
import com.dpm.prestamos.database.DpmDatabase
import com.dpm.prestamos.database.entity.*
import com.dpm.prestamos.domain.engine.InterestCalculator
import com.dpm.prestamos.domain.engine.LoanStateMachine
import com.dpm.prestamos.domain.enums.*
import com.dpm.prestamos.domain.model.Loan
import java.math.BigDecimal
import java.time.LocalDate
import java.time.LocalDateTime
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LoanRestructureService @Inject constructor(private val db: DpmDatabase) {

    data class RestructureRequest(
        val oldLoan: Loan,
        val paymentNow: Money, // monto pagado ahora sobre el préstamo anterior (puede ser 0)
        val paymentMethod: PaymentMethod = PaymentMethod.EFECTIVO,
        val newPrincipal: Money,
        val newRatePercent: BigDecimal,
        val newTermDays: Int,
        val newInterestMethod: InterestMethod,
        val newAccrualMode: AccrualMode,
        val newPaymentMode: PaymentMode,
        val type: MovementType // RENOVACION o REFINANCIAMIENTO
    )

    sealed interface Result {
        data class Success(val oldLoanId: Long, val newLoanId: Long) : Result
        data class Error(val message: String) : Result
    }

    suspend fun restructure(req: RestructureRequest, now: LocalDateTime = LocalDateTime.now(), today: LocalDate = LocalDate.now()): Result {
        val old = req.oldLoan
        if (!LoanStateMachine.canRenewOrRefinance(old.status)) return Result.Error("El préstamo no puede reestructurarse en su estado actual")
        if (!req.newPrincipal.isPositive()) return Result.Error("El capital del nuevo préstamo debe ser mayor a cero")
        if (req.paymentNow.isNegative() || req.paymentNow > old.totalBalance) return Result.Error("El pago inicial es inválido")

        return db.withTransaction {
            val oldEntity = db.loanDao().getById(old.id) ?: return@withTransaction Result.Error("Préstamo no encontrado")
            val createdAt = oldEntity.createdAt
            var currentOld = old
            var cashAccount = ensureCashAccount(now)

            // 1) Pago inicial opcional sobre el préstamo anterior (intereses luego capital)
            if (req.paymentNow.isPositive()) {
                val toInterest = req.paymentNow.min(old.interestOutstanding)
                val toPrincipal = (req.paymentNow - toInterest).min(old.principalOutstanding)
                val paidApplied = toInterest + toPrincipal
                val newPrincipalOut = old.principalOutstanding - toPrincipal
                val newInterestOut = old.interestOutstanding - toInterest
                val newTotalPaid = old.totalPaid + paidApplied
                val newBalance = newPrincipalOut + newInterestOut
                currentOld = old.copy(
                    principalOutstanding = newPrincipalOut,
                    interestOutstanding = newInterestOut,
                    interestPaid = old.interestPaid + toInterest,
                    totalPaid = newTotalPaid,
                    totalBalance = newBalance
                )
                val receipt = "RES-PAY-${old.id}-${System.currentTimeMillis()}"
                val pid = db.paymentDao().insert(PaymentEntity(
                    loanId = old.id, clientId = old.clientId, receiptNumber = receipt, paidAt = now,
                    amountTotal = paidApplied, amountToInterest = toInterest, amountToPrincipal = toPrincipal,
                    amountToFees = Money.ZERO, surplus = Money.ZERO, method = req.paymentMethod,
                    distributionMode = DistributionMode.AUTOMATICA, notes = "Pago en reestructuración", status = PaymentStatus.APLICADO
                ))
                val cashTxId = db.cashDao().insertTransaction(CashTransactionEntity(
                    cashAccountId = cashAccount.id, type = CashTxType.PAGO_RECIBIDO, amount = paidApplied,
                    relatedLoanId = old.id, relatedPaymentId = pid, occurredAt = now, notes = "Pago reestructuración $receipt"
                ))
                cashAccount = cashAccount.copy(currentBalance = cashAccount.currentBalance + paidApplied)
                db.cashDao().updateAccount(cashAccount)
                db.movementDao().insert(MovementEntity(
                    loanId = old.id, paymentId = pid, cashTxId = cashTxId, type = MovementType.PAGO,
                    amount = paidApplied, timestamp = now,
                    balanceBefore = old.totalBalance, balanceAfter = newBalance,
                    principalBefore = old.principalOutstanding, principalAfter = newPrincipalOut,
                    interestBefore = old.interestOutstanding, interestAfter = newInterestOut,
                    reference = receipt
                ))
                if (toInterest.isPositive() || toPrincipal.isPositive()) {
                    db.allocationDao().insertAll(buildList {
                        if (toInterest.isPositive()) add(PaymentAllocationEntity(paymentId = pid, component = "INTERES", amount = toInterest))
                        if (toPrincipal.isPositive()) add(PaymentAllocationEntity(paymentId = pid, component = "CAPITAL", amount = toPrincipal))
                    })
                }
            }

            // 2) Cerrar préstamo anterior como REESTRUCTURADO (saldo trasladado/resuelto, sin duplicar deuda)
            val closedOld = currentOld.copy(
                principalOutstanding = Money.ZERO,
                interestOutstanding = Money.ZERO,
                totalBalance = Money.ZERO,
                status = LoanStatus.REESTRUCTURADO
            )
            db.loanDao().update(closedOld.toEntity(createdAt = createdAt, updatedAt = today))
            db.movementDao().insert(MovementEntity(
                loanId = old.id, paymentId = null, cashTxId = null, type = req.type,
                amount = currentOld.totalBalance, timestamp = now,
                balanceBefore = currentOld.totalBalance, balanceAfter = Money.ZERO,
                principalBefore = currentOld.principalOutstanding, principalAfter = Money.ZERO,
                interestBefore = currentOld.interestOutstanding, interestAfter = Money.ZERO,
                reference = "RESTRUCT-${old.id}"
            ))

            // 3) Crear nuevo préstamo vinculado
            val initialInterest = InterestCalculator.calculateInterest(
                principalOriginal = req.newPrincipal,
                principalOutstanding = req.newPrincipal,
                ratePercent = req.newRatePercent,
                method = req.newInterestMethod,
                accrualMode = req.newAccrualMode,
                periods = if (req.newAccrualMode == AccrualMode.PERIODO_COMPLETO) 1 else 0,
                daysElapsed = req.newTermDays,
                termDays = req.newTermDays
            )
            val seq = db.loanDao().nextSequence()
            val loanNumber = "DPM-${today.toString().replace("-", "")}-${seq.toString().padStart(5, '0')}"
            val newLoan = LoanEntity(
                clientId = old.clientId,
                loanNumber = loanNumber,
                principalOriginal = req.newPrincipal,
                principalOutstanding = req.newPrincipal,
                interestRatePercent = req.newRatePercent.toPlainString(),
                interestMethod = req.newInterestMethod,
                accrualMode = req.newAccrualMode,
                defaultPaymentMode = req.newPaymentMode,
                termType = when (req.newTermDays) { 15 -> TermType.QUINCENAL; 30 -> TermType.MENSUAL; else -> TermType.PERSONALIZADO },
                termDays = req.newTermDays,
                disbursementDate = today,
                dueDate = today.plusDays(req.newTermDays.toLong()),
                status = LoanStatus.ACTIVO,
                interestGenerated = initialInterest,
                interestPaid = Money.ZERO,
                interestOutstanding = initialInterest,
                totalPaid = Money.ZERO,
                totalBalance = req.newPrincipal + initialInterest,
                gracePeriodDays = old.gracePeriodDays,
                lateFeeEnabled = old.lateFeeEnabled,
                parentLoanId = old.id,
                periodsCharged = if (req.newAccrualMode == AccrualMode.PERIODO_COMPLETO) 1 else 0,
                notes = "Reestructurado desde ${old.loanNumber}",
                createdAt = today,
                updatedAt = today
            )
            val newId = db.loanDao().insert(newLoan)
            db.movementDao().insert(MovementEntity(
                loanId = newId, paymentId = null, cashTxId = null, type = MovementType.DESEMBOLSO,
                amount = req.newPrincipal, timestamp = now,
                balanceBefore = Money.ZERO, balanceAfter = req.newPrincipal + initialInterest,
                principalBefore = Money.ZERO, principalAfter = req.newPrincipal,
                interestBefore = Money.ZERO, interestAfter = initialInterest,
                reference = "FROM-${old.loanNumber}"
            ))

            val action = if (req.type == MovementType.RENOVACION) AuditAction.RENOVAR else AuditAction.REFINANCIAR
            db.auditDao().insert(AuditLogEntity(action = action, entityType = "loan", entityId = old.id.toString(), timestamp = now, details = "old=${old.id};new=$newId;paidNow=${req.paymentNow.toPlainString()};newPrincipal=${req.newPrincipal.toPlainString()}"))
            Result.Success(old.id, newId)
        }
    }

    private suspend fun ensureCashAccount(now: LocalDateTime): CashAccountEntity {
        val existing = db.cashDao().getMainAccount()
        if (existing != null) return existing
        val account = CashAccountEntity(name = "Caja principal", initialBalance = Money.ZERO, currentBalance = Money.ZERO, createdAt = now)
        val id = db.cashDao().insertAccount(account)
        return account.copy(id = id)
    }
}
