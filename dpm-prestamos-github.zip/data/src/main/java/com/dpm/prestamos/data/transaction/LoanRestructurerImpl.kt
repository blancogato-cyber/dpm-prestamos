package com.dpm.prestamos.data.transaction

import com.dpm.prestamos.domain.usecase.loan.LoanRestructurer
import com.dpm.prestamos.domain.usecase.loan.RestructureParams
import com.dpm.prestamos.domain.usecase.loan.RestructureResult
import javax.inject.Inject

class LoanRestructurerImpl @Inject constructor(private val service: LoanRestructureService) : LoanRestructurer {
    override suspend fun restructure(params: RestructureParams): RestructureResult =
        when (val r = service.restructure(
            LoanRestructureService.RestructureRequest(
                oldLoan = params.oldLoan,
                paymentNow = params.paymentNow,
                paymentMethod = params.paymentMethod,
                newPrincipal = params.newPrincipal,
                newRatePercent = params.newRatePercent,
                newTermDays = params.newTermDays,
                newInterestMethod = params.newInterestMethod,
                newAccrualMode = params.newAccrualMode,
                newPaymentMode = params.newPaymentMode,
                type = params.type
            )
        )) {
            is LoanRestructureService.Result.Success -> RestructureResult.Success(r.oldLoanId, r.newLoanId)
            is LoanRestructureService.Result.Error -> RestructureResult.Error(r.message)
        }
}
