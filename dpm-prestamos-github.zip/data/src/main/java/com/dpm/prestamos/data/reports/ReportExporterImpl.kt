package com.dpm.prestamos.data.reports

import android.content.Context
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.dpm.prestamos.core.money.MoneyFormatter
import com.dpm.prestamos.domain.enums.LoanStatus
import com.dpm.prestamos.domain.enums.PaymentStatus
import com.dpm.prestamos.domain.repository.*
import com.dpm.prestamos.domain.usecase.reports.ExportFormat
import com.dpm.prestamos.domain.usecase.reports.ExportResult
import com.dpm.prestamos.domain.usecase.reports.ReportExporter
import com.dpm.prestamos.domain.usecase.reports.ReportType
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import java.io.FileOutputStream
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ReportExporterImpl @Inject constructor(
    @ApplicationContext private val context: Context,
    private val clientRepo: ClientRepository,
    private val loanRepo: LoanRepository,
    private val paymentRepo: PaymentRepository,
    private val cashRepo: CashRepository
) : ReportExporter {

    override suspend fun export(type: ReportType, format: ExportFormat, from: LocalDate?, to: LocalDate?): Result<ExportResult> = runCatching {
        val ts = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"))
        val base = "dpm_${type.name.lowercase()}_$ts"
        val (headers, rows) = buildReport(type, from, to)
        val rangeNote = if (from != null || to != null) "Rango: ${from ?: "..."} a ${to ?: "..."} | " else ""
        when (format) {
            ExportFormat.CSV, ExportFormat.EXCEL -> {
                val name = "$base.csv"
                val file = writeCsv(name, headers, rows)
                ExportResult(file.absolutePath, "text/csv", name)
            }
            ExportFormat.PDF -> {
                val name = "$base.pdf"
                val file = writePdf(name, titleFor(type), headers, rows, footer = "${rangeNote}Generado por DPM - ${LocalDateTime.now()}")
                ExportResult(file.absolutePath, "application/pdf", name)
            }
        }
    }

    override suspend fun generateReceipt(paymentId: Long): Result<ExportResult> = runCatching {
        val payment = paymentRepo.getById(paymentId) ?: error("Pago no encontrado")
        val loan = loanRepo.getById(payment.loanId) ?: error("Préstamo no encontrado")
        val client = clientRepo.getById(payment.clientId)
        val name = "recibo_${payment.receiptNumber}.pdf"
        val doc = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = doc.startPage(pageInfo)
        val c = page.canvas
        val titlePaint = Paint().apply { textSize = 20f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
        val bold = Paint().apply { textSize = 12f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
        val body = Paint().apply { textSize = 12f }
        var y = 50f
        fun line(text: String, paint: Paint = body, gap: Float = 18f) { c.drawText(text, 40f, y, paint); y += gap }
        line("DPM - Recibo de pago", titlePaint, 28f)
        line("Recibo: ${payment.receiptNumber}", bold)
        line("Fecha: ${payment.paidAt}")
        line("Estado: ${payment.status}")
        y += 6f
        line("Cliente: ${client?.fullName ?: "N/A"}", bold)
        client?.phone?.let { line("Teléfono: $it") }
        y += 6f
        line("Préstamo: ${loan.loanNumber}", bold)
        line("Monto total: ${MoneyFormatter.format(payment.amountTotal)}")
        line("Aplicado a intereses: ${MoneyFormatter.format(payment.amountToInterest)}")
        line("Aplicado a capital: ${MoneyFormatter.format(payment.amountToPrincipal)}")
        line("Método: ${payment.method}")
        if (!payment.surplus.isZero()) line("Excedente: ${MoneyFormatter.format(payment.surplus)}")
        y += 10f
        line("Saldo después del préstamo (actual): ${MoneyFormatter.format(loan.totalBalance)}", bold)
        payment.notes?.takeIf { it.isNotBlank() }?.let { line("Nota: $it") }
        if (payment.status == PaymentStatus.ANULADO) { y += 6f; line("ANULADO: ${payment.voidReason ?: "Sin motivo"}", bold) }
        y += 20f
        line("Documento generado por DPM", Paint().apply { textSize = 10f })
        doc.finishPage(page)
        val file = outFile(name)
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        ExportResult(file.absolutePath, "application/pdf", name)
    }

    private suspend fun buildReport(type: ReportType, from: LocalDate?, to: LocalDate?): Pair<List<String>, List<List<String>>> {
        fun inRange(date: LocalDate) = (from == null || !date.isBefore(from)) && (to == null || !date.isAfter(to))
        return when (type) {
            ReportType.CLIENTES -> {
                val clients = clientRepo.getAllOnce().filter { inRange(it.createdAt.toLocalDate()) }
                listOf("ID","Nombre","Teléfono","Documento","Creado") to clients.map { listOf(it.id.toString(), it.fullName, it.phone, it.documentId ?: "", it.createdAt.toString()) }
            }
            ReportType.PRESTAMOS -> {
                val loans = loanRepo.getAllOnce().filter { inRange(it.startDate) }
                val names = clientRepo.getAllOnce().associate { it.id to it.fullName }
                listOf("No.","Cliente","Capital","Saldo","InterésPend","Tasa%","Plazo","Vence","Estado") to loans.map { l -> listOf(l.loanNumber, names[l.clientId] ?: l.clientId.toString(), l.principalOriginal.toPlainString(), l.totalBalance.toPlainString(), l.interestOutstanding.toPlainString(), l.interestRatePercent.toPlainString(), l.termDays.toString(), l.dueDate.toString(), l.status.name) }
            }
            ReportType.PAGOS -> {
                val payments = paymentRepo.getAllOnce().filter { inRange(it.paidAt.toLocalDate()) }
                listOf("Recibo","Préstamo","Cliente","Fecha","Total","Interés","Capital","Método","Estado") to payments.map { p -> listOf(p.receiptNumber, p.loanId.toString(), p.clientId.toString(), p.paidAt.toString(), p.amountTotal.toPlainString(), p.amountToInterest.toPlainString(), p.amountToPrincipal.toPlainString(), p.method.name, p.status.name) }
            }
            ReportType.CAJA -> {
                val txs = cashRepo.getTransactionsOnce().filter { inRange(it.occurredAt.toLocalDate()) }
                listOf("ID","Fecha","Tipo","Monto","Nota") to txs.map { t -> listOf(t.id.toString(), t.occurredAt.toString(), t.type.name, t.amount.toPlainString(), t.notes ?: "") }
            }
            ReportType.INTERESES -> {
                val loans = loanRepo.getAllOnce().filter { inRange(it.startDate) }
                val names = clientRepo.getAllOnce().associate { it.id to it.fullName }
                listOf("Préstamo","Cliente","Generado","Cobrado","Pendiente") to loans.map { l -> listOf(l.loanNumber, names[l.clientId] ?: "", l.interestGenerated.toPlainString(), l.interestPaid.toPlainString(), l.interestOutstanding.toPlainString()) }
            }
            ReportType.CARTERA -> {
                val loans = loanRepo.getAllOnce().filter { it.status != LoanStatus.CANCELADO && (inRange(it.startDate) || inRange(it.dueDate)) }
                val names = clientRepo.getAllOnce().associate { it.id to it.fullName }
                listOf("Préstamo","Cliente","CapPend","IntPend","Saldo","Vence","Estado") to loans.map { l -> listOf(l.loanNumber, names[l.clientId] ?: "", l.principalOutstanding.toPlainString(), l.interestOutstanding.toPlainString(), l.totalBalance.toPlainString(), l.dueDate.toString(), l.status.name) }
            }
        }
    }

    private fun titleFor(type: ReportType): String = when (type) {
        ReportType.CLIENTES -> "Reporte de Clientes"
        ReportType.PRESTAMOS -> "Reporte de Préstamos"
        ReportType.PAGOS -> "Reporte de Pagos"
        ReportType.CAJA -> "Reporte de Caja"
        ReportType.INTERESES -> "Reporte de Intereses"
        ReportType.CARTERA -> "Reporte de Cartera"
    }

    private fun outFile(name: String): File = File(File(context.cacheDir, "exports").apply { mkdirs() }, name)

    private fun writeCsv(name: String, headers: List<String>, rows: List<List<String>>): File {
        val file = outFile(name)
        file.bufferedWriter().use { w ->
            fun esc(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
            w.appendLine(headers.joinToString(",") { esc(it) })
            rows.forEach { r -> w.appendLine(r.joinToString(",") { esc(it) }) }
        }
        return file
    }

    private fun writePdf(name: String, title: String, headers: List<String>, rows: List<List<String>>, footer: String): File {
        val doc = PdfDocument()
        val paint = Paint().apply { textSize = 10f }
        val bold = Paint().apply { textSize = 10f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
        val titlePaint = Paint().apply { textSize = 16f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
        val pageWidth = 595; val pageHeight = 842; val margin = 30f; val lineH = 14f
        val colCount = headers.size.coerceAtLeast(1)
        val colW = (pageWidth - margin * 2) / colCount
        var pageNum = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
        var c = page.canvas; var y = margin
        fun newPage() { doc.finishPage(page); pageNum++; page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create()); c = page.canvas; y = margin }
        fun ensure(space: Float = lineH) { if (y + space > pageHeight - margin) newPage() }
        c.drawText("DPM - $title", margin, y + 12f, titlePaint); y += 24f
        ensure(); headers.forEachIndexed { i, h -> c.drawText(h.take(14), margin + i * colW, y, bold) }; y += lineH
        c.drawLine(margin, y - 8f, pageWidth - margin, y - 8f, paint)
        rows.forEach { row -> ensure(); row.forEachIndexed { i, cell -> c.drawText(cell.take(16), margin + i * colW, y, paint) }; y += lineH }
        ensure(30f); c.drawText(footer, margin, pageHeight - margin, Paint().apply { textSize = 9f })
        doc.finishPage(page)
        val file = outFile(name)
        FileOutputStream(file).use { doc.writeTo(it) }; doc.close()
        return file
    }
}
