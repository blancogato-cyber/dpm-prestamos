package com.dpm.prestamos.data.transaction

import androidx.room.withTransaction
import com.dpm.prestamos.core.time.AppClock
import com.dpm.prestamos.data.mapper.toEntity
import com.dpm.prestamos.database.DpmDatabase
import com.dpm.prestamos.domain.enums.LoanStatus
import java.time.LocalDate
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LoanStatusUpdater @Inject constructor(private val db: DpmDatabase) {
    suspend fun sync(today: LocalDate = AppClock.today(), upcomingDays: Long = 3) {
        db.withTransaction {
            val loans = db.loanDao().observeAllOnce()
            val dueSoonLimit = today.plusDays(upcomingDays)
            loans.forEach { e ->
                if (e.status in listOf(LoanStatus.LIQUIDADO, LoanStatus.CANCELADO, LoanStatus.REESTRUCTURADO)) return@forEach
                if (e.totalBalance.isZero()) return@forEach
                val newStatus = when {
                    e.dueDate.isBefore(today) -> LoanStatus.VENCIDO
                    !e.dueDate.isAfter(dueSoonLimit) -> LoanStatus.PROXIMO_VENCER
                    else -> LoanStatus.ACTIVO
                }
                if (newStatus != e.status) {
                    db.loanDao().update(e.copy(status = newStatus, updatedAt = today))
                }
            }
        }
    }
}
