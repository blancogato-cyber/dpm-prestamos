package com.dpm.prestamos.data.repository

import com.dpm.prestamos.data.mapper.toDomain
import com.dpm.prestamos.data.mapper.toEntity
import com.dpm.prestamos.database.dao.LoanDao
import com.dpm.prestamos.domain.enums.LoanStatus
import com.dpm.prestamos.domain.model.Loan
import com.dpm.prestamos.domain.repository.LoanRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import javax.inject.Inject

class LoanRepositoryImpl @Inject constructor(
    private val dao: LoanDao
) : LoanRepository {
    override fun observeAll(): Flow<List<Loan>> = dao.observeAll().map { it.map { e -> e.toDomain() } }
    override fun observeById(id: Long): Flow<Loan?> = dao.observeById(id).map { it?.toDomain() }
    override fun observeByClient(clientId: Long): Flow<List<Loan>> = dao.observeByClient(clientId).map { it.map { e -> e.toDomain() } }
    override fun observeByStatus(status: LoanStatus): Flow<List<Loan>> = dao.observeByStatus(status).map { it.map { e -> e.toDomain() } }
    override fun observeDueOn(date: LocalDate): Flow<List<Loan>> = dao.observeDueOn(date).map { it.map { e -> e.toDomain() } }
    override suspend fun getById(id: Long): Loan? = dao.getById(id)?.toDomain()
    override suspend fun getAllOnce(): List<Loan> = dao.getAllOnce().map { it.toDomain() }
    override suspend fun save(loan: Loan): Long {
        val today = LocalDate.now()
        val entity = loan.toEntity(createdAt = today, updatedAt = today)
        return if (loan.id == 0L) dao.insert(entity) else { dao.update(entity); loan.id }
    }
    override suspend fun nextLoanNumber(): String {
        val seq = dao.nextSequence()
        val date = LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE)
        return "DPM-$date-${seq.toString().padStart(5, '0')}"
    }

    override suspend fun syncStatuses(today: LocalDate, upcomingDays: Long) {
        val dueSoonLimit = today.plusDays(upcomingDays)
        dao.getAllOnce().forEach { e ->
            if (e.status in listOf(LoanStatus.LIQUIDADO, LoanStatus.CANCELADO, LoanStatus.REESTRUCTURADO)) return@forEach
            if (e.totalBalance.isZero()) return@forEach
            val newStatus = when {
                e.dueDate.isBefore(today) -> LoanStatus.VENCIDO
                !e.dueDate.isAfter(dueSoonLimit) -> LoanStatus.PROXIMO_VENCER
                else -> LoanStatus.ACTIVO
            }
            if (newStatus != e.status) dao.update(e.copy(status = newStatus, updatedAt = today))
        }
    }
}
