package com.dpm.prestamos.data.repository

import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.data.mapper.toDomain
import com.dpm.prestamos.data.mapper.toEntity
import com.dpm.prestamos.database.dao.ClientDao
import com.dpm.prestamos.database.dao.LoanDao
import com.dpm.prestamos.database.dao.PaymentDao
import com.dpm.prestamos.domain.model.Client
import com.dpm.prestamos.domain.model.ClientProfile
import com.dpm.prestamos.domain.repository.ClientRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.math.BigDecimal
import javax.inject.Inject

class ClientRepositoryImpl @Inject constructor(
    private val dao: ClientDao,
    private val loanDao: LoanDao,
    private val paymentDao: PaymentDao
) : ClientRepository {
    override fun observeAll(): Flow<List<Client>> = dao.observeAll().map { it.map { e -> e.toDomain() } }
    override fun observeById(id: Long): Flow<Client?> = dao.observeById(id).map { it?.toDomain() }
    override suspend fun getById(id: Long): Client? = dao.getById(id)?.toDomain()
    override suspend fun getAllOnce(): List<Client> = dao.getAllOnce().map { it.toDomain() }
    override fun search(query: String): Flow<List<Client>> = dao.search(query).map { it.map { e -> e.toDomain() } }
    override suspend fun save(client: Client): Long =
        if (client.id == 0L) dao.insert(client.toEntity()) else { dao.update(client.toEntity()); client.id }
    override suspend fun isPossibleDuplicate(name: String, phone: String, excludeId: Long?): Boolean =
        dao.countPossibleDuplicates(name, phone, excludeId) > 0

    override suspend fun getProfile(clientId: Long): ClientProfile? {
        val client = dao.getById(clientId)?.toDomain() ?: return null
        val last = paymentDao.lastPaymentAt(clientId)?.toLocalDate()
        return ClientProfile(
            client = client,
            totalHistoricLent = Money.ofExact(BigDecimal.valueOf(loanDao.sumHistoricLent(clientId))),
            totalHistoricRecovered = Money.ofExact(BigDecimal.valueOf(loanDao.sumHistoricRecovered(clientId))),
            interestPaid = Money.ofExact(BigDecimal.valueOf(loanDao.sumInterestPaid(clientId))),
            currentDebt = Money.ofExact(BigDecimal.valueOf(loanDao.sumCurrentDebt(clientId))),
            activeLoans = loanDao.countActive(clientId),
            overdueLoans = loanDao.countOverdue(clientId),
            settledLoans = loanDao.countSettled(clientId),
            lastPaymentDate = last
        )
    }
}
