package com.dpm.prestamos.data.repository

import com.dpm.prestamos.database.dao.CashDao
import com.dpm.prestamos.domain.repository.CashAccount
import com.dpm.prestamos.domain.repository.CashRepository
import com.dpm.prestamos.domain.repository.CashTx
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

class CashRepositoryImpl @Inject constructor(private val dao: CashDao) : CashRepository {
    override fun observeAccount(): Flow<CashAccount?> = dao.observeMainAccount().map { e -> e?.let { CashAccount(it.id, it.name, it.currentBalance) } }
    override fun observeTransactions(): Flow<List<CashTx>> = dao.observeTransactions().map { list -> list.map { CashTx(it.id, it.type, it.amount, it.occurredAt, it.notes) } }
    override suspend fun getTransactionsOnce(): List<CashTx> = dao.getTransactionsOnce().map { CashTx(it.id, it.type, it.amount, it.occurredAt, it.notes) }
}
