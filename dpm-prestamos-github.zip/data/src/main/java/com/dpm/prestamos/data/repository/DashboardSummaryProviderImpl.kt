package com.dpm.prestamos.data.repository

import com.dpm.prestamos.core.money.Money
import com.dpm.prestamos.database.dao.DashboardDao
import com.dpm.prestamos.domain.enums.LoanStatus
import com.dpm.prestamos.domain.repository.FinancialSummary
import com.dpm.prestamos.domain.usecase.accounting.DashboardSummaryProvider
import java.math.BigDecimal
import javax.inject.Inject

class DashboardSummaryProviderImpl @Inject constructor(
    private val dao: DashboardDao
) : DashboardSummaryProvider {
    override suspend fun getSummary(): FinancialSummary {
        val active = dao.countLoansByStatuses(listOf(LoanStatus.ACTIVO, LoanStatus.PROXIMO_VENCER))
        val overdue = dao.countLoansByStatus(LoanStatus.VENCIDO)
        val settled = dao.countLoansByStatus(LoanStatus.LIQUIDADO)
        return FinancialSummary(
            totalToRecover = Money.ofExact(BigDecimal.valueOf(dao.sumTotalToRecover())),
            principalOutstanding = Money.ofExact(BigDecimal.valueOf(dao.sumPrincipalOutstandingActive())),
            interestOutstanding = Money.ofExact(BigDecimal.valueOf(dao.sumInterestOutstandingActive())),
            interestCollected = Money.ofExact(BigDecimal.valueOf(dao.sumInterestCollected())),
            moneyRecovered = Money.ofExact(BigDecimal.valueOf(dao.sumMoneyRecovered())),
            activeLoans = active,
            overdueLoans = overdue,
            settledLoans = settled,
            paymentsToday = dao.countPaymentsToday()
        )
    }
}
