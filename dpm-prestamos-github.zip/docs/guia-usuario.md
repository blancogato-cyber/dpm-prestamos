# Guía de usuario - DPM

## Introducción
DPM es una aplicación Android offline para administrar préstamos personales con intereses (moneda RD$, zona horaria America/Santo_Domingo).

## Navegación principal
- **Inicio**: resumen financiero (por recuperar, capital/intereses pendientes y cobrados, recuperado, estados de préstamos, pagos de hoy) y préstamos recientes. Botón destacado **Nuevo préstamo**.
- **Préstamos**: listado con filtros (estado, plazo, cliente, monto, fecha) y acceso al detalle.
- **Clientes**: registro y perfil financiero (histórico, deuda actual, puntualidad).
- **Movimientos**: historial cronológico inmutable de operaciones con saldo anterior/posterior.
- **Más**: contabilidad, caja, calendario, reportes, calculadoras, seguridad, respaldos y configuración.

## Operaciones clave
- **Crear préstamo**: seleccionar cliente, monto, tasa, plazo (15/30/personalizado), método de interés (capital inicial o pendiente), devengo, modalidad y vencimiento. El sistema calcula intereses y saldo total.
- **Registrar pago**: elegir préstamo, monto y método (efectivo/transferencia/depósito/otro), distribución automática (intereses vencidos → capital) o manual, y ver desglose antes de confirmar. No se permite exceder el saldo sin confirmación y tratamiento del excedente.
- **Abonos al capital**: 5/10/15/20/25/30/50/100% o personalizado, con simulación del impacto en el próximo interés.
- **Liquidación/Renovación/Refinanciamiento**: con confirmación, preservando historial y sin duplicar deudas.

## Seguridad y respaldos
- PIN/biometría y bloqueo automático. Copias de seguridad manuales/automáticas cifradas, exportación/restauración con validación de integridad y confirmación.
