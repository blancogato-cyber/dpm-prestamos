# Guía de compilación - DPM

## Requisitos
- Android Studio (Koala+ recomendado) o entorno con Android SDK.
- JDK 17.
- Android SDK Platform 35 y Build-Tools correspondientes.
- Conexión solo para descargar dependencias Gradle/AGP (la app funciona offline en ejecución).

## Pasos
1. Abrir la carpeta raíz del proyecto (`DPM`) en Android Studio.
2. Permitir la sincronización de Gradle (se descargará el wrapper si se configura, o usar Gradle instalado).
3. Verificar `minSdk 26`, `target/compileSdk 35`.
4. Ejecutar pruebas unitarias del dominio: `./gradlew :domain:test`
5. Compilar APK debug: `./gradlew :app:assembleDebug`
6. Instalar en dispositivo/emulador (Android 8.0+): `./gradlew :app:installDebug`

## Notas
- Zona horaria financiera: `America/Santo_Domingo`. Moneda: RD$ (DOP).
- Base de datos Room `dpm.db` (v1). Migraciones deben agregarse antes de cambios de esquema en producción.
- La funcionalidad principal no requiere Internet.
