# Informe de pruebas - DPM

> Estado: **código implementado, ejecución/compilación pendiente** (entorno sin Android SDK/Gradle/JDK/emulador).

## Resumen
- Fecha de ejecución: _pendiente_
- Entorno: _pendiente (Android SDK, dispositivo/emulador)_
- Resultado global: _no ejecutado en este entorno_

## Cobertura implementada en código (motor y flujos)
- **Motor (unit tests de dominio/core definidos):** `InterestCalculatorTest`, `PaymentAllocatorTest`, `AmortizationAndSettlementTest`, `FinancialScenariosSpecTest` (incluye escenarios 1–15 a nivel de cálculo), `LoanStateMachineTest`, `MoneyTest`.
- **Flujos transaccionales implementados:** registro/anulación/liquidación de pagos con asignaciones, caja y auditoría (`PaymentTransactionService`); renovación/refinanciamiento sin duplicar deuda (`LoanRestructureService`); operaciones de caja auditadas; sincronización de estados por vencimiento.
- **Módulos UI/funcionales:** dashboard, clientes (perfil financiero), préstamos (filtros, detalle, pagos/abonos/liquidación), reestructuración, contabilidad, caja, calendario (día/semana/mes, mora/gracia), reportes/exportación PDF/CSV, recibos PDF compartibles, recordatorios (WorkManager) con solicitud de permiso, seguridad (PIN/bloqueo), respaldos cifrados con integridad y configuración.

## Pruebas unitarias (motor financiero) — plan/estado
| Caso | Escenario | Esperado | Estado | Notas |
|---|---|---|---|---|
| 1 | Préstamo sin intereses | Interés 0 | Cubierto en código | `FinancialScenariosSpecTest` |
| 2 | Interés 10% | Cálculo correcto | Cubierto en código |  |
| 3 | Interés 20% (RD$10k→RD$2k) | 2000 | Cubierto en código | `InterestCalculatorTest` |
| 4 | Plazo 15 días | Devengo correcto | Cubierto en código |  |
| 5 | Plazo 30 días | Devengo correcto | Cubierto en código |  |
| 6 | Pago exclusivo de intereses | Capital intacto | Cubierto en código | `PaymentAllocatorTest` |
| 7 | Abono parcial de capital | Saldo actualizado | Cubierto en código |  |
| 8 | Pago combinado | Desglose correcto | Cubierto en código |  |
| 9 | Liquidación completa | Saldo 0 | Cubierto en código |  |
| 10 | Liquidación anticipada | Devengado no pagado incluido | Cubierto en código |  |
| 11 | Renovación | Sin duplicar deuda, historial | Implementado (integración pendiente) | Servicio transaccional + UI |
| 12 | Refinanciamiento | Nuevo calendario, antecedente | Implementado (integración pendiente) |  |
| 13 | Préstamo vencido | Estado/atraso correcto | Implementado (pendiente verificación) | Estado/mora en calendario |
| 14 | Pagos consecutivos | Sin duplicar períodos | Cubierto en motor | `PeriodTracker` |
| 15 | Pagos en diferentes períodos | Base según método | Cubierto en código | Capital pendiente RD$8k→RD$1.6k |

## Pruebas técnicas — pendientes de ejecución
| Área | Verificación | Resultado | Observaciones |
|---|---|---|---|
| Compilación/APK | Build debug/release instalable | _pendiente_ | Requiere Android SDK/AGP toolchain |
| Cierre/reinicio | Persistencia y recuperación | _pendiente_ | Room/State |
| Migración BD | Room `MIGRATION_1_2` (payment_allocations) | _definida, no verificada_ | Sustituye fallback destructivo |
| Offline | Operación sin red | _pendiente por diseño_ |  |
| Export/Import | PDF/CSV, recibos, respaldo cifrado+integridad | _pendiente_ |  |
| Notificaciones | Permiso y WorkManager | _pendiente_ |  |
| Seguridad | PIN/bloqueo al inicio, restauración | _pendiente_ |  |
| UI | Múltiples tamaños/flujo | _pendiente_ |  |

## Errores encontrados y corregidos
- _Sin ejecución en dispositivo/emulador: no se han registrado fallos de runtime; ejecutar suite y pruebas instrumentadas en entorno Android para validar y corregir._
