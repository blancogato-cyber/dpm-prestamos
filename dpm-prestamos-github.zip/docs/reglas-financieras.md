# Reglas financieras - DPM

## Representación monetaria
- `BigDecimal` con escala fija (2 decimales, redondeo `HALF_EVEN`) encapsulado en `Money`. Prohibido `Double/Float` para importes.

## Interés
- Interés simple: `Interés = Capital_base × Tasa / 100` por período. Sin capitalización automática.
- Base: `CAPITAL_INICIAL` (capital original) o `CAPITAL_PENDIENTE` (saldo vigente al inicio del período).
- Devengo: `PERIODO_COMPLETO` o `PROPORCIONAL_DIAS` (configurable por préstamo).
- Control de períodos: no cobrar dos veces el mismo período (`PeriodTracker` / `periodsCharged`).

## Pagos
- Distribución automática predeterminada: intereses (y cargos/mora pendientes) primero, luego capital. Manual disponible con validación.
- Nunca exceder saldo total sin confirmación explícita y tratamiento del excedente.
- Toda distribución guarda desglose capital/intereses/cargos/excedente.

## Saldos y movimientos
- Saldos vigentes del préstamo se actualizan solo en transacciones atómicas junto con pago, movimiento(s), caja y auditoría.
- `movements` es historial inmutable (saldo antes/después). No se sobrescriben ni borran operaciones financieras; las correcciones se realizan por anulación registrada.

## Contabilidad y caja
- Ingresos cobrados ≠ pendientes. Capital recuperado no es ganancia.
- Desembolso reduce efectivo disponible; pago recibido lo aumenta. Gastos operativos separados de préstamos.

## Renovación/refinanciamiento
- Conservan antecedente (`parentLoanId`) e historial. No duplican capital ni cuentan dos veces la deuda.

## Mora
- Independiente del interés ordinario, configurable y sujeta a normativa aplicable. No aplicar retroactivamente sin fundamento registrado.
